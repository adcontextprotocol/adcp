# Seller Reporting Ledger

Reliable Reporting Core turns a conforming reporting source into durable seller-side reporting. It is separate from the buyer-side `reconcileReporting` API.

Two packages make it up. `@adcp/sdk` holds the protocol layer: the `ReportingLedgerStore` interface, the protocol handlers, the producer, `createReliableReportingService` and row encoding (`@adcp/sdk/reporting/ledger`, `@adcp/sdk/reporting/service`). [`@adcp/reporting-storage`](https://github.com/adcontextprotocol/adcp-client/blob/main/packages/reporting-storage/README.md) holds the storage behind it: the PostgreSQL ledger store and migrations, row storage and its GCS, S3 and Azure providers, managed delivery, notification activity, the BigQuery sink and the production composition. Install both (`npm install @adcp/sdk@beta @adcp/reporting-storage@beta pg` while SDK 16 is in beta). Moving from the pre-split `@adcp/sdk/reporting/*` imports? See [Reliable Reporting storage moved to `@adcp/reporting-storage`](../migration-reporting-storage-package.md).

> **Stability:** `@adcp/reporting-storage` is pre-1.0 and every export of it is experimental: breaking changes ship in its minor releases. Pin it with `~`. The store, transaction, lease and row-read interfaces in `@adcp/sdk/reporting/ledger` that it implements are `@experimental` too. See the [Reliable Reporting stability policy](REPORTING-STABILITY.md).

## Recommended: install the lifecycle service

`createReliableReportingService` is the adapter-first Core path. A
provider adapter supplies one bounded slice fetch and two immutable offering
descriptions; the service reuses the PostgreSQL ledger, source executor,
producer, handlers, and decisioning-platform account resolver.

```ts
import { Pool } from 'pg';
import { postgresStorage } from '@adcp/reporting-storage';
import { createReliableReportingService } from '@adcp/sdk/reporting/service';
import { createAdcpServerFromPlatform } from '@adcp/sdk/server';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
// One storage decision: the ledger, principal records, reporting-subscription state and the buyer
// consumer's state. memoryStorage() from '@adcp/sdk/storage' in development.
const storage = postgresStorage({ pool, acknowledgeIsolatedDatabase: true });
await storage.checkSchema(); // REPORTING_SCHEMA_BEHIND: run "npx adcp-reporting-storage migrate"

const reporting = createReliableReportingService({
  storage,
  adapters: {
    // These descriptions are immutable declarations owned by your adapter.
    gam: { sourceOffering: gamSourceOffering, deliveryOffering: gamDeliveryOffering,
      fetchSlice: (slice, ctx) => gam.fetchDeliverySlice(slice, ctx) },
  },
  contact: { name: 'Reporting operations', email: 'reporting@example.com' },
  automatedRecoveryWindowSeconds: 86_400,
  statusRetentionDays: 90,

  // `account` is the framework-resolved account, not request.account.
  resolveSource: account => ({
    adapterId: 'gam',
    sourceScope: { network_id: account.ctx_metadata.gam.networkId },
    sourceTimezone: account.ctx_metadata.gam.reportingTimezone,
  }),
  // Resolve from trusted commercial/account state. The result is frozen into
  // the generation and every obligation; no request-body fallback exists.
  resolveCurrency: account => account.ctx_metadata.gam.currency,
  // The authorization boundary for shared upstream networks: return only the
  // constituents this account may report on. Never echo the declaration.
  resolveCoverage: async account => ({
    constituents: await bookings.authorizedReportingConstituents(account.id),
  }),
  resolveConsumerId: ctx => {
    if (!ctx.agent) throw new Error('Authenticated buyer-agent registry required');
    return ctx.agent.agent_url;
  },
});

const installedPlatform = reporting.install(platform);
const server = createAdcpServerFromPlatform(installedPlatform, serverOptions);

reporting.start({ intervalMilliseconds: 60_000, deploymentWide: true });
process.once('SIGTERM', () => void reporting.stop());
```

Apply the schema before starting a release with `npx adcp-reporting-storage migrate`
(`--status` lists applied and pending versions, `--dry-run` prints the plan; it reads
`--database-url`, `$ADCP_DATABASE_URL` or `$DATABASE_URL`, and `--schema`). The migrations are
versioned and recorded in `adcp_schema_migrations`; `storage.checkSchema()`, which the service also
runs before its first cycle, refuses a schema that is behind and names the pending versions. A
schema set up by applying the migration constants by hand migrates cleanly. The constants
(`REPORTING_LEDGER_MIGRATION`, `REPORTING_ROW_STORAGE_MIGRATION`, `REPORTING_LEDGER_CHANGES_MIGRATION`,
`REPORTING_MANAGED_DELIVERY_MIGRATION` and the others below) stay exported as deprecated re-exports
for one beta; where this guide says to apply or re-apply one, `migrate` does it.

The service advertises Reliable Reporting Core only. `sync_reporting_status` is advertised only when
`resolveConsumerId` is installed and the supplied ledger implements its
atomic consumer-status methods. Do not place higher tiers in a manual
capability override.

For the complete seller deployment, use the async
`createPostgresReliableReportingProductionService`. It assembles Core, Managed
Delivery, reconciled receipts when the offering requests them, all three
reporting notification types, durable webhook retries, principal-scoped
webhook activity, fair per-account delivery work, and coordinated shutdown.
Pass it `storage: postgresStorage({ pool, acknowledgeIsolatedDatabase: true })` instead of `db`: the
constructor then refuses a schema that is behind. Its notification outbox and activity tables
(configurable names) are still returned in `setup.migrations`; pass `applyMigrations` to bridge them
into your migration runner. The constructor publishes no capability object until every table and
worker dependency probes successfully and the advertised managed policy is
durably adopted. Its `platform` mounts `sync_reporting_receipts` through
`createAdcpServerFromPlatform`, and its scheduler drives production, managed
delivery, notification recovery, retry recovery, and bounded retention cleanup
together. `stop()` aborts and awaits both worker loops.
The production scheduler and `recoverOnce()` require the explicit
`deploymentWide: true` option because notification and webhook recovery scan
the entire configured namespace. Use an isolated namespace and publisher scope
for each independently operated tenant partition. The Core-only scheduler may
still use an `accountIds` roster. Production setup requires
`activity.tenantScopeForAccount`; when an offering uses `consumer_receipt`, it
also requires a trusted `obligatedConsumers` callback so lifecycle health can
become reconciled only after every obligated consumer has accepted.
See the [integrated seller example](https://github.com/adcontextprotocol/adcp-client/blob/main/packages/reporting-storage/examples/reliable-reporting-service/README.md#integrated-seller-production-service)
for the full option shape.

Install a buyer declaration after the account and its media-buy scope have
been authorized and resolved. `installConfiguration` intentionally accepts no
account, `sourceScope`, contract, timezone, currency, `constituents`, or
`mediaBuyIds` fields from the declaration. Pass the framework-resolved
`ctx.account`; trusted callbacks derive the remaining lineage. `resolveCoverage`
is the media-buy/package authorization boundary and must derive the denominator
from the resolved account: `sourceScope` may legitimately name a shared upstream
network, in which case the constituent list is the only thing keeping one
buyer's orders out of another buyer's report. `mediaBuyIds` is always derived
from the returned constituents, so a buyer-named order ID can never reach
`fetchSlice`. `expectedCurrency`, `expectedSourceTimezone`, and
`expectedMediaBuyIds` are optional assertions and fail closed on conflict.
For products created per brief or buy, source offerings may declare
`applicability.products: { kind: 'host_attested' }`. In that mode,
`resolveCoverage` must also verify each product declares the selected offering
in `reporting_capabilities.reporting_delivery_offering_ids`. The SDK retains
constituent-kind and product-binding checks, and freezes the returned
denominator for each configuration generation. Existing `productIds` lists
keep their allowlist behavior. See [source offering applicability](./REPORTING-SOURCE-EXECUTOR.md#products-created-per-brief-or-buy)
for the new shapes and reader compatibility requirements.
The service rejects credential-shaped keys and `ctx_metadata` anywhere in the
returned `sourceScope`, then applies the source contract and existing ledger
immutability checks. Return the resulting secret-free configuration state from
your `sync_accounts` implementation.

### Reporting history before installation

Trusted host code can grant an account reporting history independently of when
its configuration was installed. Supply the entitlement in the install context,
then extend it when the account upgrades:

```ts
const installed = await reporting.installConfiguration(declaration, {
  account: ctx.account,
  historyStart: accountEntitlement.historyStart, // ISO instant from trusted commercial state
});

await reporting.extendConfigurationHistory({
  configurationId: installed.configurationId,
  historyStart: upgradedEntitlement.historyStart,
});

await reporting.runCycle({
  accountId: ctx.account.id,
  maxHistorySlicesPerSource: 5,
});
```

Without `historyStart`, ownership still starts at the first scheduled boundary
at or after `max(anchor, installedAt)`. With it, ownership starts at the first
boundary **at or after the requested instant**, even when that boundary predates
the anchor. Source-calendar days use source-local boundaries, including 23- and
25-hour days. The entire historical span is validated against the source's
window bounds and calendar rules before ownership is accepted.

The requested instant must fall within the source offering's rolling
`retentionDays` window (`now - retentionDays * 24 hours`) and must not be in the
future. Out-of-range requests are refused, never silently clamped. Instants
require a timezone and at most millisecond precision. Extension can move the
aligned boundary earlier or leave it unchanged; it cannot move it later.
An unchanged replay remains valid as source retention advances.

History changes preserve the configuration ID, version, semantic fingerprint,
real `installedAt`, frozen calendar rules, and existing obligations and
publications. Reinstalling without a history option returns the current stored
ownership. A repeated install requesting a later history start also keeps the
already owned earlier range, so rolling entitlement timestamps do not shrink
ownership or break replay. Use `extendConfigurationHistory` for an earlier
boundary. On a successor version, omit `historyStart`; extend the earliest
relevant stored generation separately when the entitlement grows. History cannot overlap
another generation's owned periods: extend the earliest relevant generation to
recover periods before a successor's handoff. Coverage and status count the
entire continuous owned range, so unplanned closed history counts as a coverage
gap just like missing live obligations. Run a cycle after install or extension
to populate it. Public deadlines remain tied to the historical period:
unpublished periods past their public recovery deadline report `action_required`
/ `REPORT_OVERDUE`, including period status notifications, until publication
satisfies them. Recent historical periods retain the normal waiting/delayed
progression. The private retry
window controls execution retries and does not postpone buyer-visible deadlines.
Pausing history intentionally leaves those obligations outstanding. Source
retention is checked when history is granted; delayed execution may age beyond
the source's availability, so schedule the oldest slices promptly and leave
headroom when choosing entitlement boundaries.

Planning visits live periods across all configurations before history. Execution
also claims live work first, including when history is already queued. Each
worker pass executes at most `maxHistorySlicesPerSource` historical claims per
source offering, defaulting to **10**; zero pauses history execution. The same
option is accepted by `start()`. The optional
`maxHistoryObligationsPerSource` limits historical planning; by default history
shares the existing `maxObligations` cap (1,000). Zero pauses historical planning.
Fully plan historical ownership before a tzdb/ICU runtime upgrade, or retain
a worker with the generation's pinned runtime rules until planning is complete;
frozen calendar ownership cannot be silently reinterpreted after an upgrade.
Both budgets include retries, where applicable, and are shared by configurations
using the same offering within that pass. Scheduler budgets apply to each
account cycle, and concurrent workers have separate budgets. The adapter or host
must coordinate any shared upstream API quota across accounts and workers using
the source's `rateLimitConstraints`; these limits do not implement a distributed
rate limiter. Initial history requests use the source contract's `backfill`
trigger; retries use `retry` and receive a durable private retry window from the
first execution attempt while public deadlines remain period-based.

The low-level producer accepts `installConfiguration(input, { historyStart })`
and exposes the same extension method. A custom ledger store must persist
`historyStart` and `historyStartOrdinal`, implement atomic
`extendConfigurationHistory`, enforce newly owned range overlap checks atomically
at both install and extension, and honor live priority and
`excludeHistoryOfferingIds` in `claimObligation`. PostgreSQL supplies these
operations; reapply `REPORTING_LEDGER_MIGRATION` to add its nullable
`history_start` audit column (mirroring the configuration JSON) and live-priority
claim indexes before upgrading the workers. Existing rows retain their original
ownership. Grant or extend history only after every worker has been upgraded;
older workers cannot honor the new retry windows and pacing contract. For long feeds using the inline source executor, configure
`inlineReplayRetention` or supply a durable executor so a year of history does
not exhaust its default 100-slice lifetime scope limit.

For tenant-partitioned jobs, call `runCycle({ accountId })`, or configure
`start({ accountIds: [...] })`. Every planner and worker call receives that
same account boundary. A deployment-owned worker must explicitly pass
`deploymentWide: true`; use that form only when one trusted service instance is
authorized for every account in the store. Widening is reachable only through
that opt-in: a cycle with a missing, empty, or overlong `accountId` is refused
rather than silently promoted to a deployment-wide scan. Under `accountIds`,
one account's failed cycle is reported to `onError` and the remaining accounts
still run, so a persistently failing tenant cannot starve the tenants behind
it. Planning is resumable and bounded;
set `maxObligationsPerAccount` and `maxWorkerIterationsPerAccount` for tighter
operational limits. `stop()` aborts current source work, waits for settlement,
and wakes a sleeping scheduler immediately. Planning is a bounded ledger
operation rather than abortable source I/O, so shutdown waits for an in-flight
planning pass to settle and does not begin its worker afterward.

Run `runReliableReportingServiceConformanceV1` against an isolated test ledger
before deployment. It covers source replay, two-account isolation,
configuration replay/frozen currency, lifecycle start/stop, and Core
capability truthfulness.

### Principal-level reporting subscriptions (experimental, AdCP 3.3)

The [seller guide](REPORTING-SUBSCRIPTIONS-SELLER.md) walks through this path end to end.

**The managed block (start here).** Add a `subscriptions` block to the service. With `storage`, pass
`principal` (the principal runtime's options) and the service builds the runtime over
`storage.principals` (serve it with `protocol: service.principals.protocol`); or pass the principal
runtime your server already serves `get_principal`/`sync_principal` with as `principals`, created
without `reportingSubscriptions`. The service builds the coverage engine, installs the
`reporting_subscriptions` section on that runtime, advertises the principal capability in
`install()`, reconciles a principal after each `sync_principal` write that submits
subscriptions, and sweeps each subscribed principal that is due (a period boundary passed, its last
reconcile failed, a grant change was pushed, or an hour elapsed) at the start of each `runCycle`:

```ts
const service = createReliableReportingService({
  storage, // postgresStorage({ pool }); engine state and principal records live here too
  // ...adapters, resolveSource, resolveCurrency, resolveCoverage as above
  subscriptions: {
    principal: { notifications, agentUrl, resolvePrincipal }, // or principals: your runtime
    maxAccounts: 500,
    // Optional: without it each generation is derived from its source offering. Required for billing.
    configure: ({ subscription, offering }) => ({
      requestedMetrics: metricsFor(offering.report_definition_id),
      requestedDimensions: dimensionsFor(offering.report_definition_id),
      sourceSettings: settingsFor(offering.offering_id),
    }),
  },
});
const platform = service.install(myPlatform); // capabilities.principal is filled in
const server = createAdcpServerFromPlatform(platform, { ...serverOptions, protocol: service.principals!.protocol });
```

The roster comes from the platform's `accounts.list` and the buys from `sales.getMediaBuys`, read
under the principal's identity (a non-secret snapshot of its last authenticated request, never a
token). Override either with `subscriptions.accounts` / `subscriptions.buys` when access depends on
a live upstream credential; a roster the service cannot read is a `PlatformConfigError` coded
`SUBSCRIPTION_ROSTER_UNAVAILABLE`. Reconcile and planning failures never reject a cycle:
`runCycle` returns them in `subscriptionPlanningFailures`, and `planningErrorHandler` hears each.

**`authorized_at` comes from one journal.** With the managed block the service keeps the grant
journal and is the only source of `authorization.authorized_at`. It serves the journal's value on
`list_accounts` and `sync_accounts` to callers holding subscriptions, so the value a buyer reads is
the value coverage uses. A host value is adopted the first time a chain is observed; an omitted one
is stamped. A value that moves an open chain earlier is refused and logged as
`authorized_at_regressed`. A re-grant inside `status_retention_days` continues the chain; a later
one starts a new one. Never compute the chain yourself. Sellers whose entitlement service emits
events push them for an exact instant:

```ts
await service.grants!.changed({ principal, accountId: 'acc_1', at, authorized: false });
await service.grants!.changed({ principal, accountId: 'acc_1', at, authorized: true, allowedTasks });
```

Later listings must agree with what was pushed. `resolveRevocationInstant` is optional on the
engine: without it a revocation is dated when it was observed.

The advanced block below, with your own `engine`, is rung 3.

With `subscriptions` (formerly `reportingSubscriptions`, kept as a deprecated
alias), every `runCycle` first writes the subscription
engine's frozen owed sets into the ledger, then plans account configurations as
before, and the worker executes both.

The coverage engine, its stores, the coverage function, the calendar, offering
selection, the capability builder and the type of this option are low-level
building blocks. They import from `@adcp/sdk/reporting/advanced`, where every
export is `@experimental`; `@adcp/sdk/reporting/service`, `/consumer`, `/ledger`
and the package root no longer re-export them.

```ts
import { createReliableReportingService } from '@adcp/sdk/reporting/service';
import {
  createReportingSubscriptionEngineV1,
  createReportingSubscriptionEngineStateStoreV1,
} from '@adcp/sdk/reporting/advanced';

const service = createReliableReportingService({
  // ...store, adapters, resolveSource, resolveCurrency, resolveCoverage as above
  subscriptions: {
    engine, // createReportingSubscriptionEngineV1(...)
    resolvePrincipal: ctx => principalScopeFrom(ctx), // the principal runtime's mapping
    listSubscriptionPrincipals: async () =>
      (await Promise.all(tenantIds.map(tenantId => engine.listSubscriptionPrincipals(tenantId)))).flat(),
    // Seller policy for one (subscription version, resolved offering): the facts a
    // sync_accounts mapping also supplies to installConfiguration.
    resolveSubscriptionConfiguration: ({ subscription, offering }) => ({
      requestedMetrics: metricsFor(offering.report_definition_id),
      requestedDimensions: dimensionsFor(offering.report_definition_id),
      sourceSettings: settingsFor(offering.offering_id),
      // finalityPolicy for an official subscription, canonicalization for billing
    }),
  },
});
```

- **One generation per (account, owning principal, `subscription_id`,
  `subscription_version`, resolved `offering_id`).** Its `delivery_config_id`
  is the `subscription_id` and its `delivery_config_version` the
  `subscription_version`. Subscription ids are unique per principal, so two
  principals can both own `analytics-daily` on one account. The generation
  carries an immutable `subscription` block; account generations keep exactly
  their previous ids and fingerprints.
- **Sparse, never grid-filled.** Each obligation is one owed period with its own
  `media_buy_ids` frozen at its `scope_resolved_at` (the period end) and the
  host-authorized constituents of exactly those buys from `resolveCoverage`. Its
  `periodOrdinal` is the period start in whole seconds. The offering is
  authoritative for timing: `expected_at` is the period end plus its
  `delivery_sla`, and obligations carry `offering_id`.
- **Completeness is a horizon.** Only periods the engine has frozen are written,
  and the generation's mutable `owedSet.through` advances after they are
  durable. A gap is a period that is not owed, never a continuity error. A scope
  ending after the horizon reports `scope_closed: false` and keeps
  `coverage_complete: true`.
- **Caller isolation.** `get_reporting_status`, `get_media_buy_delivery` and
  `sync_reporting_status` show a principal the account configurations plus only
  its own subscription generations. `sync_reporting_status` accepts a status
  without `reporting_obligation_id` against a subscription only for an existing
  owed obligation.
- **Failures are isolated per subscription.** One subscription that cannot be
  planned never stops another or the account's own configurations; it is passed
  to `onPlanningError`, or `runCycle` rejects with an `AggregateError` after the
  rest of the cycle has run.

A custom `ReportingLedgerStore` holds subscription generations only when it
implements `recordOwedSetProgress` (and should implement
`findObligationByOrdinal`), keys generations by
`reportingLedgerSubscriptionKeyV1`, and applies `subscription_principal` to every
snapshot. For PostgreSQL, reapply `REPORTING_LEDGER_MIGRATION`: it adds
`adcp_reporting_configurations.subscription_key` (empty for every existing row)
and replaces the three-column generation constraint with a unique index on
`(account_id, delivery_config_id, delivery_config_version, subscription_key)`.

**Managed delivery of subscriptions.** A subscription with a `destination`
resolves only managed offerings. Serve it with
`createPostgresReliableReportingProductionService` and pass the principal
runtime as `subscriptions.principal`. The engine must have
`isAuthorized`. Then:

- Before a managed generation's first obligation is written, the service binds
  it to the owner's destination. The version's `destination.destination_id`
  names the destination, and the binding uses that destination's current
  generation (its `destination_ref`). The destination must be delivery-eligible
  and serve the offering's pattern and transport.
- One destination serves every covered account, so each account gets its own
  authorization of that `destination_ref`.
- A destination that is not ready rejects the bind, and the obligations wait
  for a later cycle instead of becoming undeliverable.
- Bindings are keyed by their Core configuration, so every (owner, offering)
  generation of one version gets its own. Reapply
  `REPORTING_MANAGED_DELIVERY_MIGRATION` to drop the three-column binding key.
- The binding freezes the version's `path_template`. Each delivery expands it
  per obligation and passes the result to the adapter as `delivery_path`.
  Object-store writes place it inside the collision-free generation prefix:
  `adcp-reporting/{namespace_key}/{scope_key}/{delivery_path}/{plan_id}/{index}`.
- Every row of a subscription revision carries `account_id`. The producer stamps
  it before the revision is bound, so the committed digest covers it, and it
  refuses a row that names another account.
- The managed worker re-checks `engine.isAuthorized(owner, account)` before
  delivering and again before settling. A lost grant releases the claim with
  `holdMaterialization` without spending an attempt: the obligation stays
  owed, and the engine reports the loss in `accounts_unauthorized`.
- Status subscribers with a `principal`, and notification activity, carry a
  subscription obligation's transitions only to its owner.

**Receipts, statuses and grants.** A subscription obligation accepts
`sync_reporting_receipts` and `sync_reporting_status` only from its owning
principal (`reportingSubscriptionReceiptAdmissibleV1`, the one rule). Account
obligations stay open to every consumer of the account. This applies on top of
the host's own account resolution and `allowed_tasks` checks.

**To end a relationship, wind down; don't revoke.** Revocation means no access
(adcp#8607): there is no post-revocation window. Once authority for an account
ends, the account is unknown to every task, receipts and statuses included, and
the principal's subscriptions stop covering it, so final revisions and
adjustments for its buys never reach it. Revoke only for fraud or a compromise.
A seller that wants a buyer to finish reconciling, for example after an agency
change, replaces the grant with `windDownGrant()` from `@adcp/sdk/server`:

```ts
import { windDownGrant, REPORTING_WIND_DOWN_TASKS } from '@adcp/sdk/server';

// allowed_tasks: get_reporting_status, sync_reporting_receipts, sync_reporting_status; read_only: false.
// Passing the current grant keeps its authorized_at: a reduced grant continues the chain.
account.authorization = windDownGrant(account.authorization);
```

Your account resolver must then refuse every task outside
`REPORTING_WIND_DOWN_TASKS` for that principal, as it does for any grant.

The engine counts an account as covered only while its grant lists
`get_reporting_status` (`reportingSubscriptionCoverageGrantedV1`; a grant with
no task restriction counts as all tasks). Report the grant's
`authorization.allowed_tasks` on each `listAuthorizedAccounts` fact, or on
`authorizationChanged`. Dropping `get_reporting_status` ends coverage at that
instant, as a loss of authority with an `accounts_unauthorized` entry.

The obligated-consumer roster stays host-owned, because it is keyed by consumer
id. Include a subscription obligation's owner in it while the owner's grant
lists the receipt task.

## Advanced: assemble the primitives directly

```ts
import { Pool } from 'pg';
import { PostgresReportingLedgerStore, sweepExpiredReportingLedgerState } from '@adcp/reporting-storage';
import {
  createReportingDeliveryHandler,
  createReportingProducer,
  createReportingStatusHandler,
  createSyncReportingStatusHandler,
  type ReportingConsumerStatusLedgerStore,
} from '@adcp/sdk/reporting/ledger';

const pool = new Pool({ connectionString: process.env.DATABASE_URL }); // after `npx adcp-reporting-storage migrate`

const store = new PostgresReportingLedgerStore(pool, {
  acknowledgeIsolatedDatabase: true,
});
const producer = createReportingProducer({
  store,
  source,
  offerings,
  contact: { name: 'Reporting operations', email: 'reporting@example.invalid' },
});

const getReportingStatus = createReportingStatusHandler(store);
const getMediaBuyDelivery = createReportingDeliveryHandler(store);

// Run periodically from one or more bounded maintenance workers.
await sweepExpiredReportingLedgerState(pool);
```

Pass `getReportingStatus` and `getMediaBuyDelivery` directly to the matching `createAdcpServer` slots. The delivery helper serves only exact `reporting_revision_id` reads and returns the row payload bound by the ledger revision. Both handlers take `pagination.max_results` as AdCP defines it, from `core/pagination-request.json`: an integer from 1 to 100, 50 when omitted. Any other value (and a `pagination` that is not an object or a `cursor` that is not a string) is refused with `VALIDATION_ERROR` (`field: 'pagination.max_results'`, `'pagination'` or `'pagination.cursor'`) before the ledger is read, so the same request behaves the same on every seller; page with `pagination.cursor`. The buyer-side walkers ask for the schema maximum, 100. Advertise `media_buy.reporting_delivery` in `experimental_features` together with a `media_buy.reporting_delivery` capability whose Reliable Reporting version is `1.0` only after both handlers are wired. Configure account resolution on the server: both handlers require the framework-resolved, caller-scoped account identity and never trust a request-body identity as an authorization boundary. If two callers can name the same upstream account, the resolver must issue distinct internal account IDs for their ledger namespaces. Install immutable delivery-configuration generations through `producer.installConfiguration`, call `planObligations()` after period close, and run `runWorker()` from a durable scheduler. Multiple workers are safe: PostgreSQL claims use `SKIP LOCKED`, expiring leases, and fencing generations.

The planner supports fixed millisecond schedules and an explicit source-calendar
day schedule. For the latter, set the existing schedule identity fields to
`periodDuration: 'P1D'`, `alignment: 'source_timezone'`, and
`periodTimezone: sourceTimezone`, with an IANA timezone and a source-local
midnight `anchor`. Keep `periodMilliseconds: 86_400_000` as the nominal day;
it does not determine the elapsed width on this path. Boundaries are resolved
independently from local 1970-01-01 and their civil-day ordinal, so New York's
spring and fall days span 23 and 25 hours. Where a DST gap swallows local
midnight (America/Santiago, America/Havana, Africa/Cairo), the day starts at
the instant midnight advances to, as `core/reporting-schedule.json`
`period_generation` defines it, and the source is still asked for that one
local date. The service fills these identity
fields from its delivery offering; callers of the producer directly must supply
them explicitly. `PT24H` continues to mean an elapsed 24 hours.

The new calendar path supports a fixed-time SLA, for example
`deliverySlaDuration: 'PT4H'` with `deliverySlaMilliseconds: 14_400_000`.
The deadline is the resolved period end plus that elapsed duration. Source
window bounds, local-day representability and authoritative finalization
must remain feasible; installation checks the operational 400-day horizon,
and planning checks each actual period's intrinsic calendar boundaries.
An elapsed `PT24H` source window cannot stand in for a calendar `P1D` window
across DST. Other calendar durations, calendar SLAs and billing-cycle expansion
remain seller responsibilities; this adds no Temporal dependency.

Whole skipped civil dates, such as Apia's 2011-12-30, have no representable
boundary. Requesting that ordinal refuses instead of aliasing the next date or
renumbering later ordinals. Valid neighboring boundary lookups keep their
identities. A floor lookup identifies a representable start; it does not certify
the next endpoint. Ceil inside the preceding day refuses its missing endpoint,
and every interval used for planning, coverage, status eligibility or deadline
projection must have both representable boundaries and span exactly one
source-local date. Ordinary midnight gap/fold point resolution is unchanged.
Source feasibility is an acceptance-time fact. Withdrawing or changing the
process-local offering later does not suppress an elapsed obligation: the
planner commits it independently, and an unavailable source proceeds through
the normal seller-responsible production issue and `action_required` path.

Existing numeric schedules and immutable generation replays are preserved. A
calendar generation has a distinct semantic fingerprint even when its current
boundaries equal an elapsed grid. The fingerprint binds the runtime's canonical
IANA timezone, tzdb version and ICU version; every resolver fails closed if the
host no longer matches those frozen rules. Use a mixed-replica handoff for a
runtime/tzdata upgrade: keep an old-runtime replica active, upgrade another
replica, and install the successor from the new replica so it freezes the new
rules. The new replica fails closed on planning until every period the
predecessor owns is frozen. Meanwhile the old replica continues to resolve the
predecessor and skips the foreign-rule successor. A mid-period cutover belongs
to the predecessor, so the old replica must plan its straddling period after
that period closes; an exact-boundary cutover has no straddler. Once that drain
completes, retire the old replica and let the new one plan the successor. The
generation persists its old-rules first-owned ordinal and boundary. Planning
seals a mismatched predecessor only when contiguous durable obligations from
that boundary reach the handoff, or when the handoff precedes the boundary and
the generation owns no periods. The new host never recomputes the ownership
range as proof, and a missing edge or interior ordinal still fails closed. This keeps
historical reads and the successor usable without letting mixed replicas derive
different periods. The PostgreSQL store also fences one obligation per
configuration and civil ordinal, independently of its resolved timestamps.
The SDK refuses to reinterpret an old fixed-period
generation whose optional labels would now imply different civil boundaries;
install an explicit new configuration version before the boundaries diverge.
The same guard applies if a later timezone database changes a previously fixed
grid. Every finite legacy floor/ceil lookup, including instants before
installation or the anchor, must retain its numeric ordinal and enclosing
period boundaries or require a new generation. Authored obligations are never
rewritten to migrate a schedule.

At period end, the obligation freezes the constituent denominator and coverage.
A zero-row source object commits like any other revision. Absence remains an
empty revision association. A deployment with per-tenant workers should pass
the resolved `account_id` to both `planObligations()` and `runWorker()`;
omitting it intentionally runs a deployment-wide worker.

### Already running your own ledger tables?

Do not dual-write, and do not migrate data. Cut over at a period boundary: the
SDK ledger produces and serves new periods, and your old tables become
read-only behind the optional `legacyRevisionReader`, which answers exact
`get_media_buy_delivery` reads only for revisions the SDK ledger does not hold.
See [Cutting over to the SDK reporting ledger](REPORTING-LEDGER-CUTOVER.md).

### Migrating an existing manual lifecycle

Keep the same `PostgresReportingLedgerStore` and run the same
`REPORTING_LEDGER_MIGRATION`; there is no second store and no data migration.
Move each inline fetch plus its source/delivery offering into an entry in
`adapters`, move account routing and currency lookup into the two trusted
resolvers, and replace manual producer/handler/capability assembly with
`reporting.install(platform)`. Replace cron calls to `planObligations` and
`runWorker` with `runCycle` or `start`. Remove manual reporting capability
overrides so discovery has one owner. Existing configuration IDs and semantic
fingerprints remain compatible because the service delegates installation to
the existing producer: replaying a generation that predates the reserved
adapter route key reuses its stored `sourceScope` verbatim, so the fingerprint
still matches and the replay does not trip generation immutability. Only new
generations carry the reserved key. With one installed adapter, pre-service
obligations without the reserved adapter route continue through that sole
adapter. A
multi-adapter migration must create a new immutable configuration generation
with an explicit route. An adapter supplies exactly one of `fetchSlice` or
`executor`: `fetchSlice` is the inline boundary, and `executor` accepts any
`ReportingSourceWithReaderV1` — including a paginated, asynchronous, or
externally staged one — so a custom executor that needs those capabilities
runs under the service today rather than waiting for a future extension. The
inline-only knob `inlineReplayRetention` applies to `fetchSlice` adapters and
is ignored by an adapter that brings its own executor.

`reporting.install(platform)` mutates that platform object in place and
requires it to be extensible; this preserves class instances and private-field
methods that a shallow wrapper would break. It also requires the platform's
native `accounts.upsert` seam. The service cannot truthfully advertise `configuration_task:
sync_accounts` without it. That account method remains responsible for mapping
an authorized wire reporting configuration to the service's resolved input and
calling `installConfiguration`; the service does not claim a generic mapping
that the current protocol does not define.

Official configurations also pin a `finalityPolicy` (`policyId` plus `source_final` or `contractual_cutoff`). For `source_final`, set `sourceSignal` to the exact opaque signal identifier the adapter places in the manifest finality evidence's `evidenceRef`; the worker requires an exact match before irreversible official publication. Protocol `expected_at` is always period end plus the wire `delivery_sla`, including for official generations. The service also refuses a private `officialAfterMilliseconds` cutoff that disagrees with the offering's advertised `schedule.delivery_sla`; that source-finality boundary never replaces the public obligation clock.

Every revision stores its rows together with an RFC 8785 JCS SHA-256 binding and exact decimal control totals for requested numeric metrics. A revision number and obligation are immutable. Official revisions are terminal; later source corrections are immutable adjustments bound to the official revision, never superseding revisions. Status snapshots omit row payloads, are capped at 8 MiB, expire after 15 minutes, and keep cursor pages stable over the flat obligation/revision/adjustment union. A periods response returns an opaque `changes_checkpoint`; echo that value verbatim as `changes_after` rather than supplying a timestamp. Account-scoped write/snapshot locks make those checkpoints gap-free for SDK store writes. The default table set is deployment-wide; use a dedicated database/schema and acknowledge that boundary explicitly. `sourceScope` must contain opaque routing identities only—never credentials or bearer tokens—because it is retained with the obligation. Retained resource locations are held to the same rule, and at the seam that persists them rather than only in the worker's pre-flight, because a caller driving `settleMaterialization` directly would otherwise store a presigned location that `get_reporting_status` then publishes. Query and fragment are refused on the raw string rather than on a successful parse, because a relative path carrying a presigning query never parsed as a URL at all; userinfo is refused as a colon-separated pair before the `@`, which is the credential shape, plus any `http(s)` userinfo at all. A blanket `@` rule would refuse `abfss://container@account.dfs.core.windows.net/...` and a Snowflake stage reference, neither of which carries a secret.

## Row storage

By default every revision document carries its rows inline. At pulse cadence
that keeps bulk report bytes in the transactional database. Opt in to row
storage to keep only the revision header in the ledger document and store
rows as verified canonical JSONL chunks (the shared SDK persistence layout,
adcontextprotocol/adcp#7996):

```ts
// `npx adcp-reporting-storage migrate` installs the row-storage tables (version 0004, PostgreSQL 13+).
const store = new PostgresReportingLedgerStore(pool, {
  acknowledgeIsolatedDatabase: true,
  rowStorage: true,
});
await store.readyRowStorage();
```

`createPostgresReliableReportingProductionService` accepts the same
`rowStorage` option and adds the migration to `setup.migrations`.

- Rows are split into 500-row segments and chunks of at most 10,000 rows or
  8 MiB. Chunk, segment and manifest digests are committed with the revision,
  and every read is verified before rows are released. Delivery pages read only
  the segments they need.
- A revision whose rows are byte-identical to a live row set in the same
  obligation is stored as a header-only revision. It gets a new identity,
  freshness and binding, and references the existing chunks
  (`rows_shared_from_row_set_id`), so an unchanged pulse uploads nothing.
- Revisions written before you enable row storage keep their inline rows.
  Reads handle both forms whether or not the option is set.
- Missing or corrupt rows inside the retention window make
  `get_media_buy_delivery` fail with `SERVICE_UNAVAILABLE` rather than reporting
  the revision as absent; expired rows read like an unknown revision.
- An exact `get_media_buy_delivery` read of an unknown, unauthorized, expired or
  compacted revision, or with a tampered `pagination.cursor`, returns the same
  nondisclosing `REFERENCE_NOT_FOUND` with `field: "reporting_revision_id"`
  (not transient, so buyers do not retry), so a response never reveals whether a
  revision exists for another account.
- Managed Delivery claims hydrate PostgreSQL-stored rows automatically.

To move existing inline rows into row storage, run the resumable migration in
bounded batches. A revision whose rows do not reproduce its committed binding is
reported in `quarantined` and left untouched:

```ts
let cursor: string | undefined;
do {
  const batch = await store.migrateInlineRows({ limit: 100, cursor });
  if (batch.quarantined.length) console.warn('unverifiable inline rows', batch.quarantined);
  cursor = batch.cursor;
} while (cursor);
```

Removing rows from ledger documents frees space only after `VACUUM FULL` or an
online repack of `adcp_reporting_revisions` and `adcp_reporting_adjustments`.

### Stored field names

Stored values use AdCP's names and bounds: a chunk's `object_ref` and
`native_version_ref` (1 to 1024 characters each, enforced by `CHECK`
constraints), `size_bytes` (the stored object's size after compression, as in
the AdCP file manifest), and `canonical_size_bytes` (the uncompressed canonical
bytes that the chunk digests cover; a row set's `content_size_bytes` is the
byte count of the content its `content_sha256` covers). A row set records `format` (`jsonl`) and
`algorithm` (`adcp_jcs_rows_v1`). Neither token feeds a digest. Installed
databases upgrade in place when you re-apply `REPORTING_ROW_STORAGE_MIGRATION`;
see [Breaking: reporting row storage field alignment](../migration-reporting-row-storage-alignment.md)
for the old names, the API renames and the re-sync option.

### Object storage bindings

Rows can live in object storage instead of PostgreSQL. A binding is defined in
host code, which makes the configuration the allowlist: the database records
which binding each revision used and its identity digest, but it can never
point reads or writes at a destination the host did not configure.

```ts
import {
  PostgresReportingLedgerStore,
  createFilesystemReportingRowObjectProviderV1,
} from '@adcp/reporting-storage';

const store = new PostgresReportingLedgerStore(pool, {
  acknowledgeIsolatedDatabase: true,
  rowStorage: {
    deploymentNamespace: 'prod-us',
    bindings: {
      inline: { kind: 'postgres' },
      reports: {
        kind: 'object',
        provider: 'filesystem', // or a cloud provider registered below
        location: { root: 'reports' },
        prefix: 'adcp-rows',
        compression: 'gzip',
      },
    },
    providers: {
      filesystem: createFilesystemReportingRowObjectProviderV1({ roots: { reports: '/var/lib/adcp/rows' } }),
    },
    selectRowBinding: ({ content_size_bytes }) => (content_size_bytes < 256 * 1024 ? 'inline' : 'reports'),
  },
});
await store.readyRowStorage();
```

- A binding ID (the key in `bindings`) is 1 to 255 characters of `A-Za-z0-9_.:-`, the
  AdCP identifier bound that `reporting_revision_id`, `resource_ref` and `destination_ref` use, so an ID
  derived from an AdCP destination reference fits. The same bound applies to a binding's `credentialRef`
  and to the keys of a provider's `clients` map. Both limits were 128 before migration `0010`; the
  `adcp_reporting_row_bindings` `CHECK` is widened by migration `0010`. The bound is exported as
  `REPORTING_ROW_BINDING_ID_MAX_LENGTH` and `REPORTING_ROW_CREDENTIAL_REF_MAX_LENGTH`.
- Each chunk is one object, written create-only. If an object already exists at
  a planned key, it is adopted only when its bytes decode to the exact chunk;
  otherwise the commit fails with `CONTENT_CONFLICT`.
- Keys always start with `{prefix}/{namespace_key}/` and use a hashed account
  segment, never a raw account ID. Override `keyTemplate` with the placeholders
  in `REPORTING_ROW_KEY_PLACEHOLDERS`; templates must include
  `{content_sha256}`, `{chunk_index}` and `{revision_key}`. `{revision_key}` is
  required on every writable binding, so each row set writes its own object
  keys (it hashes the row-set ID, so two uploads never name the same key). The store refuses a
  template without it when it is configured and again in `readyRowStorage`,
  with `INVALID_INPUT`.
  `{period_date}` renders AdCP's `YYYY-MM-DD`: the calendar date of the period
  start in the period's `source_timezone`, never UTC (a period starting
  `2026-10-02T07:00:00Z` in `America/Los_Angeles` is `2026-10-02`; one starting
  `2026-10-01T15:00:00Z` in `Asia/Tokyo` is also `2026-10-02`). It is one path
  segment, so the default layout is
  `{prefix}/{namespace_key}/{account_key}/2026-10-02/{finality}/...`, not
  `2026/10/02/`. A missing, unknown or non-IANA timezone fails the write with
  `INVALID_INPUT` rather than guessing a date. The rendered key must stay within
  AdCP's 1024-character `object_ref` bound.
- Rows written under an older template without `{revision_key}` stay readable:
  every read uses the chunk's recorded `object_ref`, never a re-rendered key.
  Changing a template needs a new binding ID, and the old definition must stay
  configured while revisions reference it. Mark that old definition
  `readOnly: true` to keep it configured without `{revision_key}`: it is
  exempt from the requirement, never selected for new writes, and still used
  for reads and retirement. A read-only binding is still registered and
  probed by `readyRowStorage`, so keep its location reachable (and keep
  enforcing `readOnly` in every process that shares the database: it is not
  stored).
- Header-only revisions share their predecessor's chunks within an obligation,
  and chunk rows written under an older template can name one object from
  several row sets. Every delete path (period retirement, compaction and the
  intent sweep) therefore skips an object while a live row set outside the
  operation still references the same binding, key and native version, or an
  open write intent created it. With unique keys, a create-only write only
  finds an existing object when a writer retries the same row set.
- **Object deletes and commits take no per-object lock, with one exception.**
  Retirement, compaction and the intent sweep run the reference check as a
  plain query, then delete the exact native version, holding no transaction or
  pooled connection across the provider call. They are safe without a lock
  because of five fences, none of which is the lock:
  1. Every writable key includes `{revision_key}` (a SHA-256 of the row set ID)
     and `{content_sha256}`, so one row set alone can ever name a key through a
     writable binding. A committed row set is replayed: a late writer that
     passed the replay check can adopt its just-committed object, but its
     commit inserts nothing (the row set exists), so it cannot reference an
     object a retirement or compaction then deletes. A `readOnly` binding's old
     template can map several row sets to one object, but nothing adopts through
     it; there the reference check and fence 4 are the whole argument. Bindings
     that share one bucket and prefix must route a row set to one binding across
     attempts, because the reference check is per binding (the orphan collector
     checks every binding).
  2. A header-only revision's commit holds the account lock and `FOR SHARE`-locks
     a predecessor that must still be `live`. Retirement and compaction mark a
     row set `pruning` under the same account lock before they delete anything,
     and a `pruning` row set neither counts as a reference nor can be shared. So
     a sharer commits first (its chunk rows then make the delete skip) or fails
     with `STATE_UNAVAILABLE` and re-uploads under its own key.
  3. The intent sweep moves an expired `open` intent to `sweeping` under the
     account lock; a writer closes that intent, still `open`, in the commit
     transaction that inserts its chunk rows. Exactly one wins, so a writer past
     its lease cannot commit objects the sweep deletes, and a retry cannot take
     over an intent being swept. A takeover renews the expiry, so the sweep
     cannot claim it.
  4. Concurrent retirements and compactions count only row sets that are not
     `pruning`, each after committing its own `pruning` state, so at least one
     of any two deletes a shared object and none can both skip it.
  5. Deletes name an exact native version, so one cannot remove an object
     re-created at the same key. This needs write-unique native versions, a
     provider requirement the conformance check `write-unique-version` tests.

  The advisory lock `adcp-reporting-object:{binding_id}:{object_ref}` stays in
  two places that pair with each other, because nothing else orders them. A
  commit that adopts an object its own intent did not record (an earlier
  attempt's `PUT` landed before the intent recorded it, or a writer created it
  after a takeover) takes the lock, in key order, before it proves the object with
  a version-pinned `stat`, and holds it until its chunk rows commit. An object its own intent recorded takes
  no lock: until the transaction commits, the open intent names it. The orphan
  collector deletes only objects no record names, so each of its deletes takes
  the lock of every binding (they can share a bucket and prefix), repeats the
  reference check under it, and then deletes. A collector that wins makes the
  adopting commit fail its version-pinned `stat` with `STATE_UNAVAILABLE` (the
  writer re-uploads once its intent lapses); a commit that wins is seen by the
  collector, which skips. The collector's clone fence is a separate protection:
  an advisory lock is per database and cannot order a clone against the
  original. A skipped object is deleted by the retirement, compaction or sweep
  of the last row set that referenced it, so it is not leaked.
- **Cross-SDK contract.** A ledger database has one writer SDK (the design record's
  §5), so the Python and JavaScript SDKs need not agree on a lock to coexist; this
  is the intended contract for both, with the same key text. The Python side
  (adcp-client-python#1492) mirrors it: (1) the delete paths above take no object lock; (2) the key text
  is `adcp-reporting-object:` + binding ID + `:` + object ref, hashed with
  `hashtextextended(text, 0)` for `pg_advisory_xact_lock`; (3) an adopting commit
  locks only adopted objects absent from its own intent's `created_objects`
  (matching on object ref and native version), in object-ref order, after the
  account lock and after closing its intent, then proves each adopted object with
  a version-pinned `stat`; (4) the orphan collector locks every binding's key for
  the object, sorted by binding ID, in the transaction that repeats the
  reference check and deletes. Lock order is account lock, then object locks.
- An upload runs only while the obligation lease still covers
  `writeDeadlineMilliseconds` plus five seconds. A fenced write intent records
  every object the upload created, and the ledger commit closes the intent in
  the same transaction. Objects of an upload that never committed are left for
  the intent sweep.
- Every read verifies the stored bytes against the recorded physical digest
  before decompressing, then verifies segments, chunks and the revision binding.
- Keep a retired binding configured while revisions still reference it.
- The filesystem provider identifies each write by inode, birth time, mtime
  and size, stamping a random sub-millisecond mtime on every write. It needs a
  filesystem with sub-second mtime and, ideally, birth time (ext4, XFS, APFS,
  NTFS). On a coarse filesystem (FAT, some NFS mounts, ext3), a reused inode
  re-created with identical bytes in the same second gets the same version,
  so a delayed delete could remove the replacement. The conformance check
  `write-unique-version` fails on such filesystems. That failure means the
  filesystem is wrong, not the code.
- Custom providers implement `ReportingRowObjectProviderV1`. Run
  `runReportingRowObjectProviderConformanceV1(provider, { location, prefix })`
  against a dedicated test prefix before using one. Provider calls take and
  return AdCP's names: `objectRef` (the decoded, destination-relative object
  key) and `nativeVersionRef` (the decoded provider-native version), each 1 to
  1024 characters. Implement the optional `stat({ objectRef, nativeVersionRef })`,
  which returns `{ sizeBytes }` for that exact version or `null` when it is
  absent, without reading the body. The commit transaction uses it to prove an
  adopted object is unchanged (native versions are write-unique, so the same
  version at the recorded size is the same bytes) instead of downloading it
  while holding the account lock. A provider without `stat` falls
  back to reading the whole object there. All bundled providers implement it.
  Also implement the optional `list({ prefix, pageToken, pageSize })`, which
  returns `{ objects: [{ objectRef, nativeVersionRef, sizeBytes, createdAt }],
  nextPageToken? }`: every stored version under the prefix once, in a stable
  order (on a versioned store, noncurrent versions too, never delete markers),
  with the version exactly as `putIfAbsent` recorded it and the time it was
  written. The orphan collector needs it; a binding whose provider has no `list`
  is reported as unsupported there. The conformance suite checks it (`list`) when
  present. All bundled providers implement it.

#### Cloud providers

Cloud providers wrap official clients that the host constructs with its own
credentials. A binding's `location` holds only non-secret coordinates, and its
optional `credentialRef` names one of the clients you injected; an unknown
reference fails `UNSAFE_BINDING`. Provider errors surface only as stable
`ReportingRowStoreError` codes. Row buckets are separate from Managed Delivery
buckets.

**Google Cloud Storage** (`@adcp/reporting-storage/gcs`, optional peer
`@google-cloud/storage`):

```ts
import { Storage } from '@google-cloud/storage';
import { createGcsReportingRowObjectProviderV1 } from '@adcp/reporting-storage/gcs';

const gcs = createGcsReportingRowObjectProviderV1({
  storage: new Storage(), // keyless credentials (workload identity / ADC)
  clients: { 'tenant-eu': euStorage }, // optional, selected by credentialRef
});
// binding: { kind: 'object', provider: 'gcs', location: { bucket: 'acme-adcp-rows' }, prefix: 'adcp-rows' }
// providers: { gcs }
```

- Writes are single-request uploads with `ifGenerationMatch: 0` and a declared
  MD5, without `Content-Encoding`. The recorded native version is the object
  generation; reads and deletes pin it, and reads never transcode.
- The probe requires uniform bucket-level access and enforced public access
  prevention. Versioning, soft delete and retention policies are allowed. A
  lifecycle `Delete` rule that can match live objects under the binding prefix
  (no `matchesPrefix`, or a prefix that overlaps it) is refused; rules limited
  to noncurrent versions (`isLive: false`, `numNewerVersions`,
  `daysSinceNoncurrentTime`, `noncurrentTimeBefore`) are allowed. Keep
  retention-driven deletion in the ledger's pruning, not in bucket lifecycle.
- The client needs `storage.buckets.get` for the probe plus object create, get
  and delete on the bucket.

**Amazon S3 and S3-compatible stores** (`@adcp/reporting-storage/s3`, optional peer
`@aws-sdk/client-s3`):

```ts
import { S3Client } from '@aws-sdk/client-s3';
import { createS3ReportingRowObjectProviderV1 } from '@adcp/reporting-storage/s3';

const s3 = createS3ReportingRowObjectProviderV1({
  client: new S3Client({ region: 'us-east-1' }), // default credential chain
});
// binding: { kind: 'object', provider: 's3', location: { bucket: 'acme-adcp-rows', region: 'us-east-1' }, prefix: 'adcp-rows' }
// providers: { s3 }
```

- Endpoint, region, credentials and path style come only from the client you
  inject; `location` accepts just `bucket` and an optional `region`, which the
  probe checks against the client.
- **Bucket versioning is required.** Writes use `PutObject` with
  `If-None-Match: *` (a 409 is retried once). The recorded native version is
  the write-unique `VersionId`; reads pin it with `VersionId`, and deletes
  confirm the exact version with `HeadObject`, then delete by `VersionId`.
  Deletes must be fenced to one write, and an ETag identifies content, not a
  write: a delayed delete (for example an intent sweep removing an abandoned
  upload) pinned to an ETag would also remove a replacement object later
  re-created with identical bytes at the same key. The probe therefore refuses
  any bucket whose `GetBucketVersioning` status is not `Enabled` (suspended or
  unversioned), and `putIfAbsent` refuses a result with no `VersionId`.
  Deleting a specific `VersionId` permanently removes that version without
  leaving a delete marker, so retention still frees storage; noncurrent-version
  lifecycle rules are not needed for rows this provider deletes.
- S3-compatible stores may ignore `If-None-Match`, so the probe writes a probe
  key under the binding prefix twice and requires the second write to fail with
  412, then deletes it. It also refuses missing or inaccessible buckets, a
  bucket policy reported as public, and enabled lifecycle `Expiration` rules
  that can match the prefix. The probe cannot verify Block Public Access on
  every store, so keep row buckets private.
- The client needs `s3:ListBucket` (HeadBucket),
  `s3:GetLifecycleConfiguration`, `s3:GetBucketVersioning`, object put/get,
  `s3:GetObjectVersion` and `s3:DeleteObjectVersion`.
  `s3:GetBucketPolicyStatus` is optional. For stores without flexible
  checksums, construct the client with `requestChecksumCalculation: 'WHEN_REQUIRED'`.

**Azure Blob Storage** (`@adcp/reporting-storage/azure`, optional peer
`@azure/storage-blob`):

```ts
import { DefaultAzureCredential } from '@azure/identity';
import { BlobServiceClient } from '@azure/storage-blob';
import { createAzureBlobReportingRowObjectProviderV1 } from '@adcp/reporting-storage/azure';

const azure = createAzureBlobReportingRowObjectProviderV1({
  client: new BlobServiceClient('https://acmerows.blob.core.windows.net', new DefaultAzureCredential()),
});
// binding: { kind: 'object', provider: 'azure_blob', location: { account: 'acmerows', container: 'adcp-rows' }, prefix: 'adcp-rows' }
// providers: { azure_blob: azure }
```

- `location` names the storage `account` and `container`; the selected client
  must belong to that account. The endpoint and credentials come only from
  the client.
- **Blob versioning is required** on the storage account. Writes are
  block-blob uploads with `If-None-Match: *`. A 409 `BlobAlreadyExists` or 412
  adopts the existing blob. The recorded native version is the write-unique
  `versionId`; reads and deletes pin it, and only count a response that echoes
  that exact version. ETags are content-derived, so they cannot fence a delayed
  delete away from an identical re-upload at the same key. The probe's
  create-only write must return a `versionId` (otherwise `UNSAFE_BINDING`), and
  `putIfAbsent` refuses a result without one. Deleting a specific version
  permanently removes it, so retention still frees storage. Azurite does not
  implement blob versioning and cannot back this provider. Metadata names are
  stored as C# identifiers (`adcp_intent`).
- The probe refuses missing or inaccessible containers and containers with
  anonymous access. Like S3, it proves create-only writes empirically with a
  probe blob under the prefix. Lifecycle management policies are account-level
  and are not visible to the data-plane client, so make sure none can delete
  blobs under the binding prefix.
- The client needs read, write and delete on blobs in the container (for
  example `Storage Blob Data Contributor`), plus permission to delete
  versions.

### Retention

Retention is period-aligned and opt-in. A period becomes eligible once both its
end and its latest publication are older than `max(statusRetentionDays,
recordRetentionDays)`, no worker holds its lease, and no Managed Delivery
materialization still references it. Superseded snapshots stay readable for the
whole window, as the protocol requires.

When the change feed is installed, retention also waits for registered feed
consumers. A period is held while any live consumer (one whose cursor was saved
within `maxFeedHoldDays`, default 7) has not yet passed that period's change
rows, in the consumer's own feed order. This is the same rule `pruneChanges`
uses, so a warehouse sink that is briefly down does not lose revisions it has
not loaded. A held period is simply not retired on this pass. A consumer silent
for longer than `maxFeedHoldDays` stops holding, so a dead consumer cannot block
retention forever; it has then fallen behind retention (see the warehouse sink
below). Pass `maxFeedHoldDays` to `retireExpiredPeriods`; the production service
passes `changeFeed.maxFeedHoldDays` for you so retention and feed pruning agree.

```ts
await store.retireExpiredPeriods({ statusRetentionDays: 30, recordRetentionDays: 45, limit: 100 });
await store.sweepRowWriteIntents({ limit: 100 }); // abandoned object uploads
```

Retirement runs in three resumable phases. First it records a `retiring`
tombstone and marks the period's rows as expired. Then it deletes external row
objects at their recorded versions. Finally it deletes the period's rows and
ledger records together. The tombstone keeps the final revision ID and digest,
and planners never re-create a retired period. `ledger_retained_from` advances
because the retired obligations no longer exist.

A period whose deletes fail (a removed binding, a permanent provider error)
stays `retiring` and is retried with backoff rather than on every pass. The
tombstone records `attempts`, `next_attempt_at` and `last_failure`; the wait
starts at one minute, doubles per failure and is capped at six hours. Periods
still backing off are skipped. Ready retries go ahead of fresh periods for up to
half of each pass (rounded up) and only fill slots fresh periods leave empty, so
a retry backlog still drains at full speed when nothing else is eligible and a
few stuck periods cannot stop others from retiring (each leaves the head of the
queue for its backoff after one failed attempt). The result reports `failed` and `failures` for this pass,
`deferred` for periods backing off, and `stuck` (up to 20, with `attempts` and
`cause`) for periods that have failed five or more times. The maintenance helper
passes `stuck` and `deferred` to `onError`. Re-apply `REPORTING_LEDGER_MIGRATION`
before upgrading; it adds the three tombstone columns idempotently.

`sweepRowWriteIntents` backs off the same way (`sweep_attempts`, `next_sweep_at`,
added idempotently by `REPORTING_ROW_STORAGE_MIGRATION`) and takes intents that
never failed first. An intent with objects to delete through a binding this host
does not configure is left untouched, since a host that configures it can finish
the sweep. The result counts `swept`, `objectsDeleted`, `failed` (this pass),
`skippedUnconfigured`, `deferred` and `overdue`; the last three describe what is
still waiting after the pass. `overdue` counts intents expired for longer than
`overdueAfterSeconds` (default 24 hours): no host is sweeping them and their
objects are leaking, so check that some host configures every binding you have
used.

`createPostgresReliableReportingProductionService` accepts
`retention: { enabled: true, recordRetentionDays?, limit? }`. Its scheduler
always sweeps abandoned row uploads and expired cursor snapshots and
checkpoints, and retires periods when retention is enabled.

### Compacting superseded snapshots (opt-in)

> **Do not enable this in production before the next eligible AdCP minor after
> November 20, 2026.** Until then the published protocol still describes
> superseded snapshots as preserved. The option is off by default, and
> retaining the whole chain, as the ledger does by default, stays conformant.

[adcontextprotocol/adcp#8100](https://github.com/adcontextprotocol/adcp/pull/8100)
separates the two things `status_retention_days` covers. **Metadata** for every
revision stays queryable for the whole window. **Content** (the rows) is owed
only for the revisions a buyer is likely to read, so a seller that publishes a
snapshot every 15 minutes need not keep thousands of full snapshots per period.

The window runs from the revision's `created_at`. Once a later revision names it
in `supersedes_reporting_revision_id`, it runs from that successor's
`created_at` instead. Within its window the seller must keep content readable
by exact read when the revision is:

- (a) the current, unsuperseded revision of its slice, which includes every
  official revision;
- (b) the revision the current revision supersedes;
- (c) a superseded snapshot inside its recovery grace, `max(automated recovery
  window, one hour)` after its successor's `created_at`;
- (d) named, for the requesting caller, by that caller's own reporting receipt
  in any status, or by its current consumer status statement with status
  `received`, `unreadable` or `content_mismatch`.

Any other superseded snapshot may be compacted to metadata only. An exact read
of a compacted revision returns the same nondisclosing `REFERENCE_NOT_FOUND` as
an unknown ID. A revision in (a) to (d) whose content cannot be served is
`SERVICE_UNAVAILABLE` (`REVISION_UNREADABLE`), never not-found.

```ts
// Core-only service
createReliableReportingService({
  // ...
  maintenance: reportingLedgerMaintenance({ compaction: { enabled: true, limit: 100 } }),
});

// Production service
await createPostgresReliableReportingProductionService({
  // ...
  compaction: { enabled: true, limit: 100 },
});

// Or call the store directly
await store.compactSupersededSnapshots({
  statusRetentionDays: 30,
  automatedRecoveryWindowSeconds: 3600,
  limit: 100,
});
```

Both options take `{ enabled: true; limit?: number }` (default `limit` 100 per
pass) and reuse the service's `statusRetentionDays` and
`automatedRecoveryWindowSeconds`. The maintenance task is named
`snapshot compaction`.

A snapshot is compacted only when all of these hold:

- A later revision supersedes it, and it is not the revision the current
  revision supersedes. Current and official revisions are never compacted.
- Its recovery grace has passed: `max(automatedRecoveryWindowSeconds, 3600)`
  seconds since its successor's `created_at`.
- No caller is owed it. The check spans every caller: a receipt in any status
  (current or superseded), or a current `received`, `unreadable` or
  `content_mismatch` consumer status statement, from any caller keeps the
  revision while its window (`statusRetentionDays` from its successor's
  `created_at`) is open. After that window nothing is owed any more.
- The obligation holds no live worker lease, no Managed Delivery
  materialization of that revision is still `pending`, and no live change-feed
  consumer (updated within `maxFeedHoldDays`) has yet to pass that revision's
  change row. This is the same hold retirement applies, narrowed to the
  revision.
- It has rows. A revision with no rows has nothing to reclaim.

Compaction drops row content only. The revision header, its manifest and every
metadata listing stay, and `listRevisionMetadata` and the status views keep
listing it. `listRevisions`, which hydrates rows, omits compacted revisions.
The `revision` view of `get_reporting_status` for a compacted revision answers
as an unavailable lookup, like an exact read.

It uses the same three resumable phases as retirement. Under the account lock it
re-checks eligibility and marks the row set `pruning` (reads answer as expired;
no new revision can share its chunks). It then deletes external objects at their
recorded versions through the fenced delete path, skipping any object a row set
that is not being pruned still references. Finally it deletes the chunk
manifest and any PostgreSQL chunk body nothing else uses, and marks the row set
`pruned`. A crash after the first phase leaves a `pruning` row set that the next
pass finishes. Chunks shared by byte-identical revisions survive until the last
revision referencing them is compacted.

Compaction records no change-feed row: the revision's metadata did not change,
and a sink still catching up holds the revision back (above).

Every writable object row binding's `keyTemplate` must include
`{revision_key}` (the default template does), so two uploads never name the
same object. Deletes skip objects another row set still references (see
[Object storage](#object-storage-bindings)), which still matters for header-only
revisions that share chunks within an obligation and for rows written under an
older template, so compaction does not depend on key uniqueness alone. A
`readOnly` binding for older rows is exempt: it never takes commits, so nothing
can adopt through it. The SDK fails closed when the store is configured, and
`createReliableReportingService`, `createPostgresReliableReportingProductionService`
and `compactSupersededSnapshots` re-check before compacting.

### Core-only setup with row storage, change feed and retention

You do not need the production service (managed delivery, notifications and
activity) to keep a ledger tidy. Build the store with the options you want and
give `createReliableReportingService` a `maintenance` option built by
`reportingLedgerMaintenance` from `@adcp/reporting-storage`. The production
service does the same work automatically; the two share one implementation, so
partial-failure reporting, the `maxFeedHoldDays` that retention honours, per-task
limits and abort handling are identical.

```ts
import { PostgresReportingLedgerStore, reportingLedgerMaintenance } from '@adcp/reporting-storage';
import { createReliableReportingService } from '@adcp/sdk/reporting/service';

// Run `npx adcp-reporting-storage migrate` (ledger, row storage and change feed), then:
const store = new PostgresReportingLedgerStore(pool, {
  acknowledgeIsolatedDatabase: true,
  rowStorage, // verified chunked rows in your object store
  changeFeed: true, // host reads and consumer cursors
});
await store.readyRowStorage();

const reporting = createReliableReportingService({
  store,
  statusRetentionDays: 90, // the commitment advertised to buyers; retention uses it
  // ...adapters, contact, resolveSource, resolveCurrency, resolveCoverage
  maintenance: reportingLedgerMaintenance({
    intervalMilliseconds: 300_000, // default: at most one pass per 5 minutes
    retention: { enabled: true, recordRetentionDays: 120, limit: 100 },
    changeFeed: { changeRetentionDays: 30, maxFeedHoldDays: 7 },
  }),
});

reporting.start({ intervalMilliseconds: 60_000, deploymentWide: true, onError });
```

`reporting.start()` runs maintenance on its first pass and then at most once per
`maintenance.intervalMilliseconds`, after the tenant cycles, never on every
cycle. A task that throws, or that resolves with `failed` items, goes to the
scheduler's `onError` (or `logger.warn`) and never stops the loop; partial
failures arrive as `ReportingMaintenancePartialFailureError`.

If you run your own scheduler instead, call `reporting.runMaintenance({ signal })`.
It returns one result per task and reports failures in the result rather than
throwing:

```ts
for (const result of await reporting.runMaintenance()) {
  if (result.status === 'failed') log.error(result.task, result.error);
  else if (result.partialFailure) log.warn(result.partialFailure.message);
}
```

Tasks, in order:

| Task                  | Runs                                              | What it does                                                         |
| --------------------- | ------------------------------------------------- | -------------------------------------------------------------------- |
| `snapshot sweep`      | always                                            | Deletes expired cursor snapshots and checkpoints (1,000 per pass).   |
| `row upload sweep`    | always                                            | Resolves abandoned object uploads (100 per pass); no-op without row storage. |
| `change-feed pruning` | when `maintenance.changeFeed` is set              | `pruneChanges` with `changeRetentionDays` and `maxFeedHoldDays`.     |
| `retention`           | when `maintenance.retention.enabled` is `true`    | `retireExpiredPeriods` with the service's `statusRetentionDays` and the feed's `maxFeedHoldDays`. |
| `snapshot compaction` | when `maintenance.compaction.enabled` is `true`   | `compactSupersededSnapshots` with the service's `statusRetentionDays` and `automatedRecoveryWindowSeconds` (see [Compacting superseded snapshots](#compacting-superseded-snapshots-opt-in)). |
| `orphan object collection` | when `maintenance.orphanCollection.enabled` is `true` | `collectOrphanedRowObjects`: lists each object binding under `{prefix}/{namespace_key}/` and deletes old objects nothing names. Opt-in, rate-limited and resumable; see [Orphaned object collection](REPORTING-OPERATIONS.md#adopting-row-storage-retention-and-the-change-feed). |

Notes:

- The service's `maintenance` option takes a factory, not an options object:
  the SDK does not know what maintenance a store needs, so it calls the factory
  once at construction with the store and the retention and recovery-window
  commitments it advertises. `reportingLedgerMaintenance(options)` is the
  PostgreSQL one. It requires a `PostgresReportingLedgerStore` (or a store with the
  same `retireExpiredPeriods`, `pruneChanges` and `sweepRowWriteIntents`
  methods, plus `collectOrphanedRowObjects` when `orphanCollection` is set) and
  fails at construction otherwise. `maintenance.changeFeed` also
  requires `changeFeed: true` on the store, since pruning is otherwise a silent
  no-op.
- Retention takes `statusRetentionDays` from the service, so it can never retire
  a period earlier than the retention you advertise. `recordRetentionDays` may
  only lengthen it.
- The snapshot sweep uses `store.sweepExpiredState()`. A custom store without
  that method skips the task rather than failing.
- Run it on every replica or on one: each task is bounded, resumable and safe
  to run concurrently.
- Enable `retention` last (see the adoption checklist in the
  [operations guide](REPORTING-OPERATIONS.md#adopting-row-storage-retention-and-the-change-feed)).
  Retirement cannot be undone.

### Host reads: current revisions and the change feed

In-process consumers such as pacing, alerts and warehouse loaders read from the
ledger, never from a warehouse copy.

```ts
// `npx adcp-reporting-storage migrate` installs the change feed (version 0005, PostgreSQL 13+).
const store = new PostgresReportingLedgerStore(pool, { acknowledgeIsolatedDatabase: true, changeFeed: true });

const current = await store.getCurrentRevision({ account_id, reporting_obligation_id });
const { revisions, cursor: next } = await store.listCurrentRevisions({
  account_id,
  period_start_from: '2026-10-01T00:00:00Z',
  period_start_to: '2026-10-08T00:00:00Z',
});

let cursor = await loadCursor();
const page = await store.changesAfter({ account_id, cursor, kinds: ['revision'] });
// ...apply page.records...
await store.saveFeedConsumerCursor('pacing', page.cursor); // holds back pruning
```

- The current revision is the official revision if one exists, otherwise the
  highest-numbered snapshot. An official revision is terminal, so this is always
  one index lookup.
- `changesAfter` lists committed obligation, revision, adjustment and retirement
  changes. Every feed, account-scoped or deployment-wide (omit `account_id`),
  orders by `(xid, seq)` and returns only changes whose transaction precedes
  every transaction still in flight (`xid` below the reading snapshot's
  `xmin`), so a slow commit is never skipped. The order does not depend on the
  account lock, on the order a writer drew `seq` in, or on which lock key a
  writer took: a change with a lower `seq` and a higher `xid` that commits late
  is simply returned on a later page, after the cursor. The cost is that any
  older open transaction on the cluster, including an idle one in another
  database, holds every feed back until it ends; keep transactions short. An
  empty page therefore means either caught up or held back, so poll again rather
  than treating it as the end of the feed. The account scan is served by the
  `(account_id, xid, seq)` index that `REPORTING_LEDGER_CHANGES_MIGRATION`
  creates.
- **A ledger database has exactly one writer SDK.** The store writes each change
  row under the account advisory lock. The feed no longer needs that lock for
  its order, but a second SDK is still unsupported: it can write rows the first
  SDK's lifecycle, retention and idempotency logic does not know about. Give
  another SDK (for example a Python deployment) its own database. `pruneChanges`
  only deletes changes older than `changeRetentionDays`, far longer than any
  transaction should stay open, and consumer holds compare against cursors the
  feed itself returned, so neither adds an ordering assumption.
- **Upgrading from account cursors that carry only `seq`.** Account feeds used
  to order by `seq` and cut each page before the first in-flight change. An old
  account cursor is `{ seq }` with no `xid`. `changesAfter` accepts it and maps
  it to the position `(xid, seq)` where `xid` is the smaller of the oldest `xid`
  among the account's changes after that `seq` and the reading snapshot's `xmin`.
  Every change after the old `seq` has an `xid` at or above both (a change that
  has not committed yet belongs to a transaction at or above `xmin`), so nothing
  is skipped. The cost is that changes the consumer already read can be returned
  again: those with a lower `seq` and a higher `xid`, and, when a long
  transaction was open at that moment, every change committed since it began.
  Treat redelivery as normal, as for any at-least-once consumer. The returned cursor is in the new
  format, even on an empty page. A legacy cursor fails with `CURSOR_EXPIRED` if
  any change with a higher `seq` was pruned (`adcp_reporting_change_account_horizon.pruned_through_seq`
  still records the highest pruned `seq` for this check). A consumer row saved
  before the upgrade has a NULL `cursor_xid` and holds retention by `seq` until
  the consumer saves its next cursor; `saveFeedConsumerCursor` given a legacy
  cursor maps it the same way. Re-apply `REPORTING_LEDGER_CHANGES_MIGRATION`
  before starting the new binary: it adds the account horizon's `xid` columns,
  replaces the consumer table's check constraint, and creates the new index. On
  a large changes table, create the index first with `CREATE INDEX CONCURRENTLY
  IF NOT EXISTS adcp_reporting_changes_account_xid ON adcp_reporting_changes
  (account_id, xid, seq)`, because a plain `CREATE INDEX` blocks appends while it
  builds; the migration then skips it. The older
  `adcp_reporting_changes_account (account_id, seq)` index is left in place and
  serves the legacy-cursor mapping; drop it once no legacy cursor remains.
- **Do not run the old and new SDK's change-feed maintenance together.** An older
  host's `pruneChanges`, `retireExpiredPeriods` and compaction hold an account
  consumer's changes by `seq` alone and record only `pruned_through_seq`, so
  against a consumer that holds new-format cursors they can prune a change the
  consumer has not read and never advance the horizon the new reader checks.
  Stop the older hosts' maintenance (or the hosts) before the new binary reads
  the feed. Rolling back is not supported once a consumer has saved a new-format
  account cursor: the older SDK rejects it, so reset those consumers.
- `pruneChanges` deletes changes older than `changeRetentionDays` (default 30)
  that every consumer updated within `maxFeedHoldDays` (default 7) has passed.
  An older cursor throws `ReportingChangeCursorExpiredError`; resynchronize from
  `listCurrentRevisions`.
- A read with no cursor can throw `ReportingChangeCursorExpiredError` too. `changesAfter`
  re-reads the retention horizon after the page, so a prune that commits during
  a consumer's first read rejects that page instead of returning one that skips
  the pruned changes. Host startup code must handle `CURSOR_EXPIRED` on a first
  read the same way as on a saved cursor: retry (the new read starts at the later
  horizon) or resynchronize from `listCurrentRevisions`. Match on
  `error.code === 'CURSOR_EXPIRED'` rather than `instanceof`, which fails when
  the store and your code load through different module formats (CJS and ESM).
- Consumer checkpoints are forward-only. `saveFeedConsumerCursor(name, cursor)`
  ignores a cursor behind the saved one in the same feed scope, so a delayed or
  stale acknowledgment cannot pull the retention hold backward. It resolves
  `true` when the checkpoint was written and `false` when it was ignored (an
  equal position also resolves `false` with `{ refreshUnchanged: false }`). To
  rewind a consumer on purpose, for example to replay changes, pass
  `{ rewind: true }`; the saved position and retention hold move back to that
  cursor (the write always applies, and the cursor is not checked against the
  retention horizon, so it must still be inside the retained history). Without it a rewound
  consumer would keep its old, newer hold, pruning could remove exactly what it
  is about to read, and its next read would throw `CURSOR_EXPIRED`.
  `removeFeedConsumer(name)` unregisters a consumer so it stops holding back
  pruning; it resolves `true` when a registration was removed.
- Period retention honours the same hold: `retireExpiredPeriods` does not retire
  a period while a live consumer has not read its changes. A consumer that
  stays silent past `maxFeedHoldDays` stops holding, and its unread changes can
  then point at revisions whose period was retired.
- The production service accepts `changeFeed: true | { changeRetentionDays,
  maxFeedHoldDays }` and prunes the feed on its scheduler.

### BigQuery warehouse sink

`@adcp/reporting-storage/bigquery` loads committed revisions into your own BigQuery
tables for analysts. The warehouse copy is derived and non-authoritative. It
is never read for serving or verification, so its table names, columns,
partitioning and retention are yours.

```ts
import { BigQuery } from '@google-cloud/bigquery';
import {
  REPORTING_WAREHOUSE_SINK_MIGRATION,
  createBigQueryReportingWarehouseSinkV1,
} from '@adcp/reporting-storage/bigquery';

await pool.query(REPORTING_WAREHOUSE_SINK_MIGRATION); // after REPORTING_LEDGER_CHANGES_MIGRATION
const bigquery = new BigQuery({ projectId: 'analytics-prod' }); // ADC / workload identity
const sink = createBigQueryReportingWarehouseSinkV1({
  store, // PostgresReportingLedgerStore with changeFeed: true
  db: pool,
  bigquery,
  name: 'warehouse',
  projectId: 'analytics-prod',
  datasetId: 'reporting',
  rowsTableId: 'media_buy_delivery_rows',
  revisionsTableId: 'media_buy_delivery_revisions',
  location: 'US',
  mapRow: row => ({ media_buy_id: row.media_buy_id, impressions: row.impressions, spend: row.spend }),
});
await bigquery.query({ query: sink.defaultTablesSql }); // or create your own tables
await bigquery.query({ query: sink.currentRowsViewSql });
setInterval(() => {
  void sink.runOnce().catch(error => console.error('Warehouse run failed', error));
}, 15 * 60_000);
```

#### The two-table contract

The sink writes two tables, and the second is part of its contract. The rows
table holds the report rows. The **revisions table** holds one metadata line per
revision: `reporting_revision_id`, `reporting_obligation_id`, `account_id`,
`revision_number`, `finality`, `period_date`, `supersedes_reporting_revision_id`,
`period_start`, `period_end`, `source_timezone`, `observed_at`, `data_through`,
`revision_content_sha256`, `row_count` and `control_totals`. The reference DDL
(`sink.defaultTablesSql`) declares exactly these columns, and a test pins the
DDL to what the sink loads. The `current_rows` view picks each obligation's
current revision from the revisions table, so the rows table alone cannot tell
you which revision is current.

- **The revisions table is required.** `revisionsTableId` has no default and no
  way to turn it off, and the sink refuses to start without it. A custom table
  must keep every column above: the load sets no schema and no
  `ignoreUnknownValues`, so a missing column fails the revisions job (and only
  that job: the rows job ran first and has already landed).
- **Load order.** Each batch loads the rows table first, then the revisions table,
  as two separate load jobs. BigQuery has no transaction across tables. The
  cursor advances only after both jobs have finished cleanly.
- **Visibility.** A revision's rows can be visible in the rows table before its
  metadata is in the revisions table: between the two jobs of a batch, and for as
  long as the revisions load keeps failing. `current_rows` shows only revisions
  whose metadata has loaded. While a newer revision's metadata is pending, each
  affected obligation keeps showing its previous revision, and an obligation
  whose first revision is pending shows nothing. The reverse does not happen
  through the sink: a revisions row implies its rows landed, because the rows job
  finished before the revisions job was submitted (so long as nothing outside the
  sink deletes or truncates the tables, which adopter-managed table retention
  can). Read the two tables in one query (the view does), or read the revisions
  table first.
- **What to query.** For current figures, query `current_rows`. For revision
  history and audit, query the revisions table and join it to the rows table on
  `reporting_revision_id`. Do not sum the rows table alone: it holds every loaded
  revision, and cumulative snapshots double-count. To alert on metadata that is
  lagging, look for rows with no revisions row:

  ```sql
  SELECT DISTINCT r.reporting_revision_id
    FROM `analytics-prod.reporting.media_buy_delivery_rows` AS r
    LEFT JOIN `analytics-prod.reporting.media_buy_delivery_revisions` AS v USING (reporting_revision_id)
   WHERE v.reporting_revision_id IS NULL
  ```

  A non-empty result for a few minutes is the window between the two jobs. One
  that persists means the revisions load is failing (add a `period_date` filter
  to bound the scan on large tables).
- **Recovery when the revisions load fails.** The batch plan stays in PostgreSQL
  and the cursor does not move, so nothing is lost and nothing needs editing by
  hand. The next `runOnce()` finds the rows job by its ID, accepts it as loaded
  and does not upload it again, then retries only the revisions job. A network
  error or timeout retries under the same job ID (BigQuery may have created the
  job, and the sink looks it up before it uploads). A job BigQuery ran and
  rejected is retried under a new attempt suffix: the run that first sees the
  failed job advances the attempt and rejects, and the run after it submits. A
  load job is atomic, so a failed one lands nothing and the rows are never
  duplicated. Fix the cause (usually a column the revisions table lacks), keep
  running, and `current_rows` catches up on its own. Do not insert or delete
  warehouse rows to repair it, and do not `reset()`: a reset reloads the history
  and duplicates it unless you empty the tables first. The exception is a failure
  that outlasts `maxFeedHoldDays`: change retention then stops waiting for the
  sink, and `runOnce()` reports the retired revisions as `missing` and loads no
  metadata for them. Their rows, already loaded, stay in the rows table with no
  revisions row (so the anti-join above keeps returning them and they never
  appear in `current_rows`); backfill their metadata or delete those rows by
  `reporting_revision_id`.
- **Why the loader is custom.** The alternative is an Iceberg or Delta Lake table
  behind the object-storage interface, which BigQuery reads as an external table.
  That path carries no revisions table and no `current_rows` view, so an adopter
  who takes it owns the leaf-revision query.

#### How a run loads

- Each run follows the change feed and reads every revision's rows through the
  store's verified reader. It loads rows first and revision metadata second,
  in one load job per table per tick. The sink always adds
  `reporting_revision_id`, `reporting_obligation_id`, `account_id`,
  `revision_number`, `finality`, `period_date` and `ordinal` to your mapped
  columns. `period_date` is a `DATE`: the calendar date of the period start in
  the period's `source_timezone`, as `YYYY-MM-DD` (an SDK column derived from
  AdCP's `period`), not the UTC date unless that is the source timezone. A
  period starting `2026-10-02T07:00:00Z` in `America/Los_Angeles` is
  `2026-10-02`; one starting `2026-10-01T15:00:00Z` in `Asia/Tokyo` is also
  `2026-10-02`. It is the start's date only, not a coverage range: a period
  that crosses local midnight or spans several days is one `period_date`, so
  `PARTITION BY period_date` holds source-local days and a UTC "yesterday"
  filter can straddle partitions. The sink computes it with the same helper
  that renders `{period_date}` in object keys. It fails the batch rather than
  load a guessed date when a revision's period or timezone is missing or
  invalid. The batch stays retained, so the sink stops until that revision's
  period is repaired (or the runtime's timezone data is upgraded); reset with
  `discardRetainedPlan` restarts from the beginning, so empty the tables first.
- Batches are planned durably before loading, and job IDs derive from the
  change-feed range. Before every submission the sink looks that job ID up in
  the destination project and location: a job that finished cleanly counts as
  loaded, a job that is pending or running is waited for (never uploaded
  again), and only a missing job (404) is uploaded. A crash or timeout between a
  load and the cursor commit therefore replays the same batch under the same
  job ID without a second upload. An upload an earlier run abandoned at its
  deadline is still running in the same process (the official client cannot
  abort it), so the next run waits for it, within its own deadline, rather than
  starting another, however long ago it started (that age includes the gap
  between runs). If that wait outlasts the run's deadline it counts as a timeout
  and the deadline grows. Only an upload still pending after 6 hours, the
  largest deadline, is abandoned and replaced; BigQuery refuses a duplicate job
  ID, so a replacement can never load the batch twice. A job that finished with
  an error is retried under a new attempt for that table only. Deadline and
  timeout errors name the table (`rows` or `revisions`, and its ID), the
  deadline in force and that table's timeout count, never a file path or
  credential.
- `projectId` scopes both load submission and replay status checks. When it is
  omitted, both use the BigQuery client's default project. Each replica must
  be able to read the BigQuery jobs submitted by the other replicas. When
  `location` is omitted, the first `runOnce()` reads it using the official
  client's `dataset.getMetadata()` and caches it for that sink instance before
  any warehouse work, even on an idle tick. This requires `bigquery.datasets.get`.
  Discovery times out after 60 seconds, or `loadTimeoutMilliseconds` if shorter.
  Both load submissions and job lookups use that location. Discovery failures
  reject before any sink state or load is written and can be retried; they name
  the permission and the `location` option. Set `location` explicitly to skip
  metadata access, including when using a wrapper without `getMetadata()`.
- `loadTimeoutMilliseconds` (default 10 minutes) is the base deadline for one
  run's work on one load: uploading the file, or waiting for a job that is still
  running. It bounds a run, not the job. BigQuery does not stop a load when the
  client gives up (a cancel is accepted and the job finishes anyway), and it
  refuses a resubmitted job ID only after the whole file is uploaded again, so
  the sink never cancels and never relies on that refusal. When the deadline
  passes, the run rejects with the plan retained and nothing advanced: the job
  ID, the attempt and the cursor stay as they were, and the next run looks the
  job up by its ID again. A job whose upload outlasted a deadline is created in
  the background and is picked up by the next run with no second upload. Each
  such timeout doubles that table's deadline for later runs (up to 6 hours).
  The growth is kept with the plan in `planned_rows_timeouts` and
  `planned_revisions_timeouts` (so it survives restarts and applies to every
  replica, and clears when the batch commits), so an upload slower than the
  deadline eventually gets enough time. Set the deadline above your slowest
  expected load to avoid the extra runs. Only a job BigQuery reports as
  finished with an error advances the attempt. A status check that times out
  is bounded by the base deadline and does not grow it. Re-run
  `REPORTING_WAREHOUSE_SINK_MIGRATION` after upgrading: it adds the two timeout
  columns (a sink table without them rejects with a message saying so).
  BigQuery's server-side `jobTimeoutMs` is not used: for a local-file load the
  official client builds `configuration.load` from the load options and cannot
  set job-level fields, and BigQuery silently drops `labels` and `jobTimeoutMs`
  found inside `configuration.load`. (Staging the file in GCS and submitting
  the load with `bigquery.createJob` can set both; the sink does not stage
  files.) For the same reason the `labels` option has no effect (it warns once per process and
  is deprecated). To attribute load cost, query
  `` `region-<location>`.INFORMATION_SCHEMA.JOBS_BY_PROJECT `` (needs
  `bigquery.jobs.listAll`; about 180 days of history), filtering on
  `STARTS_WITH(job_id, 'adcp_rr_')` or on `destination_table`, and summing
  `total_slot_ms` or `total_bytes_billed`.
- Overlapping runs atomically claim one durable batch. Replays use that
  batch's job IDs; attempts and cursor commits compare the full saved plan.
  A stale run rejects without replacing another batch or rewinding either
  the warehouse cursor or its feed checkpoint. Catch the rejection and retry
  `runOnce()` on the next tick. Empty-feed cursor initialization uses the
  same claim and commit rules. Replicas sharing a sink name must use the same
  ledger database, feed scope, destination, location and row mapping. Use a new
  name when that configuration changes. Independent ledgers loading into the
  same BigQuery project must use distinct sink names, even if their destination
  tables differ. An idle tick drains non-revision changes through the
  same fenced checkpoint. An idle tick also recovers a failed acknowledgment
  without refreshing an unchanged checkpoint. Failed loads and idle ticks
  behind the deployment feed's transaction fence can still age out after
  `maxFeedHoldDays`.
- Feed reads recheck the retention horizon before returning a page. If pruning
  overtakes the starting position during a read, `runOnce()` rejects with
  `ReportingChangeCursorExpiredError` before committing the page.
  The non-revision fallback preserves the first read's cursor, including on
  initial startup. If retention overtakes the initial read, the sink records
  that starting cursor before rejecting, so later ticks and restarted workers
  continue to report the gap. This does not acknowledge the missing changes or
  renew their retention hold. Resynchronize from current revisions before resuming.
- A brand-new sink can hit that rejection from a harmless startup race: pruning
  commits during its very first read, after the changes it lost were already
  past retention and held by nobody. Every later tick then rejects with
  `CURSOR_EXPIRED` because the sink keeps reporting that gap. Clear it with
  `await sink.reset()`, which resets the sink to start from the oldest retained
  change and unregisters its feed consumer (stop every worker with that sink
  name first; do not edit `adcp_reporting_warehouse_sinks` by hand). `reset()`
  refuses while a batch plan is retained, because that batch's BigQuery load
  jobs may have succeeded; reconcile the plan against BigQuery, then call
  `reset({ discardRetainedPlan: true })`. It does not touch the warehouse: a sink
  that already loaded history reloads the retained revisions, so empty the
  destination tables first (after stopping every worker and letting in-flight
  uploads and jobs finish, since the sink never cancels a load) or use a new
  sink name against new tables. Every
  reset starts a new job ID generation, so reloaded batches submit fresh BigQuery
  jobs instead of matching the finished jobs of the earlier history. Nothing holds
  change retention between `reset()` and the first committed batch. If `reset()`
  rejects after clearing the sink (it could not unregister the consumer), call
  it again before restarting workers. Re-run `REPORTING_WAREHOUSE_SINK_MIGRATION`
  after upgrading: it adds the `reset_generation` column.
- Upgrading from 15.9.0: stop every 15.9.0 sink worker before starting newer
  ones, then re-apply `REPORTING_WAREHOUSE_SINK_MIGRATION`. A 15.9.0 worker
  cancels a load at its deadline, so one running beside a newer worker on the
  same sink can cancel a job the newer worker is waiting on. The job then ends
  `DONE` with an error and the attempt advances. Rows do not duplicate, but
  convergence slows. The sink now discovers an omitted `location` from dataset
  metadata. Older workers require an explicit location for datasets outside the
  US and EU multi-regions so replay lookups can find their load jobs.
- Stop old sink workers before relying on these overlap guarantees. If an
  earlier overlapping run left a plan whose starting cursor differs from the
  committed cursor, the sink rejects it before loading. Reconcile the retained
  plan, its BigQuery jobs and warehouse rows before repairing the checkpoint.
  Do not discard the plan automatically: its load jobs may have succeeded.
- Query `current_rows`, not the raw rows table. Pacing snapshots are
  cumulative, so summing across revisions double-counts. The view keeps each
  obligation's current revision, read from the revisions table (see
  "The two-table contract" above for what is visible while that table lags).
- The sink registers as a change-feed consumer, so `pruneChanges` keeps changes
  it has not loaded yet, and `retireExpiredPeriods` keeps the periods it has not
  loaded yet, in both cases only while its cursor was saved within
  `maxFeedHoldDays`. Superseded snapshots are the intraday pacing curve, and the
  warehouse may keep them as long as you like.
- `runOnce()` resolves with `{ idle, revisions, rows, missing }`. `idle` means
  no revision changes were selected for this batch; an idle tick can still advance
  past non-revision feed changes without submitting load jobs. `missing`
  lists revision IDs the feed announced that were retired before the batch ran.
  A non-empty `missing` means the sink fell behind retention (it was down longer
  than `maxFeedHoldDays` plus the retention window): the warehouse lacks those
  revisions. Backfill them from another source or accept the gap. The cursor
  still advances so the sink is not stuck. After a crash and replay of a planned
  batch, a listed revision may already have been loaded by the first attempt.
- The sink uses only `dataset().table().load()`, `job().getMetadata()` and
  `query()` from the official client you construct. It adds no dependency.

## Managed Delivery and Reconciled Billing

Core remains the default and has no destination, external-resource, or receipt dependency. To opt into the higher tiers, apply `REPORTING_MANAGED_DELIVERY_MIGRATION` **after** `REPORTING_LEDGER_MIGRATION`, explicitly construct the Core store with `managedDelivery: true`, create a `PostgresReportingManagedDeliveryStore`, and pass both stores with a destination adapter to `createReportingManagedDeliveryRuntime`. The async factory proves the stores share one authority and validates the RC3 tier wiring before returning it. It advertises `managed_delivery` only when an immutable binding, delivery, bounded resource reading, generation-fenced revocation, and at least one verification profile are installed. The advertised automated recovery window must be at least the widest installed managed Core configuration recovery window. It advertises `reconciled_billing` and `receipt_task` only when an authenticated consumer resolver and canonical-digest verification are also installed.

```ts
import {
  PostgresReportingLedgerStore,
} from '@adcp/reporting-storage';
import {
  PostgresReportingManagedDeliveryStore,
  createReportingManagedDeliveryRuntime,
} from '@adcp/reporting-storage/managed';
import {
  reportingManagedDeliveryBindingV1,
} from '@adcp/sdk/reporting/ledger';

// `npx adcp-reporting-storage migrate` installs the managed-delivery tables (version 0006).
const managedStore = new PostgresReportingManagedDeliveryStore(pool);
const managedCoreStore = new PostgresReportingLedgerStore(pool, {
  acknowledgeIsolatedDatabase: true,
  managedDelivery: true,
});
await managedStore.authorizeDestination({
  account_id: internalAccountId,
  destination_ref: destinationRef,
  generation: 1,
  authorized_at: new Date().toISOString(),
  // The delivery contract this generation serves, recorded once and immutable.
  pattern: 'file_transfer',
  transport: 'gcs',
});
await managedStore.installBinding(
  reportingManagedDeliveryBindingV1({
    // Binds the Core configuration generation installed above. That
    // configuration's `schedule.recoveryWindowMilliseconds` is 3_600_000, which
    // is what `automatedRecoveryWindowSeconds: 3600` below must meet or exceed.
    ...bindingForInstalledCoreConfiguration,
    account_id: internalAccountId,
    destination_ref: destinationRef,
    authorization_generation: 1,
  })
);

type SellerContext = { account?: unknown; agent: { agent_url: string } };
const managed = await createReportingManagedDeliveryRuntime<SellerContext>({
  coreStore: managedCoreStore,
  store: managedStore,
  adapter: destinationAdapter,
  offerings: reportingDeliveryOfferings,
  resolveConsumerId: context => context.agent.agent_url,
  // MUST be at least the widest installed managed binding's Core
  // `schedule.recoveryWindowMilliseconds` / 1000 — see the precondition note below.
  automatedRecoveryWindowSeconds: 3600,
  statusRetentionDays: 90,
  resourceRetentionDays: 30,
  authorizationRevocationSeconds: 60,
});

// Supply these to the matching server slots/capability document.
const { getReportingStatus, getMediaBuyDelivery, syncReportingReceipts } = managed;
const reportingDelivery = managed.reportingDeliveryCapabilities;

// Run from a durable scheduler; replicas safely share SKIP LOCKED leases.
await managed.runWorker({ maxIterations: 100 });
```

### Pattern and transport on a destination authorization

A destination has exactly one delivery pattern, and a change to its delivery contract mints a new `destination_ref` generation, so the pattern and transport are fixed for an authorization generation. Pass `pattern` (`file_transfer`, `dataset_share`, `warehouse_materialization`) and `transport` (the same lowercase token the offering's `method.transport` uses, such as `gcs` or `s3`) to `authorizeDestination()` when you create the generation. The store records them in `pattern`/`transport` columns and returns them on the authorization that `claimRevocation()` hands to `adapter.revoke()`, so a revocation can be routed to the transport that holds the provider grant instead of being guessed or fanned out.

- Both are optional, and `transport` requires `pattern`. A generation recorded without them stays valid and revocable; it is simply unroutable by transport.
- They are immutable. Replaying `authorizeDestination()` for the current generation may omit them but cannot state different values, and it cannot add them to a generation recorded without. Change the contract by minting a new generation.
- `installBinding()` rejects a binding whose `method` or `transport` differs from what its generation recorded, so one generation can never be delivered through one transport and revoked through another.
- Upgrading: `REPORTING_MANAGED_DELIVERY_MIGRATION` is additive (`ADD COLUMN IF NOT EXISTS`) and safe to re-run. The run that adds the columns backfills each existing generation from the bindings that reference it, but only where every such binding names the same method and the same transport. A generation whose bindings disagree, name no transport, or do not exist is left NULL, and the migration raises a `NOTICE` with how many. Later runs do nothing, so a NULL generation is never re-decided by a binding that arrived afterwards. `managedStore.listDestinationAuthorizationsWithoutContract()` lists the NULL generations with a `reason` (`no_binding`, `binding_without_transport`, `bindings_disagree`, `not_recorded`) so you can see which still need handling.

### Multi-transport delivery with the router

A seller often delivers one feed through several transports: one buyer takes files in a GCS bucket, another in S3. A runtime takes one adapter, so install a router that is itself a `ReportingManagedDeliveryAdapterV1` and dispatches to one adapter per `(pattern, transport)`. The router is pure dispatch with no state of its own, so the store and worker keep every fence they provide today: leases, the authorization-generation check, settlement, the retry and attempt cap, and revocation SLA accounting, per materialization and whichever route served it.

```ts
import {
  createReportingManagedDeliveryAdapterRouterV1,
  createReportingManagedDeliveryRuntime,
} from '@adcp/reporting-storage/managed';

const adapter = createReportingManagedDeliveryAdapterRouterV1({
  routes: [
    { id: 'gcs', match: { pattern: 'file_transfer', transport: 'gcs' }, adapter: gcsAdapter },
    { id: 's3', match: { pattern: 'file_transfer', transport: 's3' }, adapter: s3Adapter },
  ],
  // Optional. Only for bindings and authorizations recorded before a transport was.
  legacyDefault: 'gcs',
});

const managed = await createReportingManagedDeliveryRuntime({ /* ... */ adapter });
// or: createPostgresReliableReportingProductionService({ /* ... */ managedDelivery: { adapter, /* ... */ } })
```

How a route is chosen:

- `deliver()` and `read()` select from the immutable binding alone: `binding.method` (the pattern) and `binding.transport`. They never look at request input, materialization state or the resource.
- `revoke()` selects from the `pattern` and `transport` recorded on the destination authorization generation (see above). It calls exactly one adapter and never fans out.
- Anything that cannot be routed throws a typed `ReportingManagedDeliveryRoutingErrorV1` (`code`: `REPORTING_ROUTE_NOT_FOUND`, `REPORTING_ROUTE_TRANSPORT_REQUIRED`, `REPORTING_ROUTE_CONTRACT_UNRECORDED`, `REPORTING_ROUTE_VERIFICATION_UNSUPPORTED`) before any adapter is called. A failed delivery is an ordinary failed attempt and counts toward the attempt cap. A failed revocation is released for retry and counted as overdue once it outlives `authorization_revocation_seconds`, so an unroutable grant is visible, not silent.
- A binding with no `transport`, and an authorization with no recorded pattern/transport, go to `legacyDefault` if you configured one (and, for a pattern that is stated, only if it is that route's pattern); otherwise they fail as above. A recorded transport with no route never falls back to `legacyDefault`: the router will not guess which provider holds the grant.

Construction throws if route ids repeat, if two routes match the same `(pattern, transport)`, if a route adapter does not declare `revocationFencesDeliveryGenerations: true`, or if a route has an empty `verificationProfiles`. The router's own `verificationProfiles` is the union of its routes' and exists only for compatibility; it never admits a binding.

Admission happens at install and at startup, not at first delivery:

- `createReportingManagedDeliveryRuntime` registers the router's `admitBinding` with the store (`setBindingAdmission`), so `installBinding` refuses a binding whose pattern/transport has no route, or whose `verification_profile` is not one of that route's `verificationProfiles`, before it writes anything. The refusal is the router's own typed error. A runtime whose adapter provides `admitBinding` refuses a store that cannot enforce it. Single adapters define no such hook and behave exactly as before.
- At runtime construction every advertised managed offering's `method` (pattern and transport) must have a route, and a consumer-receipt offering needs a route that supports `canonical_digest`. Bindings installed before you adopted the router are not re-checked at startup; they fail at delivery with the typed error unless `legacyDefault` takes them.

Optional adapter probe: an adapter may define `probe({ signal })`, which must not mutate provider state. The router probes every route that defines one, concurrently and each within `probeTimeoutMilliseconds` (default 10 seconds; it must be below the runtime's 30 second probe deadline so a hung route is still named), and the runtime calls it before it adopts any durable policy. A failure stops startup with an error naming the failing route id (`Managed Delivery adapter probe failed for route "s3"`); the provider's own message stays on `cause` and out of the message. Offerings are not withdrawn dynamically: fix the route or remove it, then restart.

Observability: when the adapter is a router, `runWorker()` results also carry per-route counts keyed by route id: `deliveriesByRoute`, `deliveryFailuresByRoute`, `revocationsByRoute`, `revocationFailuresByRoute` and `overdueByRoute`. Work no route could take is counted under `UNROUTED_REPORTING_ROUTE_KEY_V1` (`'~unrouted'`, which no route id can equal). The counts carry route ids only, never credentials, locations or provider messages. A single-adapter runtime's result shape is unchanged.

Deployment-wide materialization planning is durably round-robin. The PostgreSQL
store advances an agent-wide cursor before processing its bounded account page
and gives every selected account a first-pass share before unused capacity
returns to a hot tenant. A crash can defer a selected account until the ring
wraps, but a lexically early account cannot consume every page, and an account
added after the cursor receives bounded progress on the next eligible sweep.
Apply `REPORTING_MANAGED_DELIVERY_MIGRATION` on upgrade so the cursor column is
available before any unscoped `planMaterializations()` call.

`automated_recovery_window_seconds` is published once per agent, in one capability document, while Core `schedule.recoveryWindowMilliseconds` is per configuration. The advertised value is a **maximum** — the longest a due obligation may stay `delayed` while automated recovery continues before it becomes `action_required` — so one agent-wide number is truthful exactly when it is at least every installed window. `createReportingManagedDeliveryRuntime` enforces that bound and nothing more: advertising less than the widest installed window is refused with the offending value named, advertising more is conservative and allowed, sub-second Core windows are rounded up to the whole second the capability is expressed in, and a deployment with no managed binding — a fresh install, or one that has just offboarded its last managed tenant — starts normally. Heterogeneous tenants behind one agent therefore need no separate endpoint per cohort: advertise the widest window they run. The bound is enforced on the write path as well as at startup — `adoptAdvertisedPolicies` validates existing bindings while exclusively locking the same durable policy sentinel as `installBinding`, and `installBinding` refuses a later Core configuration whose recovery window exceeds the durable bound. `listInstalledRecoveryWindowSeconds` is optional direct-store introspection, not an authoritative publication check: an install can otherwise land between a list and a later adoption.

All four capability promises are durable and database-wide. The atomic hook adopts recovery and authorization-revocation maximums in the stronger, decreasing direction, and status and resource-retention minimums in the stronger, increasing direction. It returns those effective values so a weaker replica still runs its worker to the strongest policy already registered; PostgreSQL also enforces resource retention at settlement and authorization revocation at claim time for direct callers. A rejected binding check or policy write leaves all four columns unchanged, and a later replica can never weaken an adopted promise. Custom stores used by `createReportingManagedDeliveryRuntime` must provide the same atomic, binding-fenced contract; the optional separate recovery/status hooks remain only for compatible direct-store use and are not sufficient for capability publication. Apply `REPORTING_MANAGED_DELIVERY_MIGRATION` on upgrade as well as first install: it adds the resource-retention and revocation columns to an existing two-column registry without replacing prior promises.

Authorize a destination generation and install its immutable binding before creating any obligation for that Core configuration. Once an obligation is observable, only an exact idempotent replay of the existing binding is accepted, so the managed tier cannot appear outside the Core changes checkpoint. Build the binding with `reportingManagedDeliveryBindingV1`, which binds the exact internal account, Core configuration generation, destination authorization generation, feed purpose, method, verification profile, reconciliation mode, and resource-retention promise. That promise is a floor rather than a default at settlement: an explicit `minimum_resource_retention_days` may tighten it, never waive it, and a negative value is refused. Only a failed outcome is exempt from it — a successful one must name an expiry the database can check, or a direct store caller could persist a permanently successful materialization whose bytes no reader can fetch and which nothing revisits. It is judged only by the clock that stores the row — `assertMaterializationOutcome` deliberately does not re-check the horizon against the worker's clock, because a worker running ahead of the database then refused a resource the database considers well inside the window and reported it as `DELIVERY_FAILED`. Every claim of a pending materialization counts toward the delivery-attempt cap, and the worker calls `failExhaustedMaterializations` before planning so a row that used them all is failed rather than left pending — that sweep takes the same account lock the lifecycle apply holds, in the canonical order, because it mutates exactly the state the lifecycle compare-and-set fences and could otherwise commit `pending` -> `failed` between a matching state-version check and that apply's commit; it mutates only the accounts it locked, so a lease that expires while it waits on another account's lock is left for the next sweep rather than failed unfenced — which the planner treats as work in flight, making the revision neither claimable nor replannable. That sweep re-checks eligibility against the row it finally locked rather than only the set it selected, so a settlement that commits while the sweep waits on the row is not overwritten with `DELIVERY_ATTEMPTS_EXHAUSTED`. Revocation commits the durable deny first, fails queued work, and makes resource reads and new receipt evidence fail closed; provider-side grant cleanup is a separately leased worker action. Reauthorization uses a strictly greater generation and a new Core configuration generation. It never re-enables an old binding.

The worker claims and commits through short PostgreSQL transactions but performs destination I/O outside them. Pass `authorizationRevocationSeconds` to `runWorker()` when using a direct store; `createReportingManagedDeliveryRuntime` uses the strongest value returned by atomic adoption. PostgreSQL's claim boundary independently applies the durable minimum, so a different replica cannot widen or omit the promise: a cleanup attempt is clipped so it cannot run past `revoked_at` plus the window, a failed attempt's retry lease never outlasts the window, and a grant that has already outlived it is returned as `revocationsOverdue` for alarming. Every SLA fact — `revoked_at`, the remaining window, and whether a grant is overdue — comes from the database that committed the revocation, never the worker host, and the exact boundary counts as overdue. A crashed worker's lease is reclaimable at that boundary even before it expires, with lease generation fencing the old holder — but only once the holder has had a full attempt's worth of time, so live workers cannot steal from each other on an already-late grant and leave cleanup permanently uncommitted. `revoked_at` and `authorized_at` are both written by the committing database, never by the caller, and the strongest of the binding, caller and durable resource-retention floors is judged entirely in SQL against that clock; a settle the database refuses as under-retained is terminalized rather than left pending forever. A failed attempt gives up its lease under a short retry backoff rather than holding it for a full lease or clearing it outright — clearing it let the next iteration of the same worker tick reclaim the same grant, so one broken provider consumed every iteration — so the grant stays reclaimable and its elapsed SLA is visible rather than masked by a lease that has not expired; `claimRevocation` orders by cleanup lease generation, which the failed attempt already incremented, so releasing cannot let one broken grant starve the queue. Delivery, revocation, and resource reads have hard SDK deadlines even when an adapter ignores cancellation; resource descriptors are limited to 1 MiB and resource bodies to 64 MiB by default. Adapters must advertise `revocationFencesDeliveryGenerations: true`, make the logical `(configuration generation, revision, destination generation)` write idempotent, and install a provider-side generation tombstone before `revoke()` returns. Every delivery must be keyed by that generation and refuse a tombstoned generation, including a late provider write that completes after the SDK timed out. A successful commit requires the lease generation and unexpired lease, current authorization, exact Core row count and control totals, all evidence required by the selected verification profile, the official canonical digest when required, an immutable native version reference when applicable, and an `expires_at` satisfying the configured retention window.

`sync_reporting_receipts` derives both account and consumer from authenticated context, and `received_at` is the server's to assign: a request carrying it is refused with a typed `VALIDATION_ERROR` rather than quietly stripped, so the handler and the request schema agree on what a valid request is. RC3 caps `receipts` and `adjustment_receipts` at 100 each in JSON Schema, and bounds the batch as a whole in the request's `x-adcp-validation.batch_identity`: receipt IDs must be unique across both arrays, "whose combined length MUST NOT exceed 100". That annotation is normative prose rather than machine-checked on this path — `x-adcp-validation` is registered as an AJV keyword for commercial terms only — so the handler enforces the combined bound itself. A request that satisfies both per-array caps but exceeds 100 combined is therefore spec-invalid — and unanswerable regardless, since `results` is capped at 100 while one result per submitted receipt is required — so it is refused with a `VALIDATION_ERROR` envelope rather than an over-long `results` array. A finality filter hides managed evidence with the revision it names: returning a materialization or receipt for a revision `finality: official` omitted left the response carrying public references to a revision it does not contain. An adjustment receipt and the adjustment it names are separate pagination items, so a small `max_results` puts them on different pages; the named adjustment therefore travels with the receipt as context on whichever page carries it, and the RC3 rule that a receipt may not appear without the correction it names holds per page. Only items are counted by the cursor, so paging itself is unchanged. Its PostgreSQL implementation serializes each caller namespace, records a compact per-entry verdict for idempotency replay — receipt bodies are rehydrated from the append-only receipt table rather than duplicated — and retains those replay rows for 30 days so a consumer at the per-consumer batch cap is throttled instead of permanently locked out. An exact same-key replay is side-effect free and returns the caller its own recorded verdict even after the destination authorization is revoked. A byte-identical re-presentation of an already-recorded receipt under a fresh idempotency key likewise returns `unchanged`: both paths resolve immutable, caller-owned state and write no new evidence. Revocation governs what may be newly *accepted*, not what the caller's own stored identity answers, so no other consumer's state is read; genuinely new evidence while revoked is still refused. It exposes append-only histories only to that consumer. Revision receipts must name the exact obligation, successful materialization, current authorization, and verification evidence, and a revision whose finality satisfies the obligation's own `required_finality`, so a snapshot-finality contract reconciles on the same terms an official one does. `billing` feeds are not such a contract: RC3 requires `required_finality: official` for them unconditionally, and both `installConfiguration` and `installBinding` refuse the combination for a new generation — an immutable generation that predates the rule reinstalls unchanged, because the replay is resolved before either the offering or the validation — the binding revalidates the referenced Core configuration atomically, because a generation created before that rule existed still sits in the database — so a terminal accepted billing receipt can never land against a provisional revision. Accepted leaves are terminal; a rejected leaf may be repaired only by an exact `supersedes_reporting_receipt_id` — and a leaf whose body has been pruned still owns its subject, so the successor named by its tombstone is admitted while a fresh root carrying the same content is not. Entries that resolve to an already-stored receipt are resolved before the batch's duplicate-subject rule is applied, because such an entry writes nothing and is not competing for the subject: a batch carrying an existing rejected receipt together with its own correction records the correction rather than failing both. Duplicate receipt IDs remain a property of the whole submitted batch. A request with no receipts at all is refused with a typed `VALIDATION_ERROR` before any per-entry refusal, including a wrong-account one, because `results` has `minItems: 1` and a per-entry answer to an empty batch is an empty — schema-invalid — body. Later source corrections remain Core adjustments and receive separate append-only adjustment receipts—neither official revisions nor earlier receipts are rewritten. The per-consumer receipt cap is admission control on new rows, applied at the point one would be inserted: an exact resubmission of a receipt that already exists stores nothing, so it replays as `unchanged` at the cap rather than flipping to `failed` on the row count alone, and a refusal for capacity leaves the current leaf undemoted. Lookup failures intentionally share one generic error so the task cannot probe another account's retained objects.

The lifecycle compare-and-set covers managed state as well as Core evidence. The projection reads managed rows in their own transaction, so `getManagedLifecycleProjection` returns a `managedStateVersion` token over the obligation's materializations, receipts (including current-leaf flips), adjustments and destination-authorization state; `applyLifecycleProjection` re-reads it inside the apply transaction and refuses a stale apply. Without it a revocation, receipt or settled materialization arriving between projection and apply would be overwritten by a health computed before it existed — most visibly as a `complete` persisted and webhooked over a receipt that had just arrived. Omit `ledgerAsOf` outside a deadline sweep and the store resolves its own cutoff: a host `toISOString()` is millisecond-truncated while these columns are microsecond, so a caller-taken "now" sorts before a row written in the same millisecond and silently drops it. A pinned cutoff is also clamped to the ledger's own clock — only where there is one to clamp against; a store with no `readLedgerInstant` takes a first-attempt pin exactly as given, because `now` is precisely what pinning overrides — at the reconciler and again when the watermark is written, and a store with its own clock uses nothing but that clock on a compare-and-set retry. When a store resolves a different instant than the one it was asked for, that resolved instant is what the transition and the watermark use — the projection was computed at it, so stamping the caller's value instead watermarked a moment later than the read and buried everything in between — taking the later of the two put the caller's future pin back the moment the first attempt lost its race. A host running fast pinned an instant the database had not reached, the watermark took that instant, and every database-timestamped change inside the skew was then permanently behind it — excluded from the projection that wrote it and never due again, which left a `complete` transition and its webhook standing over a revocation that had already contradicted it. The producer's own reconciles pass their host instant as a fallback clock rather than as a pin for the same reason. Every comparison against the cutoff runs in SQL for the same reason. The projection reads and the token are taken in one `REPEATABLE READ` snapshot, so a settle committing between them cannot pair a pre-settle health with a post-settle token — the one combination the CAS would otherwise accept. A refused apply is recomputed against a **fresh** authoritative cutoff and retried immediately, bounded; the cutoff never moves backwards. The token covers materializations, receipts including current-leaf flips, adjustments, consumer statuses and destination-authorization state. The externally supplied obligated-consumer roster cannot be re-read inside the apply transaction, so it is versioned separately and re-checked immediately before the apply — every sweep refreshes a bounded slice of its managed obligations' roster versions before selecting, paging on a cursor the refresh itself advances — on failure as well as success, so a tenant whose authorization service is down yields its slot instead of occupying it every sweep, and a difference from the version last reconciled is itself a due condition. The apply fences on that observation too: it locks the obligation's lifecycle row, refuses when the published version has moved since the re-check, and never writes its own version over a newer one — otherwise a refresh landing in that window was overwritten by the version the projection had used, and since due-ness is exactly "observed differs from processed", the roster change had nothing left to re-arm from. Publishing only inside a reconcile was circular — the reconcile needs the obligation to already be due, which is what the roster change was meant to cause. Supply `version` from `obligatedConsumers`, or its resolved content is hashed for you — the projection and the re-check hash the same set, so an unversioned roster converges instead of burning its retry budget. A roster returned with `complete: true` is authoritative and excludes principals it does not list — in the lifecycle fold as well as the live projection and the digest — which is what stops a same-account principal inserting itself into the obligated set by posting a receipt. An incomplete roster is only a hint, so observed principals are still unioned in. Mutable managed state is placed at that cutoff rather than at now: `changed_at` after the cutoff means the materialization was still `pending` then, and a revocation counts only once `revoked_at` is at or before it, so a later settlement is never backdated into an earlier transition.

Managed-only changes are lifecycle candidates in their own right. A settlement, revocation, receipt, adjustment, consumer status, external-roster change or resource expiry after the last reconcile makes the obligation due, so a persisted `complete` cannot outlive a live status that has since degraded — Core deadlines alone would never reschedule it. Candidacy is measured against a per-obligation watermark in `adcp_reporting_lifecycle_state`, written on every reconcile including one that changes no health, and stamped with the cutoff the projection read at rather than the commit instant. Sweeps take that cutoff from the ledger's own clock rather than the worker host, so a fast host cannot stamp a future watermark and bury database-timestamped work committed inside the skew — anything recorded after that cutoff stays due instead of being buried by the write that follows it; without it a change with no health effect keeps the obligation due forever and, in a fair-ordered page, starves everything behind it. Sweeps reconcile each obligation in isolation, so one tenant's failing roster callback cannot abort the obligations queued after it, and a failure records an exponential backoff cursor so a page of failing tenants yields its slots instead of monopolising every sweep — including a reconcile that exhausts its compare-and-set retry budget, which is a failure rather than a completion. The backoff never advances the watermark, so the work stays visible as unresolved.

`MAX_MATERIALIZATIONS_PER_ACCOUNT` and `MAX_RECEIPTS_PER_CONSUMER` are lifetime counts by default. Because managed evidence is immutable, a long-lived account eventually reaches them and then stops planning materializations and refuses every receipt with no way back. Construct the store with `new PostgresReportingManagedDeliveryStore(pool, { evidenceRetentionDays })` to make the caps active-scope: only evidence recorded inside that window counts against them, and `pruneExpiredEvidence({ account_id, limit })` deletes what has fallen outside it — never anything still inside the window, never a `pending` or leased materialization, and never a receipt batch inside its own replay retention. Retention has a floor: at least the 30-day receipt replay retention, and at least the strongest durable status or resource-retention horizon registered for the database. Adoption and binding installation exclusively lock the migration-created policy sentinel before account/binding locks; settlement, revocation claim, and pruning hold shared locks on it through their writes. A stronger promise therefore cannot land between a weaker check and its write, while unrelated hot-path readers remain concurrent. Pruning genuinely does its selection before taking the account lock, and asks which receipts a live replay row still names by expanding those rows once rather than posing a containment question per candidate — a shape no index could serve, which held the lock long enough to fail concurrent Core writes with 55P03. Because that selection is unlocked it is a proposal rather than a verdict: every victim is revalidated under the account lock against current live replay rows, surviving receipts and unexpired resources before it is deleted, so a replay that commits in the gap keeps the receipt it promised to reproduce. The revalidation is narrowed to the candidates' own consumers and keys, so the lock still holds no per-candidate scan. The registry lock is held to commit inside the transaction that acts on it, and a precondition such as the installed-window check runs inside that same transaction so a refusal rolls the write back rather than leaving a durable promise nobody validated, so an install cannot read an empty registry while a narrower promise is being registered, and a prune cannot approve a horizon another replica is about to widen. Pruning deletes and tombstones in one statement against one frozen cutoff, so a moving boundary can never leave a deleted row without its permanent identity. Successive prunes demote the tombstones they supersede, so a subject has exactly one tombstone still claiming to be its leaf and a chain pruned twice resolves the same way every time. Re-presenting a pruned receipt byte-identically answers `unchanged` with the instant the tombstone kept, resolves that receipt's own tombstone before any rule about its subject — so an exact re-presentation is not refused as new content for a settled subject — replays the same answer under the same idempotency key by rehydrating from the tombstone when the body is gone, counts as already-resolved for the batch's duplicate-subject rule, and never recreates the row: recreating it restarted the retention clock, undid the storage the prune reclaimed, and moved the published `received_at` to a moment the consumer never filed anything at. A pruned receipt ID can never bind different content, a subject whose accepted leaf expired can never reopen — the read projection consults tombstones, not just live rows — and materialization attempt history survives as a compact terminal record, so a revision that exhausted its attempts or already succeeded does not restart at attempt 1 once its rows age out. Both conclusions — the acceptance and the fact a delivery succeeded — are folded into the live, filtered and lifecycle projections alike. Counters describe exactly the records the response emits, never more and never less, so a buyer recomputing the association cannot see `ASSOCIATED_HISTORY_INCOMPLETE`; retention therefore refuses to prune an acceptance while the resource it accepts is still readable, which is what keeps a `complete` period from having nothing to show for itself. An acceptance carries the consumer that gave it, so one consumer's pruned acceptance never settles the obligation on another's behalf — including the anonymous fail-safe consumer, which owns no acceptances at all. Pruning also removes the expired replay row before the receipts it names, keeps any receipt a surviving replay row still references — a later batch can name an earlier receipt — and keeps any materialization whose resource is still readable or that a retained receipt names as its evidence. An adjustment receipt names no materialization — it names the revision it corrects — so the readable-resource hold matches on that revision as well, or a period whose revision resource was still readable lost the adjustment acceptance behind its own `complete`. Run it from the same scheduler that runs the worker. Lifecycle receipt reads are driven from the obligation's own subjects into a `(subject_id, receipt_kind, recorded_at)` index rather than asking the global receipt table which of its rows belong to an obligation — a question that supplies neither account nor consumer, so every due obligation re-scanned the whole receipt history. The managed state digest, the obligated-consumer roster read and the permanent delivery tombstones do the same — consumer statuses carry an `obligation_id` index and materialization tombstones an `(obligation_id, reached_success, reached_success_at)` one — because that digest is read inside the apply transaction while it holds the account lock: a scan there is a scan with the lock held, which pushed concurrent Core writes past their lock timeout and failed them with 55P03.

The managed tables are additive and do not alter the Core tables. This is the schema boundary coordinated with the reporting notification work: that work owns transactional reporting notification/activity intent and the existing webhook delivery/credential plane. Managed Delivery does not create a second webhook sender, outbox, credential store, or subscriber model. Apply both feature migrations after the Core migration in either order; each owns separate tables and both reuse the Core authority.

## Transactional reporting notifications and account activity

The activity outbox covers the complete Reliable Reporting event surface. A
newly committed revision or adjustment records `reporting.ledger_changed` in
the same transaction as the immutable ledger row; a successfully settled
managed materialization records `reporting.delivery_ready` in the same
transaction as its terminal state; and health transitions record
`reporting.status_changed`. Network I/O always happens later through recovery.
Event `fired_at` values come from the database clock, and replaying an already
committed ledger record does not create another event.

Production deployments can join every health or observed-finality transition to
a compact account-operator activity record. Health transitions additionally
create one durable, schema-conformant `reporting.status_changed` intent;
finality-only changes remain internal activity because the AdCP event is defined
only for health changes:

```ts
import { createPostgresPersistentNotificationRuntime } from '@adcp/sdk/server';
import { PostgresReportingLedgerStore } from '@adcp/reporting-storage';
import {
  createPostgresReportingNotificationActivityRuntime,
  createPostgresReportingNotificationAttemptCheckpoint,
} from '@adcp/reporting-storage/notifications';

// Build the durable pre-POST checkpoint first. The notification runtime needs
// it, and the activity runtime verifies it targets the same durable store —
// a mismatched pair checkpoints nothing and loses notifications silently, so
// both are refused at construction.
const attemptCheckpoint = createPostgresReportingNotificationAttemptCheckpoint({
  db: pool,
  namespace: 'seller-production',
});
const notifications = createPostgresPersistentNotificationRuntime({
  db: pool,
  publisherScope: 'seller-production',
  checkpointDeliveryAttempt: attemptCheckpoint,
  subscriptions: { acknowledgeIsolatedDatabase: true },
  ...notificationOptions, // proof, protected credentials, webhooks, authorization
});
const reportingActivity = createPostgresReportingNotificationActivityRuntime({
  db: pool,
  notifications,
  // Use a deployment-unique value whenever a PostgreSQL schema is shared.
  namespace: 'seller-production',
  // The same checkpoint, so its store can be verified against this runtime's.
  attemptCheckpoint,
  // Pure host-owned mapping from an internal ledger account. Never derive
  // this from transition data, an incoming request body, or ctx_metadata.
  tenantScopeForAccount: accountId => durableAccountDirectory.tenantFor(accountId),
});

// Rolling-deployment order: ledger and notification tables, activity table,
// drain legacy pending transitions, then application code configured with the port.
// `npx adcp-reporting-storage migrate` applies the ledger tables.
for (const sql of notifications.migrations.all) await pool.query(sql);
for (const sql of reportingActivity.migrations.all) await pool.query(sql);

// Before enabling the port, keep legacy subscribers configured and run
// retryReportingStatusNotificationsV1() until listPendingTransitions() is empty.
// The transactional store fails closed if legacy pending rows remain.

// Last cutover step, only once no pre-SDK-14 writer is still serving: fence
// finality-less transitions out of the log. A surviving legacy writer now fails
// closed on append instead of silently adding another redundant finality event.
// `migrate` applies this fence as the stopped-worker version 0003; on such a cutover, stop every
// pre-SDK-14 writer before running it.

const store = new PostgresReportingLedgerStore(pool, {
  acknowledgeIsolatedDatabase: true,
  notificationActivityPort: reportingActivity.port,
});

// Do not also pass legacy ReportingLedgerSubscriberV1 callbacks to lifecycle
// reconciliation. The transactional port is the sole notification handoff.

await reportingActivity.probe();
await notifications.probe();

// Run both bounded calls repeatedly from the deployment's durable scheduler.
await reportingActivity.recoverOnce({
  ownerToken: process.env.INSTANCE_ID!,
  onError: (error, claim) => operationalLogger.error({ error, claim }),
});
await notifications.recoverOnce({ ownerToken: process.env.INSTANCE_ID! });
```

`applyLifecycleProjection()` owns the transaction. After locking and rechecking
the obligation and revision evidence, the PostgreSQL store inserts the
transition, updates its issues, and calls `notificationActivityPort` with that
same transaction client. A port error rolls the whole unit back. The port does
no network I/O and stores no destination or authentication material. Only after
commit does `recoverOnce()` call the existing persistent-notification runtime,
which reads current subscriptions, enforces tenant/account matching and live
authorization, resolves opaque credential bindings, and checkpoints the normal
encrypted webhook outbox before POSTing. The activity queue is not a second
sender, credential authority, retry engine, or reporting ledger.
The store atomically stamps the transition's `notifiedAt` field as a durable
handoff marker in that same transaction. In transactional mode this field means
the activity intent is durable, not that a recipient matched or network delivery
occurred. A legacy deployment with unnotified transitions must drain or
explicitly resolve them before enabling the port; the lifecycle rejects the
cutover rather than silently abandoning those rows.

The logical notification identity is derived from the immutable transition and
is reused through ambiguous crashes. Intent insertion is exactly once;
delivery remains at least once. A crash before commit exposes neither the
transition nor its activity. A crash after commit leaves pending work. A crash
after webhook checkpointing may replay projection, but the existing webhook
delivery identity prevents rebinding. The bridge intentionally binds recipients
when the existing notification runtime checkpoints each per-subscriber webhook
delivery, not while the ledger transaction is open: that keeps subscription
credentials and destination authority out of the ledger transaction and ensures
a replacement or revocation that wins before checkpointing is honored. From
that checkpoint onward the subscriber and destination generation are stable;
the runtime rechecks live authorization on every attempt and suppresses stale
or revoked generations. Already-authorized in-flight POSTs cannot be retracted.
This explicit drain-time rule is what the replacement and revocation crash tests
assert.

Account operators can read a bounded keyset page without loading report rows:

```ts
const page = await reportingActivity.listActivity({
  tenantId: authenticatedTenant.id,
  accountId: resolvedInternalAccount.id,
  limit: 100, // 1..200
  cursor: previousPage.nextCursor,
});
```

Both scope values must come from authenticated server context. Cursors are
scope-bound and cannot be moved between accounts or tenants; the runtime also
revalidates the account-to-tenant mapping on every read. Pagination is a
newest-first operator view, not a gap-free change feed: a transaction that
commits after a page was read may have an earlier PostgreSQL sequence, so
refresh from the first page to discover concurrent late commits. Records include
the transition identity, health and observed-finality change, occurrence and
projection timestamps, issue IDs, period, and non-secret configuration/report
correlation references. They never embed revision rows, `sourceScope`,
subscriber destinations, credential handles, credentials, or `ctx_metadata`.
Each compact activity intent is capped at 64 KiB.
The runtime also applies atomic per-tenant backpressure at 100,000 pending
health notifications by default; tune `maxPendingPerTenant` to deployment
capacity and alert on the operational error instead of dropping durable intent.
This is an SDK/adopter API only: AdCP defines the complete health-notification
wire payload but no public account-activity read task, so do not expose `listActivity()`
as an invented wire extension.

`listActivity()` preserves the lifecycle-only compatibility surface. Use
`listNotificationActivity()` for the complete internal revision, adjustment,
and delivery-ready event stream. It remains an SDK/admin API, not an AdCP wire
task.

That lifecycle activity is distinct from the protocol's webhook transport
diagnostics. To support `list_accounts({ include_webhook_activity: true })`,
wire the principal-scoped attempt log into the same notification runtime:

This manual composition replaces the earlier `const notifications` block; it
reuses that block's `attemptCheckpoint` and installs exactly one notification
runtime. Prefer the production composer for new deployments.

```ts
import {
  composeNotificationDeliveryAttemptCheckpoints,
  composeWebhookAttemptResultObservers,
  createPostgresReportingWebhookActivityV1,
  projectListAccountsReportingWebhookActivityV1,
} from '@adcp/sdk';

const webhookActivity = createPostgresReportingWebhookActivityV1({
  db: pool,
  namespace: 'seller-production',
  retentionDays: 30, // protocol minimum
});

const notifications = createPostgresPersistentNotificationRuntime({
  db: pool,
  publisherScope: 'seller-production',
  checkpointDeliveryAttempt: composeNotificationDeliveryAttemptCheckpoints(
    attemptCheckpoint, // pin the recipient before publishing buyer-visible evidence
    webhookActivity.checkpointDeliveryAttempt, // diagnostics are the final pre-POST write
  ),
  webhooks: {
    ...webhookOptions,
    onAttemptResult: composeWebhookAttemptResultObservers(
      webhookActivity.emitterObservers.onAttemptResult,
      webhookOptions.onAttemptResult,
    ),
    onAttemptObserverError(error, phase) {
      webhookMetrics.recordObserverFailure(error, phase);
    },
  },
  ...notificationOptions,
});

for (const sql of webhookActivity.migrations.all) await pool.query(sql);
await webhookActivity.probe();

const response = await authoritativeListAccounts(params, ctx);
return projectListAccountsReportingWebhookActivityV1({
  response,
  request: params,
  tenantId: ctx.tenant.id,
  principalId: ctx.agent.agent_url,
  activity: webhookActivity,
});
```

Both scope values must come from authenticated context. The projector can only
decorate accounts already returned by the authoritative handler; it never
resolves additional accounts. It strips adopter-supplied `webhook_activity`
even when the buyer did not request the field, preventing permissive response
shapes from leaking arbitrary diagnostics. Rows are isolated by tenant,
principal, and account and ordered newest first.

The pre-POST reservation records `pending` before network I/O. The emitter's
awaited result observer completes it as `success`, `failed`, `timeout`, or
`connection_error`; observer failures never turn a successful remote POST into
a retry. A completion outage therefore leaves the honest `pending` record
rather than risking a duplicate send. Query strings, fragments, userinfo, and
all non-allowlisted path segments are removed before storage. Error text is a
fixed classification and never includes headers, bodies, exception prose, or
credentials. Schedule bounded `pruneCompleted()` calls; pending attempts are
retained for investigation. Advertise `supports_webhook_activity: true` only
after migrations and both notification/activity probes succeed.

Projected activity defaults to 90-day retention measured from projection (or
from commit for finality-only records that require no wire projection).
Abandoned activity is retained on the same schedule, measured from
`abandoned_at`. Override `retentionMs` only to match an explicit operator
policy, schedule bounded `pruneProjected()` calls — which reclaims projected and
abandoned rows alike — and retain pending rows until they are settled. The
reporting worker retries a failed projection up to `maxAttempts` (default 100)
and then abandons the claim; once the notification runtime has durably accepted
every matched subscriber, its own webhook outbox owns delivery retry and
retention. Supply `recoverOnce({ onError })` to report a
failed projection attempt without changing lease or retry semantics.
`matched` reports how many active subscribers were checkpointed; a projected
row with `matched: 0` is expected after revocation and does not claim network
delivery. Each recovery poll claims one row at a time so work waiting behind a
slow fanout is never left under an expiring pre-claimed lease.
The host remains responsible for a database-level retained-row/byte quota and
storage alerting per tenant or isolated deployment; the runtime's pending cap
protects delivery backlog but is not a general PostgreSQL storage quota.

### Recipient intent is frozen before any send, and revisable per recipient

The recovery worker commits its resolved recipients before anything leaves the
process, via `NotificationEvent.freezeRecipients`. The runtime then delivers
only the intersection of what is resolvable now and what was committed, so each
subscriber's `delivery_id` — and therefore the `idempotency_key` it dedupes on —
is stable across an ambiguous retry.

What makes a frozen set safely revisable is a second durable barrier:
`PersistentNotificationRuntimeOptions.checkpointDeliveryAttempt`, awaited on the
allow path of live delivery authority immediately before every external POST.
Wire `createPostgresReportingNotificationAttemptCheckpoint()` into it. It is a
runtime-level option keyed on the durable attempt context rather than a
per-emission closure because an emission snapshot cannot carry a function, so a
per-emission barrier would be skipped by the recovered outbox path — the path
where an ambiguous send is most likely.

The hook is runtime-wide, so the reporting checkpoint passes any event type it
does not own straight through. Failing closed on another subsystem's
notification would suppress every one of its attempts until the retry horizon
expired. `eventTypes` **extends** the owned set and can never shrink it —
`reporting.status_changed` is always owned, because a configuration that
silently stopped checkpointing reporting deliveries while the runtime still
advertised checkpoint support is the precise bug the checkpoint exists to
prevent.

The checkpoint is bound to the exact `(queryable, namespace, table)` it writes
to, and the activity runtime requires that same object as `attemptCheckpoint`.
It verifies in two tiers: when the port exposes `deliveryAttemptCheckpoint` —
the checkpoint it actually invokes — that must be the identical object, because
two correctly-built checkpoints can each look valid while targeting different
stores. When it does not, the declared store binding becomes mandatory and is
compared instead. Either way a mismatch is refused at construction. Configuring the two independently was
undetectable at runtime: the checkpoint's update matched no row, every attempt
was suppressed as retryable, the delivery binding eventually retired, the
recipient settled terminal and the activity projected — losing the notification
with no error anywhere.

Construction and `probe()` both fail closed unless the notification port proves
it runs the checkpoint. A custom `{ emit }` port must set
`hasDeliveryAttemptCheckpoint: true`, asserting that it forwards the event it is
handed to a runtime that does; otherwise a crash plus a destination replacement
re-addresses the notification under a second generation and idempotency key.
`acknowledgeMissingAttemptCheckpoint` exists only for tests that deliberately
demonstrate that hazard.

Declaring the capability is not sufficient, and is not trusted. Freeze and
checkpoint are one contract: a port that declares support but never calls
`freezeRecipients` leaves nothing addressable, so the checkpoint has no row to
mark and settlement would see zero outstanding recipients and record the
notification as delivered although nothing was sent. The runtime verifies that
the freeze actually ran and refuses to project the emission otherwise.

The checkpoint and a concurrent recipient replacement run as separate statements
against a pool, so neither sees the other's uncommitted work: a freeze can
propose a replacement generation while the original is being checkpointed, and
PostgreSQL keeps both rows. A partial unique index on
`(namespace, transition_id, subscriber_key) WHERE attempt_at IS NOT NULL` is the
arbiter — the second generation's checkpoint fails, so it is never POSTed, and
the next freeze drops it because its subscriber is already claimed.

Revisability is tracked **per recipient**, in `<activity_table>_recipients`:

- A recipient with no `attempt_at` provably never received a POST, because
  suppression fails closed before the checkpoint. It is replaced in place when
  it goes stale, which closes the window where a destination is replaced between
  candidate enumeration and the first POST.
- A recipient with `attempt_at` is pinned. Pinning is keyed on the **subscriber**,
  not the destination generation: once a subscriber has been addressed, a later
  generation of that subscriber is never addressed for this notification,
  because that would be one logical delivery under two idempotency keys.
- One recipient's attempt never pins a sibling. In a fanout, a subscriber
  suppressed stale before its own first POST is still re-resolved while an
  already-addressed sibling stays pinned.
- Unattempted rows are replaced rather than superseded, so a claim that retries
  many times before any send cannot accumulate rows. A settled recipient is left
  out of later emissions — it still gates projection, but re-addressing it would
  be redundant traffic.
- Settled history is compacted to one row per subscriber, and
  `maxRetainedRecipients` bounds **every retained row**. Counting only the
  addressable recipients let
  terminal rows grow for the lifetime of a claim that kept retrying while fresh
  subscribers settled.
- Every mutation — the replacement delete, the insert, compaction and
  settlement — takes a `FOR UPDATE` lock on the parent activity row before it
  touches a recipient, in a `MATERIALIZED` CTE so that lock is the statement's
  first act. Reading the lease without locking it only proved the lease was
  live when the snapshot was taken: a statement that then blocked on a
  recipient lock could resume after a successor had claimed, still see its own
  lease in the cached snapshot, and mutate the successor's rows. Holding the
  parent means a takeover cannot complete while a leaseholder's statement is in
  flight, and a statement starting after one matches nothing. Lock order is
  always parent then recipient, so the paths cannot deadlock.
- Every mutation is also gated on a live, matching lease, and so is the gate
  that authorises them. A stale worker sees an empty lease source, which makes every
  other source empty and the budget zero; gating only the row sources let that
  empty budget satisfy the check and reap the rows a successor had already
  frozen. After a takeover a stale worker is a strict no-op that refuses.
- `maxRecipients` bounds one emission's fanout and must be **at least** the
  notification runtime's `maxFanoutCandidates`. `maxRetainedRecipients` bounds
  every stored row — that fanout plus the pinned identities of subscribers
  addressed and then replaced — and defaults to twice `maxRecipients`. They are
  separate because a maximum 10,000-recipient fanout with one former subscriber
  pinned needs 10,001 rows, which a single bound capped at the fanout ceiling
  could never express. Setting either below what a notification legitimately
  needs is a misconfiguration: the claim retries until `maxAttempts` (default
  100) abandons it. An abandoned claim leaves the pending set — so it cannot
  exhaust `maxPendingPerTenant` and start refusing writes for the whole tenant —
  while staying visible as `notificationAbandonedAt` (the real abandonment
  instant) in account activity. It is never recorded as delivered.
- The bound and the replacement are one statement, and the rows it measures are
  taken `FOR UPDATE`. Measuring separately let a concurrent checkpoint turn a
  revisable row into a pinned one after the budget approved the write: the
  `DELETE` then re-checked the locked row, skipped it, and the retained set
  landed above the bound. Compaction runs before the budget, so a bound that
  compaction can satisfy never refuses, and a refusal mutates nothing — raise
  `maxRecipients` and the claim self-heals on its next pass.

| Replacement lands | Outcome |
| --- | --- |
| Before candidate enumeration | New generation enumerated and delivered |
| Between enumeration and the first POST | Suppressed `subscription_stale`, claim released, next pass replaces that recipient with the new generation; the superseded one gets nothing |
| After that recipient was checkpointed | Never re-addressed; the pinned recipient settles terminally |
| Revoked entirely | Empty recipient set is committed and the activity settles undelivered |

### Suppression is not delivery, and delivery is not settlement

Live delivery authority fails closed before every POST. Use
`notificationSuppressionDisposition(reason)` to tell the two kinds apart:

- **terminal** — `subscription_missing`, `subscription_inactive`,
  `event_not_allowed`, `authorization_denied`. The subscriber must not receive
  this event.
- **retryable** — `authorization_error`, `credential_unavailable`,
  `subscription_stale`, `attempt_checkpoint_unavailable`. Authority could not be
  established: a store read failed, an authorization or credential callback threw
  or timed out, the generation moved mid-flight, or the durable checkpoint could
  not be written. Nothing was sent (`attempts: 0`).

`subscription_stale` is the one reason whose disposition depends on the caller.
A live emission can re-resolve the new generation, so it stays retryable. A
**recovered** attempt (`WebhookEmitAttempt.recovered`) is pinned to the snapshot
it was taken from and can never become valid for a replaced generation, so it is
terminal — otherwise the outbox reclaims a dead delivery until its horizon
expires.

A delivery that throws is classified too: a retired binding or an exhausted
retry horizon surfaces as `failure.reason: 'delivery_binding_retired'` with
`terminal: true` and settles under terminal policy. Flattening it into a
retryable failure left the activity pending forever and eventually exhausted the
tenant's pending capacity.

A retryable suppression no longer terminalizes the delivery in the webhook
outbox either — it releases it, exactly as a retryable exhausted HTTP result
does, so the only durable record of the send survives for the outbox worker.

Projection requires **every** stored recipient to have reached a terminal
disposition: delivered, or deliberately not delivered. An outcome that never
reached a subscriber — a retryable suppression, a transport error, an exhausted
but retryable HTTP result — leaves the claim unsettled and the activity is not
recorded as delivered. The bundled runtime raises
`ReportingNotificationRetryableSuppressionError` for a retryable suppression.
Custom notification runtimes must implement the same barriers and the same
classification.

Intent is stored relationally, one row per recipient, keyed by a bounded 64-hex
fingerprint; only that fingerprint is indexed, so an individual recipient
reference has no length limit. `maxRecipients` defaults to 10,000 — the ceiling
the notification runtime enforces on `maxFanoutCandidates`.

Custom ledger stores implement
`ReportingLedgerNotificationActivityPortV1<TTransaction>` over their existing
authority transaction. Their `applyLifecycleProjection` equivalent must call
`recordTransition({ transition, obligation }, tx)` after its compare/lock and
before commit, and must roll back the authoritative transition if the port
fails. In the same transaction they must stamp `notifiedAt` as the durable
handoff marker. Stores must also compare `expectedPreviousFinality` with the
latest stored transition before applying a finality-only projection; this field
is optional only so pre-v14 implementations continue to compile during
migration.

That comparison must read **one** committed baseline, never a freshly
recomputed one. Transitions written from SDK 14 onward carry their own
`finality`, so the baseline is read straight back off the row. Pre-v14 rows
carry none, and their baseline is **not** reconstructed — it resolves to `none`,
which the store persists via
`resolveTransitionFinalityBaseline(reporting_obligation_id)` under its account
lock. `reconcileReportingStatusLifecycleV1` calls that port before deciding the
transition.

Stores that omit the port must also ignore `expectedPreviousFinality`, and
omitting it is **not** the same as returning `none`. The lifecycle cannot
persist a baseline on such a store's behalf, so it uses the currently observed
finality instead and the comparison becomes a no-op: finality is unobservable
there, health transitions still fire, and finality-only ones never do — exactly
the behaviour from before finality existed. Assuming `none` instead would make
every reconciliation tick observe `none -> official` and append another
finality-only transition, forever. Implement the port if you want finality-only
activity at all.

Do not try to reconstruct a historical baseline. Nothing already stored proves
which revisions had committed when a pre-v14 transition was recorded:

- **Payload timestamps** (a revision's `createdAt` against the transition's
  `occurredAt`) rank creation instants, not commits. A revision constructed
  before the transition but committed after it counts as already observed.
- **Insert wall clocks** (`recorded_at`, `created_at`, anything derived from
  `clock_timestamp()`) can repeat within a microsecond and can step backward, so
  a revision that committed after the transition can still compare equal or
  earlier. Comparing one against the transition's application-clock `occurredAt`
  additionally mixes clocks, so the store and the lifecycle decision disagree
  under skew and the compare-and-set wedges permanently.

Either rule can conclude `official`, which makes `previousFinality` equal
`finality` and silently suppresses the real snapshot→official transition and its
activity record forever. Resolving to `none` instead records at most one
redundant finality-only transition per obligation at upgrade, which stays
internal activity because the AdCP status webhook is health-only.

That bound holds only while no pre-v14 writer is still appending. During a
rolling deploy an old pod keeps writing finality-less transitions; each becomes
the latest row, gets its baseline committed as `none`, and produces another
redundant finality-only transition. Deploy ordering and wall clocks cannot rule
that out, so make it enforceable in the database.
`REPORTING_LEDGER_FINALITY_WRITER_FENCE_MIGRATION` adds

```sql
CHECK (data ? 'finality') NOT VALID
```

to `adcp_reporting_transitions`. `NOT VALID` is the whole point: PostgreSQL
enforces the constraint for every INSERT and UPDATE while leaving historical
rows unvalidated, so existing finality-less rows keep working and new
legacy-shaped writes are rejected. Two consequences to plan for:

- **Run it last**, after legacy pending transitions are drained and no old pod
  remains. A surviving legacy writer will fail its appends with
  `rejected by the finality writer fence`. That is deliberate — a loud rejection
  beats a quietly unbounded event stream.
- **Any UPDATE must leave the row fence-clean.** The baseline resolver and
  `markTransitionNotified` both write `finality` as part of their update, so a
  historical row is repaired by the same statement that touches it.

A store that implements neither the baseline port nor the optional `finality`
fields is treated as unable to observe finality at all: the baseline becomes the
currently observed finality, so the comparison is a no-op and no finality-only
transition is ever written. Without that, every reconciliation tick would see
`none -> official` and append another one forever. Such a store behaves exactly
as it did before finality existed — health transitions still fire.

Custom stores carry the same obligation: after cutover, reject any transition
write that does not record an observed finality, and enforce it in the storage
engine rather than in application code — an application-level check does not
bind a pod running last release's binary. Repair a historical row in the same
statement that mutates it.

The transaction argument must be one BEGIN/COMMIT-bound connection, never a
pool or autocommit queryable; the per-tenant advisory transaction lock provides
capacity serialization under READ COMMITTED. Never call the port in a
post-commit subscriber callback. The bundled
PostgreSQL activity runtime accepts only the active queryable transaction and
can therefore be reused by a custom PostgreSQL ledger without adopting the SDK
ledger tables.

The transactional port and legacy `ReportingLedgerSubscriberV1` callbacks are
mutually exclusive. The bundled store exposes that mode to lifecycle
reconciliation and fails closed if both are supplied, preventing double fire;
the port's pending rows, rather than `listPendingTransitions()`, own retry.

The activity table is deliberately separate from Core revision and obligation
rows. Managed Delivery/Reconciled Billing work can add immutable
materialization and receipt tables without changing this transition identity,
queue schema, or migration ordering.

`planObligations()` creates at most 1,000 obligations per call by default. Use its `account_id` and `maxObligations` options from a resumable scheduler when catching up dense or old schedules. Source executions are bounded to 10,000 objects, 1,000,000 rows, and 64 MiB per revision.

When `get_reporting_status` omits a period, the operational default horizon is the 24 hours ending at `ledger_as_of`. The `health` and `finality` arrays filter periods-view output only; they do not rewrite summary health or the underlying obligation projection.

In AdCP 3.2, `next_expected_at` has two deliberately different summary meanings. An open summary reports the next obligation due time (period end plus the frozen delivery SLA). A `complete` summary instead reports the nearest future period start, strictly after `ledger_as_of`, across configuration generations active in the selected scope. A periods response never carries this summary forecast. This wire-projection rule does not rewrite an obligation's immutable `expected_at`, historical snapshots, callback timing, or the installed schedule from which future boundaries are derived.

`projectReportingObligationHealthV1` is the pure five-state projection. Before `expectedAt`, missing evidence is `waiting`; during recovery it is `delayed`; after the recovery deadline it is `action_required`; readable qualifying evidence is `healthy` for an open scope and `complete` for a closed scope. An unfiltered closed scope with no caller-owned configurations or no due periods is vacuously `complete`; an explicitly unknown configuration returns `lookup_unavailable`, and a snapshot with missing elapsed obligations fails closed. The simplified lifecycle persists deterministic issues and `reporting.status_changed` transitions. In legacy mode it then calls only subscribers already authorized and supplied by the host; with the transactional port, finality-only changes stay in internal activity and health changes flow through the durable AdCP notification runtime. When the store implements the optional `getManagedLifecycleProjection`, the reconciler folds Managed Delivery through the same projection the read path uses, so a persisted transition and its webhook report the health a read of that obligation would return instead of Core health alone. Every managed instant is written at database precision: a JS `Date` holds milliseconds, so taking the batch instant through one truncated `recorded_at` below the microsecond watermark written from the same clock and the reconcile it should have triggered could never become due. The lifecycle projection reads each chain's leaf **as of the cutoff** — the receipt nothing recorded by then supersedes — rather than its whole history, because the leaf is the only thing the verdict uses. Asking which row is current *now* and only then applying the cutoff answered "neither" for a rejection an acceptance had since repaired, and persisted `RECEIPT_REQUIRED` over a rejection the buyer had already filed. Reading the history instead made an obligation whose subject was repaired more times than a snapshot page may carry — a state the receipt store admits — permanently unreconcilable. A leaf also stops being a leaf when its successor is pruned — the tombstone records what it superseded — or retention handed a settled subject back to the rejection its acceptance had replaced. The read path applies the same rule at the verdict: a tombstoned acceptance outranks a rejection it superseded, so `reconciliation_status` cannot report `rejected` for a subject the lifecycle considers settled. Evidence recorded after the cutoff is out of scope at that cutoff: revisions and adjustments alike are filtered by it exactly as receipts are — a revision committed after the cutoff arrives with no materialization and no receipt in scope and would read as an unmet consumer obligation, while the compare-and-set still fences on the full revision set, which is a concurrency check rather than a statement about an instant — by the store's own ordering column, not by the producer-authored `createdAt` on the body, because a producer clock running ahead otherwise hid a committed correction from the lifecycle while the public read, which orders by that column, kept demanding a receipt for it — and pruned conclusions carry the instant they concluded, so a historical reconcile cannot settle on an acceptance or a delivery that had not happened yet. The bound is now one leaf per (consumer, subject), which is the product of two dimensions the store admits independently, and crossing it — like an oversized roster or conclusion set — truncates at a deterministic boundary and reports `receiptEvidenceComplete: false` rather than failing: a bound the write path can legitimately cross must never be a hard error, and an incomplete projection is treated exactly as an unproven roster is, so it can never report an obligation reconciled. Wire counters are computed on the read path, which still sees every row. A projection that cannot be published is reported by `runWorker` as `reconcilesDeferred` rather than aborting the sweep — the durable write already committed and the obligation stays due, so the deadline sweep, which isolates and backs off per obligation, owns the retry. Reads are scoped to one authenticated consumer while a transition is account-level, so the reconciler keeps the most severe consumer: the seller's obligation is not reconciled until every consumer that owes a receipt has accepted. Consumer-specific issue codes — `RECEIPT_REQUIRED`, `RECEIPT_REJECTED`, `ADJUSTMENT_RECEIPT_REQUIRED`, `ADJUSTMENT_RECEIPT_REJECTED` — are deliberately excluded from that persisted set and from transition `issueIds`, because the issue store is keyed by obligation with no consumer dimension and reads republish persisted issues to whichever consumer is asking; publishing them would hand one consumer another's rejection state and exact receipt ingest timing. Their severity still reaches the account-level `health`, and each caller's own issues are recomputed per read. Aggregation runs over `obligatedConsumerIds`, not over whoever happens to have submitted, so a silent authorized consumer cannot vanish when another accepts. The managed tables carry no consumer dimension on destination authorizations or bindings, so the built-in PostgreSQL store cannot prove the roster is complete and reports `obligatedConsumerRosterComplete: false`; while that is false the reconciler keeps one zero-receipt consumer in the fold and never reports a `consumer_receipt` obligation reconciled. Supply the roster from your own authorization layer through the store's `obligatedConsumers` option — `(input: { reporting_obligation_id, account_id }) => Promise<{ ids, complete }>` — and return `complete: true` to get accurate reconciled transitions. Because the conservative default holds a `consumer_receipt` obligation at `action_required` from first delivery, and the per-consumer receipt issues are deliberately not persisted, the reconciler restates that state once per obligation as a `RECEIPT_REQUIRED` issue anchored to the obligation's own `expected_at`. It names no principal and carries no receipt timing, so a degraded persisted health is never unexplained and the leak stays closed.

## Consumer status ingest

The SDK is pinned to AdCP 3.2.5 and exposes `sync_reporting_status` from the ledger subpath. Its request, response, consumer-status, obligation, issue, delivery-capabilities, and reporting-status types come from the published 3.2.5 schema bundle.

```ts
const syncReportingStatus = createSyncReportingStatusHandler(store, {
  // Derive this only from authenticated transport; it is never a payload field.
  resolveConsumerId: context => context.agent.agent_url,
});

const getReportingStatus = createReportingStatusHandler(store, {
  resolveConsumerId: context => context.agent.agent_url,
});
```

Existing authoritative ledgers only need the narrow
`ReportingConsumerStatusLedgerStore` port—not the producer/worker store. An
adapter supplies `listConfigurations`, `getObligation`,
`getRevisionMetadata`, `readSnapshotPage`, `getConsumerStatusBatchReplay`, and
`syncConsumerStatusBatch`. Keep the adapter over the existing authority store:
derive the internal account and durable consumer principal from authenticated
transport, authorize before every replay or read, return immutable revision
bindings, and implement current-leaf compare + append + original batch-result
replay in one transaction. Several authorized principals for one external
account must receive separate `(internal account, consumer principal)` chain
namespaces; never create a second authority store or trust either identity from
the request body.

```ts
const statusStore: ReportingConsumerStatusLedgerStore = {
  listConfigurations: accountId => existingLedger.configurations(accountId),
  getObligation: (id, accountId) => existingLedger.obligationForAuthorizedCaller(id, accountId),
  getRevisionMetadata: (id, accountId) => existingLedger.boundRevision(id, accountId),
  readSnapshotPage: (id, accountId, cursor, limit) =>
    existingLedger.authorizedSnapshotPage(id, accountId, cursor, limit),
  getConsumerStatusBatchReplay: input => existingLedger.statusBatchReplay(input),
  syncConsumerStatusBatch: input => existingLedger.compareAppendAndReplayStatusBatch(input),
};
```

Use `reportingConsumerStatusChainKeyV1`,
`reportingConsumerStatusChainKeyFromIdentityV1`,
`reportingConsumerStatusFingerprintV1`, and
`normalizeReportingConsumerStatusIdsV1` from `@adcp/sdk/reporting/ledger` when
implementing duplicate, exact-leaf, unchanged, and replay behavior. This keeps
equivalent RFC 3339 spellings in one logical chain. `readSnapshotPage` is
optional; omitting it makes seller snapshot provenance unavailable without
blocking statuses that do not claim snapshot provenance. Store failure results
use `retryAfterSeconds` (integer seconds from 1 through 3600); invalid hints and
oversized custom codes are omitted or replaced before reaching the wire.

`sync_reporting_status` is a partial-success batch. The server validates the
closed request envelope, then the handler validates every status independently.
Custom handlers should parse each item with the exported
`ReportingConsumerStatusV1Schema` from `@adcp/sdk/reporting/ledger`; the ledger
handler already does this. The framework always applies strict envelope
validation for this task—even when general request validation is `warn` or
`off`—and rejects requests above 8 MiB, 10,000 JSON nodes, or the SDK maximum
JSON depth before dispatching either the built-in or a custom handler. Results
map one-for-one to submitted statuses in request order; inspect each `result`
even when the response envelope is `completed`. Custom handlers must also
reject every duplicate ID and every entry in a duplicate logical status chain.
`recorded_at` is seller-authored and response-only.

Clock-skew, ineligible-period, and too-early missing-status failures identify
the caller-controlled field. Obligation, revision, and snapshot mismatches are
intentionally indistinguishable so consumer status ingest cannot become an
existence oracle across retained ledger objects.

Per-item failures carry an explicit recovery classification. Schema and
authorization failures are `correctable`; an exhausted transient read slot is
`RATE_LIMITED`/`transient` with `retry_after`; oversized durable statements are
`REPORTING_STATUS_TOO_LARGE`/`correctable`; and exhausted append-only store
capacity is `REPORTING_STATUS_CAPACITY_EXHAUSTED`/`terminal`. The last two are
open-vocabulary AdCP extension codes, so clients must use their accompanying
`recovery` value rather than a closed code switch.

The language-neutral acceptance vectors ship at
`@adcp/sdk/compliance-fixtures/reporting-consumer-status-v1.json`. They pin
exact request bytes and SHA-256 digests, frozen clocks and principals, ordered
results, and post-operation ledger state so non-TypeScript adapters can run the
same contract without installing the SDK ledger as a second authority store.

The PostgreSQL store compares the exact current leaf for each consumer/configuration/report-definition/period chain in the same transaction that appends the new statement. An exact batch replay returns its original results; an identical status ID already recorded through another batch returns `unchanged`. Stale or omitted supersession fails without forking the chain. Periods readback includes only the authenticated consumer's history. A negative current statement—or a received statement naming a revision superseded by a later seller restatement—adds `CONSUMER_STATUS_MISMATCH` to that consumer's projection without changing seller-authored ledger evidence.

### rc.3 consumer-status hardening

`content_mismatch` is the fifth consumer status: the buyer consumed the exact
revision the seller requires and it contradicts a fact the accepted
configuration generation already fixed. It carries a required closed
`mismatch_code` (`scope_media_buy_missing`, `coverage_short`, `metric_missing`,
`schema_nonconformant`, `currency_mismatch`, `period_mismatch`) plus the
obligation id, the revision id, and the recomputed
`observed_revision_content_sha256`, so the disagreement names the exact bytes
that were read. It is **not** a measurement dispute — a buyer must not use it to
argue about how many impressions the seller counted; that is
`measurement_terms` / `makegood_policy` territory.

Not every conflict is an immediate escalation. A `received` statement made stale
*only* by a seller restatement projects the caller-scoped view as `delayed`
until a bounded re-read grace deadline, then `action_required`. The buyer read
exactly what the seller then required, so it gets one bounded chance to re-read
before the disagreement escalates. The deadline is the `created_at` of the
**first** revision that superseded the one the buyer named, plus the generation's
`schedule.delivery_sla` — or `automated_recovery_window_seconds` when that SLA is
zero, so a zero-SLA feed still yields a bounded window. Later restatements
supersede later revisions and therefore cannot restart it; a seller cannot hold
an unresolved mismatch below `action_required` by restating on a timer. Every
other conflict kind is `action_required` immediately.

`projectReportingConsumerStatusMismatchV1` is that projection as a pure
function, exported so a custom store can reuse the exact logic the built-in
handler runs. It returns the issue, the caller-scoped health it forces, and the
grace deadline when one applies.

Issues now carry `opened_at`, which is fixed at first emission and carried
unchanged across every re-emission — including across the `delayed` →
`action_required` transition, which reuses the same `issue_id` so consumers age
one work item instead of two. The SDK derives it from immutable ledger facts
(the first superseding revision's `created_at` for a stale read, the statement's
`recorded_at` otherwise) rather than from the read time, because advancing it on
re-emission would reset the escalation clock on every poll. Optional
`issue_state` (`open` / `acknowledged` only — a retired issue leaves the
projection instead of being published at `resolved` / `waived`) and
`external_ref` (inert correlation text, never dereferenced, never shared across
callers on a caller-scoped issue) round out the lifecycle.

Pass `consumerMismatchEscalation` to `createReportingStatusHandler` when the
capability document advertises `consumer_mismatch_escalation_seconds` and
`operations_contact` — the schema requires both or neither, so the escalation
always has a destination:

```ts
const getReportingStatus = createReportingStatusHandler(store, {
  resolveConsumerId: context => context.agent.agent_url,
  consumerMismatchEscalation: {
    escalationSeconds: 86_400,
    operationsContact: { email: 'reporting-ops@seller.example' },
  },
});
```

Advertise the same commitment in the capability document from that one value,
so the reads and the document cannot drift:

```ts
const escalation = {
  escalationSeconds: 86_400,
  operationsContact: { email: 'reporting-ops@seller.example' },
};

const reportingDelivery = {
  reliable_reporting_version: '1.0',
  consumer_status_task: 'sync_reporting_status',
  ...reportingConsumerStatusCapabilityV1(escalation), // consumer_mismatch_escalation_seconds + operations_contact
};

const getReportingStatus = createReportingStatusHandler(store, {
  resolveConsumerId,
  consumerMismatchEscalation: escalation,
});
```

Both entry points run the same validation, so a window with no destination — or
a `NaN` / negative one — fails at wiring time rather than silently never firing.
If you also apply the `health` query filter in a custom store, pass
`consumerMismatchEscalation` there too; the bundled `PostgresReportingLedgerStore`
takes it as a constructor option for exactly that reason.

Past `opened_at` plus that window an open mismatch is emitted at
`action_required` with a `contact_*` action naming the diagnosed responsible
party. `wait_for_retry` and `repair_access` are automation hints and neither
survives the boundary. The escalation boundary takes precedence over the
stale-received grace window when the two overlap. `operations_contact` is inert
display metadata for a human operator: agents surface it and MUST NOT fetch the
URL, send protocol traffic to it, or treat either value as a credential.

The summary view gains `obligation_counts.consumer_status_pending` whenever a
consumer principal is resolved (which is exactly when this handler advertises
`consumer_status_task`). It counts obligations whose consumer-status deadline —
`expected_at` plus `automated_recovery_window_seconds` — has passed with an
*empty* status chain for the authenticated caller. A chain with any unsuperseded
leaf counts as current whatever that leaf says. It is a visibility count over
the caller's own silence and never a health input: it does not change health,
any other count, or advertised reliability statistics, and it overlaps the
health counts rather than partitioning them.

Finally, `authoritative_party: 'consumer'` on a delivery configuration is
reserved for a buyer-deposited billing revision task that no released AdCP
version defines. `assertSupportedReportingAuthoritativeParty` refuses it with
`UNSUPPORTED_FEATURE`; call it from your `sync_accounts` handler on each
requested configuration, before the generation becomes ready and before any
obligation exists. `installConfiguration` already applies it. Do not coerce the
value to `seller` — that silently installs a different contract than the buyer
asked for.

Core revisions intentionally omit feed purpose, destination, obligation, and
recipient identity. Obligations sharing the same account, report definition,
period, media-buy scope, and canonical content therefore reuse one revision,
including fan-out across direct-Core and managed-materialization consumers.

For account-local calendar periods outside the stock `P1D` +
`source_timezone` path, expand each boundary externally into an immutable
configuration generation. Do not model a local day as a constant 86,400,000 ms
across daylight-saving changes. For example, the New York daily
periods `2026-03-08T05:00:00Z` → `2026-03-09T04:00:00Z` and
`2026-11-01T04:00:00Z` → `2026-11-02T05:00:00Z` use 82,800,000 and 90,000,000
milliseconds respectively. Give each generated boundary its own delivery
configuration version, set `anchor` and `installedAt` to the exact start,
`supersededAt` to the exact end, and set `periodMilliseconds` to `end - start`.
The repository-only fixture at
`test/fixtures/reporting-reconciliation/consumer-status.json` contains those
23/25-hour cases,
a calendar-month boundary, and the obligation-missing path with no invented
obligation ID.

### Observe consumer-status mismatches: `issueObserver`

A `CONSUMER_STATUS_MISMATCH` is caller-scoped: only the buyer whose
`sync_reporting_status` statement caused it sees it in `get_reporting_status`.
To hear about one without waiting for that buyer to poll, pass an
`issueObserver` (adcp-client#3648, the Python SDK's `issue_observer`):

```ts
import { createReliableReportingService, type ReportingIssueEventV1 } from '@adcp/sdk/reporting/service';

async function onIssue(event: ReportingIssueEventV1) {
  // Delivery is at least once: deduplicate on event.eventId.
  if (event.kind === 'resolved') return alerts.close(event.issueId, { dedupeKey: event.eventId });
  if (event.issue && event.issue.responsibleParty !== 'buyer') {
    await alerts.open(event.issueId, {
      dedupeKey: event.eventId,
      escalated: event.kind === 'escalated',
      action: event.issue.recommendedAction,
    });
  }
}

const reporting = createReliableReportingService({
  storage, // memoryStorage(), or postgresStorage({ pool }) with migration 0012 applied
  resolveConsumerId,
  consumerMismatchEscalation: {
    escalationSeconds: 4 * 3_600,
    operationsContact: { email: 'reporting-ops@seller.example' },
  },
  issueObserver: onIssue,
  // ...adapters, contact, resolveSource, resolveCurrency, resolveCoverage, windows
});
reporting.start({ intervalMilliseconds: 60_000, deploymentWide: true, onError: reportToSentry });
```

**When it is called.** Once per lifecycle transition of a mismatch occurrence:

| `event.kind` | The transition | Recorded |
| --- | --- | --- |
| `opened` | A consumer's current statement started to conflict with the seller's record: a negative statement landed, or a restatement made a `received` statement stale. | In the same transaction as that `sync_reporting_status` write or revision commit. |
| `escalated` | An open occurrence passed `openedAt` plus `consumerMismatchEscalation.escalationSeconds`, where the issue turns `action_required` with a `contact_*` action. | By `runCycle`'s sweep, which settles the obligation first so a cleared condition resolves instead. |
| `resolved` | The statement that caused it is no longer the consumer's current leaf (the buyer superseded it), or it no longer conflicts. | In the same transaction as the write that cleared it. |

An occurrence follows the read path's own projection, with one difference: while the seller's own
projection is degraded, `get_reporting_status` publishes the seller's issue instead of the mismatch,
but the disagreement still stands, so the occurrence stays open (and can escalate). An occurrence
needs at least one revision; a statement filed before the first one opens when it commits.

The kind union also has `acknowledged` and `waived`, the Python SDK's operator transitions
(`set_issue_state`). **No TypeScript store emits them yet**: the TypeScript ledger has no operator
issue-state API.

**Delivery needs `runCycle`.** The ledger records `opened` and `resolved` with the writes, but the
observer runs only on `runCycle` (`start()`, or your own scheduler), after the worker: it sweeps
escalations, then delivers committed events, each occurrence's in recording order with at most one
leased at a time. Without `runCycle` events are recorded but the observer is never called, and
`escalated` is never recorded. The Python SDK is the same: its worker turn does both.

**At least once.** An occurrence is `(issueId, consumerId)`: the `issueId` that `get_reporting_status`
publishes names the obligation and the causing `reporting_status_id` but not the consumer, and two
consumers may reuse one status id. Each transition is recorded exactly once, even when replicas make it
together (`(issueId, consumerId, kind)` is unique). A cycle that stops after the observer returned but
before the event was marked delivered delivers it again. Every delivery carries the same `eventId`,
`"rpie_" + sha256(canonical_json_utf8_v1(["reporting-issue-event-v1", issueId, consumerId, kind])).hex()[:40]`
(`reportingIssueEventIdV1`). That is the Python SDK's scheme with the consumer added: Python's `issue_id` is
already consumer-scoped, so it hashes `[tag, issue_id, kind]`. An exact retry of `sync_reporting_status`
(`unchanged`) and status reads record nothing.

**Failures never reach the buyer.** An observer that throws, or an async one past 10 seconds, is
retried on a later cycle after a backoff of 30 seconds doubling to one hour, with no limit;
`event.attempt` counts deliveries. The failure is handed to the scheduler's `onError` as a
`ReportingIssueObserverError` (`component: 'issue_observer'`, with `eventId`; `issue_events` when the
sweep or claim failed; `issue_events:snapshot` when the evidence could not be read, which is retried
rather than delivered unrendered) and returned in `runCycle(...).issueEvents.errors`.

**The event.** `eventId`, `kind`, `occurredAt` (the issue's `openedAt`, the escalation boundary, or when
it resolved), `accountId`, `consumerId`, `principal` (for a subscription obligation, on every kind including `resolved`, while the obligation is retained; omitted once retention removed it), `issueId`,
`reportingObligationId`, `reportingStatusId`, `attempt`, and `issue`: the `ReportingLedgerIssueV1`
`get_reporting_status` showed `consumerId` at `occurredAt` (`responsibleParty`, `recommendedAction`,
`severity`, `openedAt`). It is `null` for `resolved`, while the seller's own projection suppressed the
mismatch at that instant, and when the evidence is no longer retained. Rendering is best effort and
leaves Managed Delivery out.

**Storage.** `memoryStorage()` records issue events. On PostgreSQL, `@adcp/reporting-storage` needs
migration `0012 reporting_issue_events` (`npx adcp-reporting-storage migrate`): one new table and its
indexes, additive, so workers of an earlier release keep running beside it (they record no events for
their own writes). Until it is applied, writes record nothing, `postgresStorage().checkSchema()` names
`0012` as pending, and a store constructed directly refuses `issueObserver` at its first cycle. The
service refuses `issueObserver` at construction against a store that does not record issue events.
Retention prunes only closed occurrences: resolved, every event delivered more than seven days ago, and
unable to be derived again because the causing statement is no longer the consumer's current leaf or the
obligation is gone. An open occurrence is never pruned, however long ago its events were delivered: the
outbox is also the record of which occurrences are open, which a later supersession resolves and the sweep
escalates. A resolved occurrence whose statement is still current is kept too, as the anchor that stops a
later write recording its delivered events again under the same `eventId`.

When ledger retention retires a period (`retireExpiredPeriods`), its open occurrences resolve in the same
transaction, because nothing can resolve or escalate them once the obligation and statements are gone. The
`resolved` event is delivered like any other, with `issue: null` and no `principal`, and the occurrence is
then pruned.

**Production service.** `createPostgresReliableReportingProductionService` (`@adcp/reporting-storage/service`)
takes `issueObserver` too: it passes it to the core service whose `runCycle` and `start()` it drives, and
adds `REPORTING_ISSUE_EVENTS_MIGRATION` to `service.setup.migrations` when it is set. The Python SDK adds the
same in adcp-client-python#1873.

Composing the ledger without the service? Run
`createReportingIssueEventDispatcherV1({ store, observer, escalation }).runOnce({ accountId })` on your
own schedule.

**Known gaps against the Python SDK.**
- `acknowledged` and `waived` are never emitted (no operator issue-state API).
- A seller-side change never clears a TypeScript mismatch: the read projection only stops conflicting
  when the buyer supersedes its statement, while Python's `consumer_statement_conflicts` also clears
  `content_mismatch`, `revision_missing` and `unreadable` on the seller's own record change
  ([#3653](https://github.com/adcontextprotocol/adcp-client/issues/3653)). `commitRevision` already
  records `resolved` when the projection stops conflicting, so events follow once that is fixed.
- The issue id is per causing statement, not per chain occurrence, so a TypeScript and a Python seller
  publish different `issueId`s (and therefore `eventId`s) for the same disagreement, and the TypeScript
  `eventId` also hashes the consumer. Observers should not compare ids across SDKs.
