# Validate Your Agent

Your checklist to get from "agent boots" to "agent ships." Every tool below is already in `@adcp/sdk`; this page tells you which one runs when, what it catches, and how to read the output.

## TL;DR — five commands, roughly in order

```bash
# 1. Does it answer at all? (60s)
npx @adcp/sdk@15.9 http://localhost:3001/mcp get_adcp_capabilities '{}'              # MCP
npx @adcp/sdk@15.9 --protocol a2a http://localhost:3001 get_adcp_capabilities '{}'   # A2A (preview)

# 2. Does it walk the golden path? (2–5 min)
npx @adcp/sdk@15.9 storyboard run http://localhost:3001/mcp --auth $TOKEN            # MCP
npx @adcp/sdk@15.9 storyboard run --protocol a2a http://localhost:3001 --auth $TOKEN # A2A (preview)

# 3. Does it crash on weird inputs? (1–3 min)
npx @adcp/sdk@15.9 fuzz http://localhost:3001/mcp --auth-token $TOKEN

# 4. Does webhook/async conformance pass? (2–5 min)
npx @adcp/sdk@15.9 storyboard run http://localhost:3001/mcp \
  --webhook-receiver --auth $TOKEN

# 5. Does it survive horizontal scaling? (same as 2, two URLs)
npx @adcp/sdk@15.9 storyboard run \
  --url https://a.agent.example/mcp --url https://b.agent.example/mcp \
  sales-guaranteed --auth $TOKEN
```

If all five pass and your skill's specialism-specific checks below pass, you're conformant. The rest of this page explains why each check exists and how to debug failures.

**Serving both transports (MCP + A2A)?** If your agent mounts MCP and A2A on the same process (via `serve()` + `createA2AAdapter`), run command sets 1–2 against both endpoints — storyboards and capability checks are protocol-independent. MCP validators target the `/mcp` sub-path; A2A validators target the base URL. See [BUILD-AN-AGENT.md § Exposing your agent over A2A](./BUILD-AN-AGENT.md#exposing-your-agent-over-a2a-preview) for the dual-mount setup.

**Working on the agent locally?** Before you reach for the remote-agent commands above, see [`VALIDATE-LOCALLY.md`](./VALIDATE-LOCALLY.md) — the same storyboards, zero tunnel setup, ten lines of code. Point `--local-agent <module>` at your handlers or call `runAgainstLocalAgent` directly from a test file.

**Why `@15.9` in every `npx` command?** This selects the stable SDK 15.9 maintenance line, which bundles the current AdCP 3.2 and maintained 3.1 compliance corpora. Select the exact maintained 3.1 cache with `--compliance-version 3.1.31`. For reproducible CI, pin an exact published SDK version and verify its `ADCP_VERSION` and packaged compliance versions. The older `adcp-3.2` npm tag selects SDK 14 and does not supply the refreshed caches shown here.

---

## What catches what

| Command | What it catches | Run when |
|---|---|---|
| `adcp storyboard run` | Missing tools, broken happy-path flows, state leaks, validation drift, capability-vs-behavior mismatch | Every commit |
| `adcp fuzz` | Crashes on edge-case inputs, 500s instead of typed errors, schema drift, shape bugs your storyboards don't exercise | Before PR merge |
| `--webhook-receiver` | Unsigned webhooks, unstable `idempotency_key` across retries, missing HMAC/RFC 9421 headers | When you add webhook emission |
| `--url --url ...` (multi-instance) | `(brand, account)`-scoped state stored per-process instead of in a shared backing store | Before production deploy |
| `adcp grade request-signing` | RFC 9421 signature verification bugs if you claim `signed-requests` | If you claim `signed-requests` |
| `runConformance({ autoSeed: true })` | Tier-3 update-tool bugs with real IDs (not just random-rejection paths) | Against a sandbox tenant |
| Schema validation hooks | Field-name drift, enum drift, missing required fields — caught at dev time, not runtime | In your dev/test harness |

Each row is a different failure mode. Passing storyboard and failing fuzz is common — storyboards walk happy paths, fuzz walks rejection paths.

---

## Command reference

### `adcp storyboard run` — capability-driven assessment

The main compliance entry point. Runs every storyboard that applies to your agent based on its declared `get_adcp_capabilities` output.

```bash
# Full capability-driven run — resolves bundles from your capabilities
npx @adcp/sdk@15.9 storyboard run http://localhost:3001/mcp --auth $TOKEN

# Single bundle or storyboard by id
npx @adcp/sdk@15.9 storyboard run http://localhost:3001/mcp sales-guaranteed --auth $TOKEN

# Specific tracks only (faster feedback when iterating)
npx @adcp/sdk@15.9 storyboard run http://localhost:3001/mcp --tracks core,products --auth $TOKEN

# Pin a specific compliance cache/spec line
npx @adcp/sdk@15.9 storyboard run http://localhost:3001/mcp --compliance-version 3.1.31 --auth $TOKEN

# Ad-hoc YAML (new storyboards under development)
npx @adcp/sdk@15.9 storyboard run http://localhost:3001/mcp --file ./my-wip.yaml --auth $TOKEN

# JSON report for CI / tooling
npx @adcp/sdk@15.9 storyboard run http://localhost:3001/mcp --json > report.json
```

Writing a storyboard that applies only to agents declaring a capability? See
[STORYBOARD-CAPABILITY-GATES.md](./STORYBOARD-CAPABILITY-GATES.md) for the
`requires_capability` matchers, `any_of` groups and how older runners treat
them.

For a publisher split across sales, signals, governance, or creative tenants,
provide an agents map and omit the storyboard ID to assess the whole topology:

```yaml
# publisher.yaml
agents:
  sales:
    url: https://sales.example.com/mcp
  signals:
    url: https://signals.example.com/mcp
default_agent: sales
```

```bash
adcp storyboard run --agents-map ./publisher.yaml --json > report.json
adcp storyboard run --agents-map ./publisher.yaml --format junit > report.xml
```

The runner discovers every tenant, selects the union of storyboards applicable
to their declared capabilities, and evaluates `required_tools` against the
whole topology. JSON reports group executed results by tenant, with storyboards
that touch multiple tenants under `cross-tenant-topology`. JUnit uses the same
group as the suite package and name prefix.

Storyboard `response_schema` checks use strict JSON Schema validation for
grading by default, matching the hosted compliance grader. A strict failure
therefore fails the owning step even when the generated lenient Zod projection
would accept the response; `strict_validation_summary` still reports that
delta for diagnostics. Programmatic migration tooling can temporarily pass
`strictResponseSchemaValidation: false` to `runStoryboard()` or `comply()` to
restore the historical informational-only posture when using packaged schemas.
An explicit external `schemaRoot` always remains authoritative.
The CLI equivalent is `--no-strict-response-schema-validation`; reserve it for
temporary legacy compatibility harnesses rather than routine compliance runs.

**Flags you'll actually use:**

- `--tracks <a,b,c>` — limit to named tracks (e.g., `core,products,security_baseline`)
- `--storyboards <id1,id2>` — limit to specific storyboard IDs
- `--compliance-version <version>` — select the compliance cache/spec line used for resolution and request version intent; pass the same flag to `storyboard list`, `show`, and `step` when reproducing a pinned run
- `--compliance-dir <path>` — use a specific compliance cache directory for local protocol/cache development
- `--schema-root <path>` — use a matching external schema bundle for request/response validation; pair it with `--compliance-dir` when the two directories are not co-located
- `--webhook-receiver [loopback|proxy]` — host a webhook sink so async steps grade instead of skip
- `--webhook-receiver-auto-tunnel` — autodetect `ngrok`/`cloudflared` on `PATH`, spawn and plug into proxy mode
- `--invariants <mod1,mod2>` — load custom cross-step assertion modules
- `--multi-instance-strategy round-robin|multi-pass` — when paired with two or more `--url`s
- `--brief <text>` — custom product-discovery brief (default varies by storyboard)
- `--auth <token>` — bearer token (also accepts `$ADCP_AUTH_TOKEN`)
- `--oauth` — run the browser OAuth flow inline when the saved alias has no valid tokens (MCP only; equivalent to `adcp --save-auth <alias> <url> --oauth` then re-running)
- `--signing-transport raw|mcp|a2a` — how the `signed_requests` conformance vectors are framed on the wire. Not the same as `--transport`/`--protocol`. Default: inferred from the resolved protocol
- `--signing-skip-vectors <ids>` — comma-separated vector ids to exclude (graded `operator_skip`); unknown ids are rejected
- `--signing-skip-rate-abuse` — skip the rate-abuse vector, which floods cap+1 requests at the agent (bare flag; `=false` is rejected, not read as "off")

**Authoring webhook assertions.** Webhook storyboard pseudo-steps share the
receiver URL and filter contract. Use `triggered_by` to scope the observation
to the earlier step's `{{runner.webhook_url:<step_id>}}`; add `filter.body`
entries for dotted-path payload matching.

`expect_no_webhook` asserts silence: it passes only when zero matching
deliveries arrive during the observation window (five seconds by default) and
fails on the first match with `unexpected_webhook_received`. It deliberately
does not validate a payload schema or require an `idempotency_key` on the
passing path because no payload exists to inspect.

```yaml
- id: expect_sync_silence
  task: expect_no_webhook
  triggered_by: sync_get_products_with_webhook_config_success
  filter:
    body:
      operation_id: op_sync_get_products_no_webhook
  timeout_seconds: 5
```

All `expect_webhook*` steps require `webhook_receiver` runner support. If the
`triggered_by` step is missing, skipped, or failed, the assertion skips with
`prerequisite_failed` instead of treating the absence as a passing result.

### Why a storyboard failed when no step did

A storyboard's verdict (`overall_passed`) can be `false` while every step you
can see passed or was skipped. Every failing result says why:

| Field | Where | Meaning |
|---|---|---|
| `verdict_reason` | `StoryboardResult` (`storyboard run --json`), the `<storyboard_id>/storyboard` scenario in `tracks[].scenarios[]` | Primary cause, one of the codes below. Absent on a passing result. |
| `verdict_detail` | same | One line of runner-authored text. It names failed steps without quoting their errors. |
| `verdict_contributing[]` | same | Every step, assertion, phase or requirement behind the verdict: `kind`, `id`, `reason`, `status` (`failed` / `skipped` / `not_passed`), and where known `phase_id`, `pass_index`, `skip_reason`, `requirement`, `message`. At most 20 rows. |
| `verdict_explanations[]` | `ComplianceResult` (full assessment `--json`) | One entry per failing storyboard, with the fields above, `storyboard_level: true` when no `failures[]` row explains it, and a `fix_command` that re-runs the storyboard. |

| `verdict_reason` | What happened | What to do |
|---|---|---|
| `step_failed` | A step failed. Usually a counted failure; on a storyboard with only optional phases, a failed optional step. | Read that step's `error` and `validations`. |
| `assertion_failed` | A storyboard-level invariant (for example `status.monotonic`) failed, or an assertion failed on a skipped step. | Read the assertion row's `message`. |
| `controller_prerequisite_unmet` | Required steps needed `comply_test_controller` or its pre-flight seeding, and it was absent or seeding failed. | Implement the controller scenarios the storyboard names, or fix the seeding error. |
| `required_phase_not_executed` | A required phase did not pass because its steps were skipped (`prerequisite_failed`, `missing_tool`, `unsatisfied_contract`, `requirement_unmet`, a capability gate). | Follow each row's `skip_reason`. |
| `no_executed_steps` | Nothing failed, but no required step executed and passed. | Advertise the tools the storyboard needs. |
| `fixture_error` | Fixture resolution or preparation failed before the behavior under test ran. | Fix the fixture or test kit. |
| `coverage_unverified` | A request-signing storyboard never reached the agent. | Use a transport the vectors can frame. |
| `runner_error` | The runner or host refused to proceed. Not an agent failure. | Report it to whoever runs the grader. |
| `unexplained` | The runner could not attribute the verdict. | Report it as a runner bug. |

The fields explain the verdict. They never change `overall_passed`, the counts,
or any track or bundle grade. The human output of `adcp storyboard run` prints
the same reason under the summary line (`Why: [...]`).

### Running against pre-publish artifacts

Use a matching compliance bundle and schema root to validate a protocol build
before its matching SDK package is published:

```bash
adcp storyboard run https://agent.example.com/mcp \
  --compliance-dir /app/dist/compliance/latest \
  --schema-root /app/dist/schemas/latest
```

The supplied JSON Schema bundle is authoritative for storyboard request and
response validation. Same-change tools, fields, and controller scenarios do
not need to exist in the SDK's generated validator snapshot, and the workflow
does not write into `node_modules/@adcp/sdk`. A `schemas/latest` bundle may
retain `/schemas/latest/...` IDs when its root `index.json` declares the real
`adcp_version`; the index preserves cross-version validation fencing.

Programmatic runners can pair the two directories explicitly as well:

```ts
import { comply } from '@adcp/sdk/testing';

await comply(agentUrl, {
  version: '3.0.12',
  complianceDir: '/app/dist/compliance/3.0.12',
  schemaRoot: '/app/dist/schemas/3.0.12',
  adcpVersion: '3.0.12',
});
```

**Capabilities served at a newer release.** A 3.0 pin sends only
`adcp_major_version: 3`, so a conformant agent may serve and echo its highest
3.x release in `get_adcp_capabilities` (versioning spec, "Server echoes"). The
runner validates that one response against the echoed release when the echo is
the pin's major, is listed in the response's own `adcp.supported_versions`, and
has a schema root. That covers discovery's `capabilities_response_schema_invalid`
notices, `getAdcpCapabilities()` and every storyboard `response_schema` check on
`get_adcp_capabilities`, even with `schemaRoot` set for the pin. Otherwise it
validates strictly against the pin. Every other task's response, storyboard
selection, the run's `adcp_version` and grading stay on the pin.

The echoed release's schemas come from the SDK's bundle by default. A grader
that ships its own roots per release can supply them with
`servedReleaseSchemaRoots` (on `comply()`, `runStoryboard()` and
`runStoryboardStep()`), keyed by AdCP version:

```ts
await comply(agentUrl, {
  version: '3.0.27',
  complianceDir: '/app/dist/compliance/3.0.27',
  schemaRoot: '/app/dist/schemas/3.0.27',
  servedReleaseSchemaRoots: {
    '3.1.29': '/app/dist/schemas/3.1.29',
    '3.2.5': '/app/dist/schemas/3.2.5',
  },
});
```

Those roots are used only for that capabilities validation. Each one is checked
against its key once per process, and a mismatched or missing root throws
before the run starts. Callers that validate outside `comply()` and the runner
can scope the same map with `withServedReleaseSchemaRoots(roots, fn)` from
`@adcp/sdk/testing`.

**Multi-agent storyboards under `comply()`.** `comply()` grades one agent, so
storyboards that declare `requires: [multi_agent]` (for example the
governance-aware seller scenarios) skip with `requirement_unmet` and cap their
bundle at `partial`. A grader that can supply the other agents can route them
per storyboard with `routeStoryboard`; every other storyboard keeps the
ordinary single-URL run:

```ts
await comply(agentUrl, {
  auth: { type: 'bearer', token: ownerToken },
  routeStoryboard: storyboard => {
    if (!storyboard.requires?.includes('multi_agent')) return undefined; // unchanged run
    if (!canRoute(storyboard)) return { skip: `${storyboard.id}: no governance agent for this topology` };
    return {
      agents: {
        seller: { url: agentUrl }, // agent under test: inherits the run-level auth
        governance: { url: governanceUrl, auth: { type: 'bearer', token: governanceToken } },
      },
      default_agent: 'seller',
      context: { seller_agent_url: agentUrl },
    };
  },
});
```

A routed result lands in `tracks`, `failures`, `storyboards_executed` and
`bundle_results` like any other run, graded against the agent under test
only. A failed step, or a discovery failure, on another routed agent becomes a
`prerequisite_failed` coverage gap (`partial`, never `failing`). A routed
storyboard in which no step served by the agent under test passed cannot reach
`passing`. `{ skip }` records the same `requirement_unmet` row an unrouted
`multi_agent` storyboard gets, with your reason (control characters stripped)
as `skip.detail`, so the bundle stays `partial`. Storyboards whose root
capability predicate the agent under test does not satisfy are never passed to
the hook and stay `not_applicable`. The hook's `profile` argument is the
agent's own capability answer, so treat it as untrusted.

`comply()` throws on caller misconfiguration. That covers a `default_agent`
that is not the agent under test, an entry whose `auth` is not a real
credential object (only the agent-under-test entry may omit it; it then keeps
the run-level credential, which is dropped from the shared routed options), run-level
`headers` (they are sent to every routed agent), and a replacement
`storyboard` that changes phases, steps, validations or gates. A storyboard that
would send `$test_kit.auth` or `from_test_kit` credentials through a step not
pinned to the agent under test is recorded as a skip instead of being routed.
Run-level `transport`, including a `trustedFetchFn` egress guard, applies to
every routed agent. Version negotiation is done once, against the agent under
test, and shared by the routed agents.

**OAuth-protected agents.** Storyboard runs reuse tokens saved under an alias. Two supported flows:

```bash
# (a) pre-save tokens
npx @adcp/sdk@15.9 --save-auth my-agent https://agent.example.com/mcp --oauth
npx @adcp/sdk@15.9 storyboard run my-agent

# (b) inline on first run
npx @adcp/sdk@15.9 --save-auth my-agent https://agent.example.com/mcp --no-auth
npx @adcp/sdk@15.9 storyboard run my-agent --oauth
```

Either way, subsequent runs reuse the cached tokens (auto-refresh on expiry via the stored `refresh_token`). Raw URLs don't support `--oauth` — save an alias first.

**CI.** `--oauth` needs a browser. In CI, save tokens once locally, ship `~/.adcp/agents.json` to the runner, and drop the `--oauth` flag from the CI command — the stored `refresh_token` auto-renews on 401.

**Output:** JSON with `tracks[].status` (`passed`/`failed`/`skipped`), `steps[]` with diagnostics, and validations per step.

### Account-scoped fixtures and negative membership

Automatic `seed_product` and `seed_pricing_option` calls use the complete account
reference used by the storyboard: `context.account`, otherwise the single resolved
account in its effective sample requests or single-account provisioning request,
otherwise a single sandbox account fixture. Request overrides, context inputs, and
the run brand use the same account rules as public requests, except on tasks whose `account` names
the account the request is *about* — `list_accounts`, `get_account_financials`,
`list_account_changes`, and the `force_account_status` / `expire_account_change_cursor` controller
scenarios — where an already-resolved `account.brand` reaches the wire verbatim and the run brand
is only added when the reference carries none. Account provisioning
seeds retain their independent targets; only product and pricing seeds need a
shared catalog scope. Natural
keys retain brand countries, operator, operator unit, currency, and timezone.
 Opaque
`account_id` references stay opaque. A storyboard that uses several accounts must
provide an explicit `context.account` for its seeds; unresolved or ambiguous scope
fails setup rather than seeding a different default account. This is account
scoping, not a sandbox reset: fixtures for the same account may still coexist.

### `comply_test_controller` responses are graded now

Earlier SDK packages did not ship `compliance/comply-test-controller-{request,response}.json`, so
the selected release's JSON Schema check was unavailable for this tool. Packaging them enables it.
The SDK's generated Zod projection is a separate, weaker check and is unchanged. The test client's
response validation defaults to strict, so a controller response that the published JSON Schema
rejects can now fail a step that previously passed — with no change to your agent.

Validate your controller response against the response schema of the release you pin, and read the
`oneOf` arm that matches the request's `scenario`. The arms are scenario-shaped and the step text
shows only the first five AJV issues, so the summary is often arm-by-arm noise rather than the
error you need. Two causes worth checking first:

- **A missing top-level `status`.** The response composes `core/protocol-envelope.json`
  (`required: ['status']`) on 3.1.31, 3.2.8 and 3.3.0-rc.0. AdCP 3.0.25 composes no envelope and
  does not require it. The SDK's own `registerTestController` always sets it.
- **An `error` outside the published enum** — `INVALID_TRANSITION`, `INVALID_STATE`, `NOT_FOUND`,
  `UNKNOWN_SCENARIO`, `INVALID_PARAMS`, `FORBIDDEN`, `JCS_NON_FINITE_NUMBER`, `INTERNAL_ERROR`
  (3.0.25 omits `JCS_NON_FINITE_NUMBER`).

Fix the response: the contract did not change, only the SDK's ability to see it. If you need the
old informational-only posture while you do, use the `strictResponseSchemaValidation: false` /
`--no-strict-response-schema-validation` escape hatch described above — and heed the caveat there
about reserving it for temporary legacy harnesses.

For product-filter checks, exclude a known negative control rather than assuming
only one product can match. A validation entry can use:

```yaml
check: field_excludes
path: products[*].product_id
value: filter_negative_control
description: The seeded display control is absent from an OLV result
```

Declare `requires: [field_excludes_runner]` at the storyboard root (alongside
`controller` when needed). Supporting SDKs satisfy this intrinsic requirement;
older SDKs skip the scenario before seeding instead of silently ignoring an unknown
check. The matcher has the same scalar, deep-subset, and `allowed_values` semantics
as `field_contains`, inverted over **every** resolved terminal. Empty arrays pass;
additional matching products are allowed. Failed checks report the prohibited
terminal in the `actual` array and `expected.excludes` while preserving the
seller's response. Diagnostic evidence is bounded to the matching terminal;
absence is checked across the complete result.

### `adcp fuzz` — property-based schema fuzzing

Generates schema-valid requests, calls your agent, checks every response under the two-path oracle (schema-valid success *or* well-formed AdCP error envelope with uppercase reason code). Anything else — 500, stack traces, lowercase error codes, token leaks — fails.

```bash
# Tier 1 + Tier 2 stateless + referential (safe, no mutation)
npx @adcp/sdk@15.9 fuzz http://localhost:3001/mcp --auth-token $TOKEN

# Reproducible (rerun with same seed to repro a failure)
npx @adcp/sdk@15.9 fuzz http://localhost:3001/mcp --seed 42 --auth-token $TOKEN

# Pre-seeded ID pools for referential tools (Tier 2)
npx @adcp/sdk@15.9 fuzz http://localhost:3001/mcp \
  --fixture creative_ids=cre_a,cre_b \
  --fixture media_buy_ids=mb_1

# Auto-seed + Tier 3 update-tool fuzzing (mutates agent state — SANDBOX ONLY)
npx @adcp/sdk@15.9 fuzz http://localhost:3001/mcp --auto-seed --auth-token $TOKEN

# Uniform-error-response invariant in full cross-tenant mode
npx @adcp/sdk@15.9 fuzz http://localhost:3001/mcp \
  --auto-seed \
  --auth-token            $TENANT_A_TOKEN \
  --auth-token-cross-tenant $TENANT_B_TOKEN

# Inspect the tool list + tier classification
npx @adcp/sdk@15.9 fuzz --list-tools
```

See [`docs/guides/CONFORMANCE.md`](./CONFORMANCE.md) for the fixture map, tier-by-tier tool list, and failure interpretation.

#### Uniform-error-response invariant (paired probe)

`adcp fuzz` also runs a paired-probe invariant per AdCP spec § error-handling — the MUST that "the id exists but the caller lacks access" and "the id does not exist" produce byte-equivalent responses across every observable channel. Distinguishing the two leaks cross-tenant existence information.

Two modes, picked automatically:

- **Baseline** (default — single token): two fresh UUIDs probed at the same tool. Catches id-echo in error bodies, header divergence outside the narrow allowlist, MCP `isError` / A2A `task.status.state` divergence, and gross latency delta. Runs with zero extra config.
- **Cross-tenant** (two tokens): seeds a resource as tenant A (via `--auto-seed` or explicit `--fixture`), then probes as tenant B against tenant A's seeded id plus a fresh UUID. Catches everything baseline catches plus the cross-tenant existence leak itself. Triggered by `--auth-token-cross-tenant`.

What the comparator enforces:

- `error.code`, `error.message`, `error.field`, `error.details` identical
- HTTP status identical
- A2A `task.status.state` / MCP `isError` identical
- Response headers identical — **closed allowlist** of headers that MAY differ: `Date`, `Server`, `X-Request-Id`, `X-Correlation-Id`, `X-Trace-Id`, `Traceparent`, `Tracestate`. Everything else (`ETag`, `Cache-Control`, any `X-RateLimit-*`, CDN-tag headers, etc.) MUST match.

What to fix when it fails:

- **`error.code diverges`** — you're returning `PERMISSION_DENIED` (or similar) when the caller lacks access but `REFERENCE_NOT_FOUND` when the id doesn't exist. Collapse to one code — return `REFERENCE_NOT_FOUND` on both paths regardless of whether the id resolved before the access check.
- **`error.details diverges`** — you're echoing the probed id back in `details` (e.g., `details.looked_up = <uuid>`). Drop it or set it to a fixed token like `details.id_class = 'unresolvable'`.
- **`header "etag" diverges` / `header "cache-control" diverges`** — your cache layer is keyed on resolution success. Disable caching on the error path, or ensure the response envelope is constructed identically regardless of resolution state.
- **`MCP isError diverges`** — one path returns `isError: true`, the other doesn't. Both paths are errors; both MUST set `isError`.

**Tool coverage today**: `get_property_list`, `get_content_standards`, `get_media_buy_delivery`. The invariant runs whenever one of these appears in the fuzz tool set (the default). Extending to more referential tools is additive — see `src/lib/conformance/invariants/uniformError.ts` `TOOL_ID_CONFIG`.

##### Preparing for cross-tenant testing

To exercise the full invariant, stand up two test accounts against your agent before running fuzz:

1. Provision two isolated tenants (call them A and B). They MUST NOT share any resources beyond what the seller platform itself makes globally visible.
2. Obtain bearer tokens for each. Export as `ADCP_AUTH_TOKEN` (tenant A) and `ADCP_AUTH_TOKEN_CROSS_TENANT` (tenant B), or pass via `--auth-token` / `--auth-token-cross-tenant`.
3. Grant tenant A the minimum permissions needed to create the resources the seeder creates: property lists, content standards, media buys, creatives. Tenant B does not need create permissions — it only reads.
4. Confirm tenant B can authenticate against the agent (e.g., run `adcp --auth-token $TENANT_B_TOKEN https://your-agent/mcp get_adcp_capabilities '{}'`).

A single-tenant run still produces useful signal — baseline catches a significant subset of leaks, and the CLI flags cross-tenant mode as not exercised. Configure two tenants in your compliance CI so this check runs at full strength.

### Request signing — `adcp grade request-signing`

If you claim the `signed-requests` specialism, run the RFC 9421 grader. The grader signs its own requests with test keypairs from `compliance/cache/<version>/test-kits/signed-requests-runner.yaml` — no `--auth` flag; your agent's verifier must accept the runner's JWKS ahead of time.

```bash
# Grade the bundled request-signing vectors
npx @adcp/sdk@15.9 grade request-signing https://sandbox.agent.example/mcp

# Skip rate-abuse (vector 020 fires cap+1 requests; skip in dev loops)
npx @adcp/sdk@15.9 grade request-signing https://sandbox.agent.example/mcp --skip-rate-abuse

# MCP transport (wraps vectors in JSON-RPC envelopes)
npx @adcp/sdk@15.9 grade request-signing https://sandbox.agent.example/mcp --transport mcp

# Isolate a single vector
npx @adcp/sdk@15.9 grade request-signing https://sandbox.agent.example/mcp --only 016-replayed-nonce

# Grade the authored AdCP 3.2 signing profile
npx @adcp/sdk@15.9 grade request-signing https://sandbox.agent.example/mcp --signing-profile 3.2
```

`--signing-profile 3.2` selects only the 3.2 profile vectors from the bundled
compliance cache. Library callers can select
the same set with `gradeRequestSigning(agentUrl, { signingProfileVersion: '3.2' })`.

#### A2A operation-resolution vectors (`--transport a2a`)

`--transport a2a` also grades the A2A operation-resolution vectors (adcp#7945, GHSA-frxv-c96c-4vqw): `required_for` must be enforced against the operation named by the invocation DataPart's `skill`, not the JSON-RPC method, so an unsigned `SendMessage` carrying `create_media_buy` is rejected with `request_signature_required` and a body that does not resolve to exactly one operation is rejected with `request_body_malformed`. Unlike the other vectors these go out byte-for-byte (the defect is in the body) to the JSON-RPC endpoint your Agent Card declares; the four signed ones are re-signed over that URL. Rows are prefixed `a2a/` and tagged by tier: `contradiction-resolution` is MUST for a 3.2 verifier, `hardening` is SHOULD in 3.2.x and MUST from 3.3. Both count as failures; the summary under the table splits them. Pass `--required-for create_media_buy` (and `--protocol-methods-required-for SendMessage` for `negative/007`) so vectors for operations you do not require skip instead of failing. The two signed `create_media_buy` positives need `--allow-live-side-effects` against a non-sandbox endpoint. If the compliance bundle predates the vectors (a repo checkout falls back to a vendored copy; elsewhere point `ADCP_A2A_VECTORS_DIR` at one), the run says "a2a operation-resolution vectors unavailable in this compliance bundle" and reports a skipped `a2a/operation-resolution-vectors` row rather than passing silently.

#### Same vectors inside `storyboard run`

The `signed_requests` storyboard synthesizes one step per vector and grades them through the same engine. `storyboard run` exposes the knobs that matter there:

```bash
# Per-operation HTTP endpoints instead of a single MCP mount
npx @adcp/sdk@15.9 storyboard run https://sandbox.agent.example/adcp signed_requests \
  --signing-transport raw --auth $TOKEN

# Drop a vector your deployment can't satisfy, and the cap+1 flood
npx @adcp/sdk@15.9 storyboard run https://sandbox.agent.example/mcp signed_requests \
  --signing-skip-vectors 025-jwk-alg-crv-mismatch --signing-skip-rate-abuse --auth $TOKEN
```

- **`--signing-transport` is not `--transport`.** `--transport`/`--protocol` selects how the storyboard talks to your agent; `--signing-transport` selects how the conformance vectors are framed. Mirrors `adcp grade request-signing --transport`.
- **Leave it unset by default.** The vector transport is inferred from the resolved protocol: MCP frames each vector as a `tools/call` envelope; A2A signs the exact request emitted by the official `@a2a-js/sdk` client after Agent Card discovery.
- **The 3.2 signing profile follows the storyboard version.** Select a 3.2 compliance cache with `--compliance-version 3.2.5`; the `signed_requests` storyboard then selects its authored 3.2 profile vectors automatically. The `request_signing` options on `comply()` control transport and filtering; profile selection follows the resolved storyboard `adcp_version`.
- **A2A discovery fails closed.** If the Agent Card cannot resolve to a supported JSON-RPC interface, networked vectors skip with detailed reason `signing_transport_unavailable`; the storyboard cannot pass, the `security_transport` track stays `partial`, and the command exits 3. Publish a resolvable modern or legacy Agent Card, or grade an MCP/REST binding. Do not use `--soft-fail` to dismiss actual A2A verifier failures: once discovery succeeds, they are real grades.
- **The in-library vector remains transport-independent.** `025-jwk-alg-crv-mismatch` is decided against the SDK verifier with no wire exchange, so its result does not grade your agent.
- **Vectors excluded on their own terms say so, on every protocol.** `026-non-ascii-host` reports `transport_ungradable` (no HTTP client can carry a non-ASCII authority — `fetch` punycodes it first). `028-unsigned-protocol-method-required` reports `capability_profile_mismatch` unless your `get_adcp_capabilities` declares `request_signing.protocol_methods_required_for` — **this applies on MCP runs too, not just A2A**: previously the storyboard dispatched 028 at every agent, so one that never claimed the JSON-RPC bucket could fail it. Declare the bucket (e.g. `['tasks/cancel']`) if you verify signatures on protocol methods; a declaration your AdCP line's schema rejects is discarded rather than treated as "not declared", so it cannot suppress the vector. Note `adcp grade request-signing` does not read your advertisement — it uses the profile you pass it — so the two commands can disagree about 028 by design.
- **Vector `027-webhook-registration-authentication-unsigned` grades only while legacy HMAC is on.** From 3.3 it declares `applies_when: "webhook_signing.legacy_hmac_fallback == true"`. The storyboard reads your `get_adcp_capabilities` and reports `capability_profile_mismatch` when the flag is false or `webhook_signing` is absent, because such a seller rejects the registration with `UNSUPPORTED_FEATURE` instead. `adcp grade request-signing` does not read your advertisement; library callers can pass `agentCapabilities` to `gradeRequestSigning()` for the same check.
- **A run that graded nothing exits nonzero.** Skipped steps are `passed: true`, so a coverage gap used to exit 0. `adcp storyboard step` now exits 3 when the runner could not dispatch the step, and the full assessment exits 3 when a storyboard's signing coverage went unverified — including when your own `--signing-skip-vectors` removed every vector, which is the other way to end up with nothing graded. The message names which of the two happened. Everything else keeps exit 0: other `partial` runs, legacy fixture gaps, and single steps you excluded yourself. `--soft-fail` works on both commands and reports the gap while exiting 0.
- **Library callers get the same knobs.** `comply(agentUrl, { request_signing: { transport: 'mcp', skipVectors: [...], onlyVectors: [...], skipRateAbuse: true, rateAbuseCap: 5 } })` from `@adcp/sdk/testing` mirrors the storyboard CLI knobs. The standalone `gradeRequestSigning()` API also accepts `signingProfileVersion: '3.2'`, matching `adcp grade request-signing --signing-profile 3.2`. `storyboard run` prefixes transport and vector-filter flags because `--transport` is already taken by the storyboard's own transport.
- **Mistyped flag values are rejected.** `--signing-skip-vectors` validates every id against the shipped vector set (a typo silently skipped nothing before), and `--signing-skip-rate-abuse` refuses a value — `=false` used to read as "on".
- **Vector `025-jwk-alg-crv-mismatch` is graded in-library.** It publishes a malformed JWK your agent never serves, so there is no HTTP exchange: the step asserts the grader's verdict (`probe_passed`), not a 401.

> **Published 3.0 line.** These fixes ship on the 3.1 and 3.2 lines. The `adcp-3.0` dist-tag (`@adcp/sdk@7.11.x`) still defaults the vector transport to `raw` and has no `--signing-*` flags; an MCP-only agent must grade `signed_requests` from the 3.1 or 3.2 CLI (or drive `runStoryboard` with `request_signing: { transport: 'mcp' }`) until that line takes a backport.

### Multi-instance testing

Exposes `(brand, account)`-scoped state that lives per-process instead of in a shared store — a class of bug that single-URL runs never catch. See [`docs/guides/MULTI-INSTANCE-TESTING.md`](./MULTI-INSTANCE-TESTING.md).

```bash
npx @adcp/sdk@15.9 storyboard run \
  --url https://a.agent.example/mcp \
  --url https://b.agent.example/mcp \
  sales-guaranteed --auth $TOKEN
```

---

## Deterministic testing (force state transitions the happy path can't reach)

The `deterministic_testing` universal storyboard — plus rejection-branch and delivery-reporting sub-scenarios across several specialisms — requires your agent to expose `comply_test_controller`. Without it, the grader records `controller_detected: false` and skips or fails every step that needs a forced state transition, simulated delivery, or seeded error condition.

**Use `createComplyController`** — adapter-based scaffold that handles dispatch, param validation, typed error envelopes, and re-seed idempotency for you:

```typescript
import { createComplyController, TestControllerError } from '@adcp/sdk/testing';

const controller = createComplyController({
  // This is server-controlled deployment state. Every field in `input` is
  // buyer-supplied and MUST NOT be used as the authority boundary.
  sandboxGate: () => process.env.ADCP_SANDBOX === '1',
  seed: {
    buyer_agent: (params, ctx) => {
      const seededAccount = ctx.input.account ?? ctx.input.context?.account;
      const scope = [
        ctx.input.context?.session_id ? `session:${ctx.input.context.session_id}` : undefined,
        seededAccount ? `account:${JSON.stringify(seededAccount)}` : undefined,
      ].filter(Boolean).join('|');
      if (!scope) throw new TestControllerError('INVALID_PARAMS', 'seed_buyer_agent requires session_id or account scope');
      buyerAgentOverlay.upsert(scope, params.agent_url, {
        agent_url: params.agent_url,
        display_name: params.display_name ?? 'Compliance test buyer agent',
        status: params.status ?? 'active',
        billing_capabilities: new Set(params.billing_capabilities ?? ['operator']),
        sandbox_only: params.sandbox_only ?? true,
      });
    },
    product:  (params) => productRepo.upsert(params.product_id, params.fixture),
    creative: (params) => creativeRepo.upsert(params.creative_id, params.fixture),
    media_buy: (params) => mediaBuyRepo.upsert(params.media_buy_id, params.fixture),
    measurement_catalog: (params) => measurementRepo.seed(params.vendor, params.metrics, params.fixture),
  },
  force: {
    creative_status:  (params) => creativeRepo.transition(params.creative_id, params.status),
    creative_purge:   (params) => creativeRepo.purge(params.creative_id, params),
    media_buy_status: (params) => mediaBuyRepo.transition(params.media_buy_id, params.status),
  },
  simulate: {
    delivery: (params) => deliveryRepo.simulate(params),   // needed for delivery_reporting
  },
  queryProvenanceAuditObservations: (params) => auditRepo.observationsForCreative(params.creative_id),
});

controller.register(server);
```

Direct `controller.register(server)` calls without a `sandboxGate` are
refused. The only escape hatch is for deliberately ungated local harnesses:
set `NODE_ENV` to `test` or `development` **and** set
`ADCP_COMPLY_CONTROLLER_UNGATED=1`. `ADCP_SANDBOX=1` alone is not a request
gate and does not authorize ungated registration.

Migration for direct registrations: pass a `sandboxGate` that closes over
trusted server-side deployment or authentication state. The callback's
`input` argument contains buyer-supplied tool arguments, not trusted auth
context. For per-principal sandbox accounts, use
`createAdcpServerFromPlatform(platform, { complyTest })`; its framework-owned
registration resolves the authenticated account before dispatch.

Omit adapters you don't support — they auto-return `UNKNOWN_SCENARIO`. Throw `TestControllerError('INVALID_TRANSITION', msg, currentState)` when the state machine disallows a transition; the helper emits the typed envelope. `controller.register(server)` auto-emits `capabilities.compliance_testing.scenarios` per AdCP 3.0 — don't declare `compliance_testing` in `supported_protocols`.

If you build with `createAdcpServerFromPlatform`, pass the same adapters as
`complyTest` instead of calling `controller.register(server)` yourself, keep
`capabilities.compliance_testing` declared, and make
`accounts.resolve(undefined, ctx)` resolve the authenticated principal. The
framework derives `compliance_testing.scenarios`; hides the capability and tool
from live principals; filters `tools/list`; and makes live direct controller
calls look like MCP method-not-found. Sandbox/mock principals still see the
controller. Legacy resolved `{ sandbox: true }` accounts remain visible during
the migration, and `ADCP_SANDBOX=1` remains a temporary conformance deployment
bridge that fails closed after a live account is observed. `account.sandbox:
true` on the request is only an unresolved-target fallback after visibility; it
never makes a live principal visible and never overrides a resolved live target.
`PERMISSION_DENIED` is reserved for a visible sandbox/mock principal targeting a
live or unresolved non-sandbox account.

When a storyboard declares `fixtures.buyer_agents[]`, the runner sends `seed_buyer_agent` before product, pricing, creative, plan, or media-buy seeds. Use it to populate a session- or account-scoped `BuyerAgentRegistry` overlay so `accounts.resolve` / `sync_accounts` gates see the intended per-agent commercial state without inventing a test bearer prefix. Do not store these overlays process-wide by `agent_url` alone; the same compliance runner can seed different buyer-agent states for different sessions or accounts. The shipped AdCP 3.1 billing-gate storyboard still uses a static test-kit precondition until the upstream storyboard switches to this seed; supporting the seed now makes your agent ready for that switch.

```yaml
prerequisites:
  controller_seeding: true

fixtures:
  buyer_agents:
    - agent_url: "https://addie.example.com"
      display_name: "Addie compliance runner"
      status: active
      billing_capabilities: ["operator"]
      sandbox_only: true
```

The raw controller call has the same lifted shape: `agent_url` is a direct param and the commercial fields sit beside it, not under `fixture`.

```json
{
  "scenario": "seed_buyer_agent",
  "context": {
    "session_id": "storyboard-run-123"
  },
  "params": {
    "agent_url": "https://addie.example.com",
    "status": "active",
    "billing_capabilities": ["operator"],
    "sandbox_only": true
  }
}
```

If your overlay is account-scoped instead of session-scoped, put the account reference on either top-level `account` or `context.account`; the SDK includes both in seed idempotency scoping.

For domain state that carries internal structure (packages, revision, history) read by production tools, use `registerTestController(server, store)` — flat store surface, session-scoped factory. See `examples/seller-test-controller.ts`. Pick by state shape, not by helper tier — both sit on the same primitives and both auto-emit the capability block.

### Platform-proxy sellers (state-of-record lives upstream)

Sellers whose read path proxies to upstream platforms (`snapClient.getCreatives(...)`, `metaClient.getMediaBuy(...)`) don't read seeded fixtures from their own data layer — controller-seeded state is a dead write. Wire `TestControllerBridge` to feed those fixtures back into the read path on sandbox requests, without stubbing 13 upstream clients per adapter.

Worked fork target: `examples/proxy-seller-snap/` shows this pattern with a Snap-shaped upstream contract, resolved-account session keying, and product / creative / governance selectors.

```typescript
import { createAdcpServer, bridgeFromSessionStore } from '@adcp/sdk/server';

const server = createAdcpServer({
  // ... usual config + per-adapter handlers ...
  // Both paths are required: account-bearing tools use resolveAccount;
  // account-less tools use resolveAccountFromAuth. Resolve mode from trusted
  // server-side account state, never from the request's sandbox marker.
  resolveAccount: (ref, ctx) => accounts.resolve(ref, ctx),
  resolveAccountFromAuth: ctx => accounts.resolve(undefined, ctx),
  testController: bridgeFromSessionStore({
    loadSession: (_input, ctx) => sessionStore.loadForAccount(requireResolvedAccount(ctx.account)),

    // Each selector is opt-in by presence — wire the ones whose storyboards
    // your specialism gates on. Returned entries are validated (warn-and-drop
    // on shape errors, never throw) and merged into the matching tool's
    // response on sandbox requests only.
    selectSeededProducts:           s => s.seededProducts,          // get_products                                  → sales-* product discovery
    selectSeededCreatives:          s => s.seededCreatives,          // list_creatives                                → creative-* upload/listing
    selectSeededMediaBuys:          s => s.seededMediaBuys,          // get_media_buys                                → sales-non-guaranteed delivery-readback
    selectSeededMediaBuyDelivery:   s => s.seededDelivery,           // get_media_buy_delivery                        → sales-* delivery-snapshot assertions
    selectSeededAccounts:           s => s.seededAccounts,           // list_accounts                                 → audience-sync / governance-* multi-account
    selectSeededAccountFinancials:  s => s.seededFinancials,         // get_account_financials                        → governance-spend-authority financial readback
    selectSeededCreativeFormats:    s => s.seededFormats,            // list_creative_formats                         → creative-template / creative-generative
    selectSeededPropertyLists:      s => s.seededPropertyLists,      // list_property_lists + get_property_list       → property-lists / governance-aware-seller property catalog seeding
    selectSeededCollectionLists:    s => s.seededCollectionLists,    // list_collection_lists + get_collection_list   → collection-lists (program-level brand safety)
    selectSeededContentStandards:   s => s.seededContentStandards,   // list_content_standards + get_content_standards → content-standards (brand safety / suitability policies)
    selectSeededSignals:            s => s.seededSignals,             // get_signals                                   → signal-marketplace / signal-owned (signal_id discriminator handles both)
    selectSeededCreativeDelivery:   s => s.seededCreativeDelivery,    // get_creative_delivery                         → creative-ad-server / creative-template / creative-generative delivery readback
    selectSeededCreativeFeatures:   s => s.seededCreativeFeatures,    // get_creative_features                         → creative-* governance feature evaluation (feature-level overrides into success-arm results[])
    selectSeededBrandIdentity:      s => s.seededBrandIdentity,      // get_brand_identity                            → brand-rights identity discovery
    selectSeededRights:             s => s.seededRights,             // get_rights                                    → brand-rights rights discovery
    selectSeededSiOffering:         s => s.seededSiOffering,         // si_get_offering                               → sponsored-intelligence offering lookup
  }),
});
```

Bridge contract:

- **Triply gated.** Bridge runs only when the bridge is registered, the request carries a sandbox marker (`account.sandbox === true` or `context.sandbox === true`), and the applicable resolver returns a trusted account with `mode: 'sandbox' | 'mock'` (or legacy `sandbox: true`). Account-bearing tools use `resolveAccount`; account-less tools use `resolveAccountFromAuth`. Missing or null resolution fails closed. Production traffic is untouched.
- **Post-handler merge.** The adapter's real handler runs first (so a broken `snapClient.getCreatives()` still fails the conformance gate — the bridge supplements, it does not replace adapter behavior). Seeded entries append; on id collision the seeded fixture wins.
- **Singleton exception.** `get_account_financials` returns one account's envelope, so the bridge picks the seeded fixture whose `account.account_id` matches the request's `account.account_id` and REPLACES the handler envelope for that account. Other accounts pass through unchanged. When `resolveAccount` produces a record, the resolved `account_id` wins over the request's `account_id` — fixtures are interchangeable across `AccountReference` variants. The same pattern applies to `get_property_list` / `get_collection_list` (pick seeded entry by `list_id` matching `request.list_id`, replace the response's `list` field while preserving handler `identifiers` / `pagination` / `resolved_at` / `cache_valid_until` / `coverage_gaps` / `context` / `ext`), `get_content_standards` (pick by `standards_id`, replace the `ContentStandards` body and preserve handler's `context` and `ext`), `get_brand_identity` (pick by `brand_id`, replace the success body and preserve handler `context` / `ext`), and `si_get_offering` (pick by `offering.offering_id` matching `request.offering_id`, replace the response body and preserve handler `context` / `ext`). The seeded fixture array for each governance tool also feeds the matching list tool (`list_property_lists`, `list_collection_lists`, `list_content_standards`) via append-merge with seeded-wins on collision. `get_rights` is a discovery / search tool with an array response — append-merge by `rights_id`, seeded wins on collision (no list / singleton pair).
- **Delivery merge recomputes aggregated_totals.** `get_media_buy_delivery` is the one append-merge bridge that updates the response envelope: after seeded deliveries merge in (seeded wins on `media_buy_id` collision — matches the precedent set by the other five `getSeeded*` bridges, since storyboards seed deliberately and a seeded fixture for an existing id is an explicit author override), `aggregated_totals` is recomputed from the merged per-delivery `totals`. Required sums (`impressions`, `spend`, `media_buy_count`) always recompute. Optional sums (`clicks`, `completed_views`, `views`, `conversions`, `conversion_value`) only recompute when every merged delivery populates the field — partial population falls back to the handler's value (no silent under-counting). Derived ratios (`roas`, `completion_rate`, `cost_per_acquisition`) recompute only when both inputs were recomputed AND the divisor is non-zero. Pass-through fields (`reach`, `reach_unit`, `frequency`, `new_to_brand_rate`) keep the handler's value verbatim — they aren't derivable from per-delivery `totals`.
- **Validation drops invalid fixtures.** Entries missing the dedup id (`creative_id`, `media_buy_id`, `account_id`, `account.account_id`, `format_id.{agent_url,id}`, `list_id` for property + collection lists, `standards_id` for content standards, `signal_id.{source,id,data_provider_domain|agent_url}` for signals, `creative_id` for creative delivery, `feature_id` for creative features, `brand_id` for brand identity, `rights_id` for rights, `offering.offering_id` for SI offerings) are warn-and-dropped, not thrown — a broken test fixture shouldn't tank the request under test.
- **`get_creative_features` is the only nested-array merge.** `get_creative_features` returns a `oneOf` envelope. When the handler returned the success arm, seeded `CreativeFeatureResult[]` merge into the success arm's `results` array by `feature_id` (seeded wins on collision); framework-managed envelope fields (`context`, `ext`, `detail_url`, `pricing_option_id`, `vendor_cost`, `currency`, `consumption`) round-trip from the handler verbatim. When the handler returned the error arm, the bridge is a no-op — the error envelope passes through unchanged.
- **`_bridge` marker on augmented responses.** When the bridge merges seeded fixtures into a handler response, the framework stamps a non-normative `_bridge: { callback, tool, merged_count }` field on `structuredContent` (and mirrors it onto `content[0].text` when that body is JSON). This is the runner-visible signal that distinguishes _"this pass exercised the adopter's adapter against upstream"_ from _"this pass exercised wire conformance against fixture data merged by the SDK"_. Storyboard runners and compliance leaderboards read the marker to attribute bridge participation in run records — without it, a green storyboard step through fixture-merge reads identically to one that ran through a real adapter. The underscore prefix and AdCP's `additionalProperties: true` on every bridge-augmented response top level keep the marker schema-safe. Absent when no merge occurred (callback omitted, non-sandbox traffic, or singleton-replace fixture didn't match the request id). Marker payload:

  - `callback` — bridge callback that produced the seeded entries (e.g. `getSeededCreatives`)
  - `tool` — tool name whose response was augmented (mirrors envelope context)
  - `merged_count` — number of post-validation seeded entries the callback returned

  **Interpreting a bridge-augmented pass:** wire conformance against fixture data, _not_ adapter-against-upstream health. Pair the conformance suite with a separate live-OAuth run against the real upstream platform before promoting an adapter to production. **If you're a buyer reading a compliance score**, treat `_bridge`-marked passes as supplier wire-readiness, not as evidence the adapter can fulfill against the live upstream — a fully bridge-augmented response array (`merged_count` equal to the response's entry count) means every entry came from a fixture; a `merged_count` smaller than the response's entry count means the bridge supplemented a real adapter call. The leaderboard policy that surfaces this distinction is tracked in [`adcp-client#1782`](https://github.com/adcontextprotocol/adcp-client/issues/1782); see [`adcp-client#1775`](https://github.com/adcontextprotocol/adcp-client/issues/1775) for the cross-repo coordination context (storyboard runner surfacing).

Plain hand-rolled `TestControllerBridge` (no session store) is also supported — wire `getSeededProducts` / `getSeededCreatives` / etc. directly. See `src/lib/server/test-controller-bridge.ts` for the interface.

---

## Schema-driven validation (catch field drift at dev time)

Wire AJV-based validation into your client or server so payload drift surfaces in tests, not production:

```typescript
// Client side — strict response validation in dev
import { SingleAgentClient } from '@adcp/sdk';

const client = new SingleAgentClient(url, {
  validation: {
    requests: 'warn',        // log shape issues before they hit the wire
    responses: 'strict',     // throw on schema mismatch from the agent
  },
});

// Server side — opt-in validation on incoming requests + handler responses
import { createAdcpServerFromPlatform } from '@adcp/sdk/server';

createAdcpServerFromPlatform(platform, {
  name: 'My Agent',
  version: '1.0.0',
  validation: {
    requests: 'strict',      // reject malformed requests with VALIDATION_ERROR
    responses: 'strict',     // catch handler-returned drift (dev/test canary)
  },
});
```

Modes are `'strict'` (throw/reject), `'warn'` (log, continue), or `'off'` (skip, default). One AJV compile per tool on cold start; one validator invocation per call. Cheap in dev, optional in prod hot paths.

Validation issues carry path + expected-vs-actual so the fix location is obvious. Cheap to enable in CI, cheap to disable in prod hot paths.

---

## Cross-step invariants (custom assertions)

Use `--invariants` to load modules that assert properties across storyboard steps. Example invariant: "every mutating call's `idempotency_key` is echoed in the response," "no secret in `$TOKEN` ever appears in any response body," "governance denial MUST block every subsequent mutation in the same session."

```bash
# Load ./my-invariants.js (relative path) or a bare specifier (npm package)
npx @adcp/sdk@15.9 storyboard run http://localhost:3001/mcp \
  --invariants ./assertions/idempotency.js,@my-org/adcp-invariants
```

The invariant module calls `registerAssertion({ id, onStep, onEnd, ... })`; failures flip `overall_passed` to `false`. Assertion modules ship upstream as part of the AdCP spec; the SDK provides the registry + CLI wire-up.

---

## Substitution verification (catalog-driven sellers)

If you ship catalog-driven products with macro-expandable tracker URLs, wire `SubstitutionEncoder` into your seller-side macro path and `SubstitutionObserver` into your test harness:

```typescript
import {
  SubstitutionEncoder,
  SubstitutionObserver,
  CATALOG_MACRO_VECTORS,
} from '@adcp/sdk';

// Seller side — encode every substituted value:
const encoder = new SubstitutionEncoder();
const url = template.replace(macro, encoder.encode_for_url_context(rawValue));

// Runner side — parse preview HTML, match bindings, assert RFC 3986 safety:
const observer = new SubstitutionObserver();
const records = observer.parse_html(previewHtml);
const matches = observer.match_bindings(records, template, bindings);
for (const m of matches) {
  const result = observer.assert_rfc3986_safe(m);
  if (!result.ok) throw new Error(result.error_code); // substitution_encoding_violation, etc.
}
```

Unencoded substitution is a common XSS / scheme-injection vector. `CATALOG_MACRO_VECTORS` exports the seven canonical test bindings (`url-scheme-injection-neutralized`, `reserved-character-breakout`, `nested-expansion-preserved-as-literal`, etc.). For preview-URL fetches, `observer.fetch_and_parse(url)` enforces an SSRF policy — DNS revalidation, bare-IP rejection, cloud-metadata deny — before the HTTP connect.

For pixel URLs that mix AdCP universal macros with a platform's native macro syntax, use `translateUniversalMacros`. Native mappings are inserted verbatim; literal values are RFC 3986 encoded. A native mapping containing U+0000–U+001F or U+007F throws `UnsafeNativeMappingError` before any URL is emitted, even when that mapping is unused. Consent macros frozen through literal `value` mappings remain encoded and are reported in `frozen_consent_macros` for advisory handling:

```typescript
import { translateUniversalMacros, UnsafeNativeMappingError } from '@adcp/sdk';

try {
  const translated = translateUniversalMacros(pixelUrl, {
    '{CACHEBUSTER}': { native: '%%CACHEBUSTER%%' },
    '{GPP_STRING}': { value: consentSnapshot },
  });
  if ((translated.frozen_consent_macros?.length ?? 0) > 0) {
    auditConsentSnapshot(translated.frozen_consent_macros ?? []);
  }
  emitPixel(translated.url);
} catch (error) {
  if (error instanceof UnsafeNativeMappingError) {
    // `message` includes the exact mapping key in a log-safe escaped form.
    rejectMapping(error.code, error.message);
  }
  throw error;
}
```

These policies follow the language-neutral fixture ratified in [AdCP #6674](https://github.com/adcontextprotocol/adcp/issues/6674).

The AdCP 3.3 fixture also covers vendor-scoped `{GDPR_CONSENT_<gvl_id>}` and
`{ADDTL_CONSENT}`. Preserve the receiving vendor ID and treat Additional Consent
as opaque CMP data. Both participate in dropped/frozen consent diagnostics.
After unsupported parameters are dropped, a URL with multiple scoped TCF
occurrences throws `MultipleVendorConsentMacrosError` (exported from both
`@adcp/sdk` and `@adcp/sdk/substitution`), with code
`multiple_vendor_consent_macros` and the canonical second token in `macro`.
Existing native tokens and verified native aliases count; encoded concrete
values and Additional Consent do not. See the
[compilation guide](UNIVERSAL-MACRO-COMPILATION.md) for mapping and schema-version
boundaries.

---

## The fork-matrix: canonical adapter → compliance

`test/examples/hello-*.test.js` is the canonical compliance gate. Each test boots the matching `examples/hello_*_adapter_*.ts` reference adapter against a mock-server upstream, runs the storyboard grader, and verifies upstream traffic — the three-gate contract documented in [`docs/guides/EXAMPLE-TEST-CONTRACT.md`](EXAMPLE-TEST-CONTRACT.md): tsc strict / storyboard zero-failures / upstream façade. Adopters inherit the gate by extending the test file with their own adapter path and `expectedRoutes`.

> **Mock-server is the reference implementation, not one of many.** When the grader rejects your agent's response, follow the spec's normative triage order: [`spec → mock → SDK`](https://adcontextprotocol.org/docs/building/verification/conformance#mock-server-authority-and-failure-triage). The mock is the authoritative interpretation of the wire contract — if your agent diverges from the mock, your agent is wrong by default. Only when the spec itself contradicts the mock should you file an issue on `adcontextprotocol/adcp`.

```bash
# Run every fork-target gate (deterministic, ~10s parallel)
npm run compliance:fork-matrix

# Or one specialism
npm run compliance:fork-matrix -- --test-name-pattern="hello-seller-adapter-guaranteed"
```

Use before merging adapter or skill changes. Deterministic — no LLM variance, no minutes-long Claude spin-up.

> **Note:** storyboards with webhook steps (e.g. `webhook_emission`) hold the grader subprocess open until the agent emits a webhook. If your agent doesn't emit one, the harness kills the subprocess after 120s and logs `grader: subprocess timed out` — this is a harness-level timeout, not a conformance failure from your agent's response.

---

## Reading `💡 Hint:` lines (context-value rejections)

> **If you see a `💡 Hint:` line, the fix is almost always in your catalog, not the SDK.** The two tools named in the hint are returning inconsistent values — unify their source.

Example output:

```
❌ Activate PII signal (412ms)
   Task: activate_signal
   Error: Pricing option not found: po_prism_abandoner_cpm
   💡 Hint: Rejected `pricing_option_id: po_prism_abandoner_cpm` was extracted
           from `$context.first_signal_pricing_option_id` (set by step
           `search_by_spec` from response path
           `signals[0].pricing_options[0].pricing_option_id`). Seller's
           accepted values: [po_prism_cart_cpm].
```

The runner is telling you:

1. Step `search_by_spec` wrote `po_prism_abandoner_cpm` into `$context.first_signal_pricing_option_id` — extracted from `signals[0].pricing_options[0].pricing_option_id` on your own `get_signals` response.
2. Step `activate_signal` sent that id back to you.
3. Your `activate_signal` handler rejected it with `available: [po_prism_cart_cpm]`.

So **`get_signals` advertised one id and `activate_signal` accepted a different one**. **Fix by unifying the catalog source** — typically both handlers should read from the same store ([build-seller-agent/SKILL.md](../../skills/build-seller-agent/SKILL.md) covers the shared-store pattern).

The runner only prints a hint when it can trace the rejected value back to a prior-step `$context.*` write. **No hint?** The mismatch came from somewhere else — a hardcoded `sample_request` in the storyboard, a stale fixture, or a `--request` override. Fix the storyboard, not the handler.

Hints are diagnostic-only; pass/fail is decided by the step result, not by hint presence.

### For CI dashboards

Hints also land in machine-readable output:

- **JUnit XML** — appended to the `<failure>` body as `Hint (context_value_rejected): …`, and used as the `message=` attribute when `step.error` is empty (e.g. validation-only failures on 200-OK responses):

  ```xml
  <failure message="Rejected `pricing_option_id: po_prism_abandoner_cpm` …" type="StoryboardFailure">
  Pricing option not found: po_prism_abandoner_cpm
  Hint (context_value_rejected): Rejected `pricing_option_id: po_prism_abandoner_cpm` …
  </failure>
  ```

- **JSON report** (`--format json`) — on `StoryboardStepResult.hints[]` as `ContextValueRejectedHint` objects. Fields: `kind`, `context_key`, `source_step_id`, `source_kind`, `response_path`, `source_task`, `rejected_value`, `request_field`, `accepted_values`, `error_code`, `message`. Dashboards can aggregate rejections by `source_step_id` or `context_key` to spot systemic catalog-drift. See `StoryboardStepHint` / `ContextValueRejectedHint` types exported from `@adcp/sdk/testing`.

> The rejection-envelope shape (`errors[].details.available` etc.) is tracked in [adcontextprotocol/adcp#3049](https://github.com/adcontextprotocol/adcp/issues/3049); field names here may evolve as the spec pins a canonical key.

---

## When each check fails: debug first-lookups

| Failure | First lookup |
|---|---|
| `storyboard run` skips steps with "no webhook_receiver_runner" | Add `--webhook-receiver` |
| `storyboard run` fails on `security_baseline` | You skipped `authenticate` in `serve()` — see [build-seller-agent/SKILL.md § signed-requests](../../skills/build-seller-agent/SKILL.md) |
| `None of the required contributions were recorded: ["auth_mechanism_verified"]` | No auth mechanism could be verified. If your steps also show task `mcp_session_probe`, your read surface is outside the probe allowlist and the runner fell back to the MCP session probe — see the next rows |
| `Skipped (not_applicable / session_probe_ungradable)` | The runner prints the full reason and remedy on the line directly below. Four causes: (1) you advertise no **canonical AdCP** read task the probe can call with an empty body — tool names you invented are not eligible, and public-tier (`get_adcp_capabilities`, `get_products`, `list_products`, `list_creative_formats`) and mutating tools are excluded by design; (2) the step is a positive static-credential probe the session probe cannot grade; (3) the run signs functional dispatch and your `request_signing` advertisement covers every target the probe could call; (4) the run passed a `-H` header the runner can classify neither as a credential nor as routing — that one is about how the run was invoked, not about your agent, and the detail names the header. **A static-credential-only agent with no allowlisted read tool cannot be certified**: the positive probe asserts an AdCP response body no protocol operation produces, so its branch's contribution gate stays closed. Two remedies: advertise one allowlisted read tool (`list_creatives`, `get_media_buy_delivery`, `list_authorized_properties`, `get_signals`, `list_property_lists`, `list_collection_lists`, `list_content_standards`, `list_accounts`) — the durable fix — or serve RFC 9728 metadata and run with `--oauth` so the OAuth branch is verified instead |
| `Error: MCP session auth probe is inconclusive: …` | A rejection is auth evidence only when a valid credential of the **same kind** reaches the same protected tool. The message names what is missing: no OAuth access token for this run (run with `--oauth`), no API key / Basic credential configured, the valid credential was refused too, or the agent refused the *shape* of the call (advertise a tool that accepts an empty request body) |
| `Error: MCP session auth probe refuses this as auth evidence: …` | The probe's bad or absent credential got a successful payload from your protected tool — it is serving tenant-scoped data to anyone — or a valid credential failed to reach it |
| `Error: MCP session probe could not run: …` | Not an authentication result at all: a wire version this SDK does not implement, a response shape the official MCP client rejects, or an exchange that never completed. Nothing was learned about your credentials; fix the named protocol problem and re-run |
| `extraction.note` reads `MCP session probe graded <tool> at <stage>` | Which protected tool the verdict rests on, and where the agent decided (`initialize` for session-boundary auth, `tools/call` for per-operation auth). The verdict is evidence that the mechanism is enforced **at that tool** — it is not a claim that every tool enforces auth |
| `storyboard run` reports `Agent requires OAuth` / exits without running | Save tokens once with `adcp --save-auth <alias> <url> --oauth`, or pass `--oauth` to `storyboard run` to complete auth inline |
| `storyboard run` prints `💡 Hint: Rejected …` below an error | Catalog inconsistency between the two tools — see [§ Reading hint lines](#reading--hint-lines-context-value-rejections) above |
| `fuzz` reports `500` status with stack trace | Validate inputs and return `adcpError('REFERENCE_NOT_FOUND', ...)` instead |
| `fuzz` reports `response_shape_mismatch` | Response drifted from schema — regen with `npm run sync-schemas` + check your handler |
| Multi-instance fails with `NOT_FOUND` on read-after-write | State keyed by session ID instead of `(brand, account)` — see multi-instance guide |
| `grade request-signing` fails every negative vector | Missing `verifyRequestSignature` middleware; see [build-seller-agent/SKILL.md § signed-requests](../../skills/build-seller-agent/SKILL.md) |
| `--invariants` load errors | Relative path relative to cwd; bare specifier requires installed package |

---

## CI recipes

### Per-PR smoke (fast, blocks merge)

```yaml
- name: Storyboard (core + products)
  run: npx @adcp/sdk@15.9 storyboard run $AGENT_URL --tracks core,products --auth $TOKEN
- name: Fuzz (fixed seed)
  run: npx @adcp/sdk@15.9 fuzz $AGENT_URL --seed 42 --auth-token $TOKEN --format json
```

### Nightly (slow, broader coverage)

```yaml
- name: Fuzz (random seed, auto-seed)
  run: npx @adcp/sdk@15.9 fuzz $AGENT_URL --auto-seed --auth-token $TOKEN
- name: Full storyboard assessment
  run: npx @adcp/sdk@15.9 storyboard run $AGENT_URL --auth $TOKEN --json > report.json
```

Random seed on nightly broadens the surface; fixed seed on per-PR keeps reproducibility.

---

## Deeper dives

- [`CONFORMANCE.md`](./CONFORMANCE.md) — `runConformance` + `adcp fuzz` in depth
- [`MULTI-INSTANCE-TESTING.md`](./MULTI-INSTANCE-TESTING.md) — horizontal scaling bug hunt
- [`BUILD-AN-AGENT.md`](./BUILD-AN-AGENT.md) — server-side implementation
- `skills/build-*-agent/SKILL.md` — per-specialism obligations and storyboard IDs


For creative evaluator security fixtures, see
[Creative evaluator build probes](CREATIVE-BUILD-PROBE.md) for valid route/input
preparation, provisioned legacy selectors and explicit coverage gaps.

SDK 17 controller registration preserves complete account identity and requires
`account: { sandbox: true }` on every controller call, including `list_scenarios`.
Callers that used the AdCP 3.0 account-less form must add this assertion before
upgrading default MCP registration. `account_id` may accompany the assertion on
the controller carrier; ordinary public opaque AccountRefs remain `{account_id}`.
The platform wrapper retains its optional-account compatibility shape and trusted
principal/target sandbox authorization. A caller assertion never grants sandbox
authority by itself.
