# Account Resolution Guide

How sellers implement the three `AccountStore.resolution` modes — `'explicit'`,
`'implicit'`, and `'derived'` — with a deep dive on `'implicit'` (the
`sync_accounts`-first pattern).

---

## Quick reference

| Mode | Roster owner | Onboarding / discovery | Durable wire reference |
|---|---|---|---|
| `'explicit'` (default) | You (the seller) | ids issued out-of-band, or an optional `list_accounts` | `{ account_id }` or the `{ brand, operator }` natural key |
| `'implicit'` | Buyer-declared | `sync_accounts` (required) | `{ brand, operator }` — inline `account_id` is refused |
| `'derived'` | An upstream platform you front, or the credential itself | `list_accounts` (**required**) | `{ account_id }` — the `{ brand, operator }` arm is refused |

Declare the mode on `AccountStore`:

```ts
accounts: {
  resolution: 'implicit',      // or 'explicit' (default) or 'derived'
  resolve: async (ref, ctx) => { ... },
  upsert: async (refs, ctx) => { ... }, // required for 'implicit'
}
```

For buyer setup and opt-in lifecycle management, see
[First call to a seller](./FIRST-CALL-TO-A-SELLER.md).
For upgrading an existing integration, use the
[14.0-to-14.1 checklist](../migration-14.0-to-14.1.md).

### Account sync contracts

For platform `accounts.upsert`, the framework looks up accepted natural-key
entries with `provisioning: false` before calling the batch method. The optional
`ctx.existing` array is aligned with the entries passed to `upsert`; each element
is the pre-write account snapshot or `null`. All natural-key dimensions are
preserved, including brand countries, operator unit, currency, timezone and sandbox.
Natural-key snapshots require the resolved account's own brand and operator;
identity-free singleton resolvers supply no snapshot rather than matching every key.
Use these snapshots to update the existing ID instead of creating another account.
Snapshots are advisory: enforce uniqueness atomically in your own storage too.

The framework emits typed, server-side `accounts.onDiagnostic` events for
`ACCOUNT_SYNC_IDEMPOTENCY_VIOLATION`, `ACCOUNT_SYNC_PAYMENT_TERMS_MISMATCH`, and
`ACCOUNT_BILLING_FIELDS_MISSING`, plus `ACCOUNT_SYNC_BILLING_MISMATCH` when an
active result silently replaces requested agent billing with another party
(strict mode rejects it with `BILLING_NOT_SUPPORTED`). ID-only resolvers that reject natural-key
lookups remain usable and emit `ACCOUNT_SYNC_LOOKUP_UNSUPPORTED`; their
identity checks require store-level enforcement. Events contain only the code, tool and original
row index. Development logs also receive warnings. Callback exceptions do not
change the result of a committed write. The default behavior preserves existing
responses. Set `accounts.strictIdempotency: true` to return per-row failures for
changed IDs, `created` on an existing key, or an active account that omits or
changes requested terms (`PAYMENT_TERMS_NOT_SUPPORTED`). Identity violations
return `SERVICE_UNAVAILABLE`. These post-write checks cannot roll back adopter writes.

Missing sync billing/terms are filled only from a stored account whose ID matches
the result, never from the buyer's requested terms. Agent-billed list rows without
terms also emit a diagnostic. Low-level handler-bag overrides do not use this
platform-store guard.

### Persistent keyed accounts

`createKeyedAccountStore` from `@adcp/sdk/server` supplies deterministic IDs and
additive, non-expiring account syncs. Choose `memoryKeyedAccountBackend()` for one
process, `pgKeyedAccountBackend(pool)` for PostgreSQL, or
`redisKeyedAccountBackend(client)` for a persistent Redis deployment with eviction
disabled. Custom KV backends can implement `KeyedAccountBackend` using native
atomic compare-and-swap; ordinary read followed by write is insufficient.

```ts
import {
  createKeyedAccountStore,
  getKeyedAccountMigration,
  pgKeyedAccountBackend,
} from '@adcp/sdk/server';

await pool.query(getKeyedAccountMigration());
const accounts = createKeyedAccountStore({
  namespace: 'seller-production', // trusted deployment namespace
  backend: pgKeyedAccountBackend(pool),
  resolution: 'implicit',
  buildAccount: async (entry, { accountId, existing, dryRun, ctx }) => {
    // Your onboarding code accepts the requested terms or throws AdcpError.
    // It must use accountId for idempotent upstream writes too.
    return onboardAdvertiser(entry, { accountId, existing, dryRun, authInfo: ctx?.authInfo });
  },
});
```

`buildAccount` is required and returns the actual account, using the supplied
`accountId`. The store validates active payment terms before committing; a
rejected update leaves the stored account intact. It strips `authInfo` before
persistence; credentials must also stay out of `ctx_metadata`. By default the
store partitions accounts by stable OAuth client, API key ID or verified agent
URL. Override `principalKey` only with a trusted authorization partition, never
buyer-supplied request fields. Use distinct namespaces for different sellers.

Concurrent writes retry atomic CAS up to ten times, re-running `buildAccount`
against fresh state. Its external side effects must therefore be idempotent on
the supplied account ID. A crash between an upstream write and the local CAS
still requires that upstream idempotency. The backend stores one roster per
principal with a default `maxAccounts` limit of 1000 and suits modest rosters; large sellers should use indexed account
tables with unique natural-key constraints. Share the memory backend across
server factories; use persistent storage across restarts.

Dry runs do not persist; `buildAccount` receives `dryRun: true` and must preview
without upstream writes or other side effects. Only the seller-returned account
determines sandbox authority; the buyer's sandbox flag participates in identity
and never grants test-tool access. Settings updates cannot provision a missing natural-key
account. `delete_missing` and operator identity reconciliation are explicitly
unsupported; close accounts through your lifecycle code. List cursors are bound
to the principal, filters and roster revision and become stale after a write.
An unknown ID-keyed entry rejects the batch before any `buildAccount` callback:
this interface requires brand/operator on failed rows, and unauthorized account
identities must not be invented or exposed. Failed known-account updates retain
the account's actual status and leave persisted state intact.

Run [the account sync storyboard](../../examples/storyboards/account-sync-contract.yaml)
with one authenticated sandbox caller. Its `account.sync_contract` invariant
checks repeat syncs with fresh request keys, exact accepted terms and billing
fields on list rows. The fixture is SDK-authored; canonical protocol storyboards
remain unchanged. A seller rejecting the fixture's terms needs an accepted-terms
fixture to exercise successful repeat provisioning.

Account resolvers receive `ctx.provisioning`. It is false on discovery and
negotiation (`get_products`, `list_products`, `get_signals`, and proposal
request/refine/decline); these tasks MUST use lookup only. It is true on spend
commitments, `activate_signal`, and `sync_*` tasks. Lazy provisioning must be
explicitly gated:

```ts
resolve: async (ref, ctx) => {
  const existing = await db.findAuthorizedAccount(ref, ctx?.authInfo);
  if (existing || !ctx?.provisioning) return existing;
  return await db.createAuthorizedAccount(ref, ctx?.authInfo);
},
```

When `resolveAccount` is configured, a supplied unknown reference returns
`ACCOUNT_NOT_FOUND`, even on optional account tools.

### Account requests (`request_account`, AdCP 3.3 experimental)

A seller that serves `request_account` registers it through the handler merge
seam, and serves the caller's requests back on `list_accounts` through
`accounts.listRequests`:

```ts
createAdcpServerFromPlatform(
  {
    capabilities: {
      // ...
      supportedBillings: ['agent'], // required with account requests: who bills
      accountRequests: {
        changeableAttributes: ['billing', 'payment_terms', 'timezone'],
        pendingActionKinds: ['review', 'accept_terms'],
      },
    },
    accounts: {
      resolution: 'explicit',
      resolve,
      list,
      // Only when the buyer sends include_requests, request_ids or requests_pagination.
      listRequests: async (request, ctx) => {
        const page = await db.requestsFor(callerOf(ctx), {
          ids: request.request_ids,
          cursor: request.requests_pagination?.cursor,
        });
        return { items: page.records, nextCursor: page.next };
      },
    },
  },
  { accounts: { requestAccount: async (params, ctx) => ({ request: await db.request(params, ctx) }) } }
);
```

Registering `requestAccount` advertises `account.requests` on
`get_adcp_capabilities` (`supported: true`, `request_task: 'request_account'`,
`read_task: 'list_accounts'`, plus `changeable_attributes`,
`pending_action_kinds` and `event_type` from `capabilities.accountRequests`) and
adds `account.requests` to `experimental_features`. Callers on releases before
3.3 see neither. Buyers route `client.accounts.ensure` and
`client.accounts.change` by this block. The same applies to `createAdcpServer`,
with `capabilities.accountRequests`.

The block lives in the account capability block, whose schema requires
`supported_billing`, so declare who bills: `capabilities.supportedBillings` here,
or `capabilities.account.supportedBilling` on `createAdcpServer`. A server that
registers `requestAccount` without one is refused at construction; the SDK never
fills in a billing claim for you.

`listRequests` returns a `CursorPage` of wire account-request records, which the
framework serves as `account_requests[]` and `account_requests_pagination`; the
accounts page is unaffected. Return only the caller's own requests, newest
`updated_at` first and at most 100 per page, and omit unknown or foreign
`request_ids` silently. It needs `accounts.list`. Without it, the framework warns
at startup that buyers cannot poll a pending request.

Return `revision` on the accounts `accounts.list` lists. Buyers read it from
`list_accounts` and send it with a change, and a money change (`billing`,
`billing_entity`, `payment_terms`) without it should be refused with
`INVALID_REQUEST`; a stale one with `CONFLICT`.

### Strict account references (`strictAccountReferences`)

SDK 14 keeps four compatibility behaviors that strict mode removes:

- A buyer-supplied `account` still reaches a raw handler-bag seller that has
  no reference-aware `resolveAccount`: the handler sees `params.account` and
  `ctx.account` is undefined. An auth-only `resolveAccountFromAuth` does not
  authorize an arbitrary reference.
- A seller that declares `capabilities.account.requiredForProducts` still
  serves `get_products` when the request carries no account and
  authentication resolves none.
- `list_accounts.account` is resolved through `resolveAccount` as the
  request's account (an unknown or unauthorized filter returns
  `ACCOUNT_NOT_FOUND`). Strict mode treats it as a filter instead.
- On `createAdcpServerFromPlatform` with `resolution: 'implicit'`, an account
  whose returned identity metadata disagrees with the supplied natural key is
  still used.

Each logs a deprecation warning once per process per warning code (through
`logger.warn`, plus `process.emitWarning` outside `NODE_ENV=production`);
later occurrences log at debug level. Codes:
`ADCP_UNRESOLVED_ACCOUNT_REFERENCE`, `ADCP_REQUIRED_FOR_PRODUCTS_NOT_ENFORCED`,
`ADCP_LIST_ACCOUNTS_FILTER_RESOLVED`, and
`ADCP_IMPLICIT_ACCOUNT_IDENTITY_MISMATCH`.

**Strict mode remains an explicit opt-in in SDK 15.** Set `strictAccountReferences: true`:

```ts
createAdcpServer({
  name: 'Seller',
  version: '1.0.0',
  strictAccountReferences: true,
  resolveAccount: (ref, ctx) => authorizedAccounts.find(ref, ctx.authInfo),
  mediaBuy: {
    getProducts: (params, ctx) => catalog.forAccount(ctx.account, params),
  },
});
```

With `strictAccountReferences: true`:

- A supplied reference on a server without `resolveAccount` fails with
  `ACCOUNT_NOT_FOUND` before the handler runs.
- A `requiredForProducts` seller refuses account-less `get_products` with
  `ACCOUNT_REQUIRED`.
- `list_accounts.account` is a filter: `resolveAccount` is not called for it
  and `ctx.account` comes from `resolveAccountFromAuth`.
- An implicit-mode account whose returned identity metadata (`brand`,
  `operator`, `operator_unit`, `currency`, `timezone`, `sandbox`) disagrees
  with the supplied natural key is refused with `ACCOUNT_NOT_FOUND`. Fields
  your store does not return are not compared.

Migration for handler-bag sellers: move account authorization out of
individual handlers and into `resolveAccount`, then set the flag.
`authorizedAccounts.find` must return null on an unknown reference or a
reference owned by another principal. Public discovery may omit `account`;
resource creation and spend commitments need an authorized account. Implicit
stores should resolve by the complete natural key and return identity
metadata that echoes it, or omit the metadata.

`InMemoryImplicitAccountStore` matches supplied refs on the complete natural
key, including operator unit, currency, timezone, and sandbox. It retains its
24-hour TTL and replacement sync semantics. Set `mergeOnUpsert: true` for
additive batches and revoke individual refs with `remove(ref, ctx)`; passing
`delete_missing: true` in `sync_accounts` retains replacement semantics.

**Each mode has exactly one spelling.** `'derived'` keeps its name even
though [adcp#5062](https://github.com/adcontextprotocol/adcp/pull/5062)
calls the shape an *upstream-managed account-id namespace*: `resolution` is
SDK-local configuration, never a wire value, so a second spelling would buy
nothing on the wire while silently defeating adopter code written as
`resolution === 'derived'` and inviting divergence from the Python SDK.
`'account-id-namespace'` is rejected for the extra reason that it doesn't
discriminate — under #5062 both `'explicit'` and `'derived'` are account-id
namespaces. An unrecognized value is a `PlatformConfigError` at
construction, not a silent fallback.

> **Breaking change in SDK 14 (adcp-client#1647).** `'derived'` used to mean
> "single-tenant; no `account_id` on the wire", and the framework refused
> inline `account_id` for it. That was inverted — see
> [`'derived'` (upstream-managed account-id namespace)](#derived-upstream-managed-account-id-namespace)
> and the [13 → 14 migration guide](../migration-13-to-14.md#derived-account-resolution-is-now-an-upstream-managed-account-id-namespace).

---

## `'implicit'` deep dive

### 1 · How it works

1. Buyer calls `sync_accounts` with natural-key provisioning entries.
2. Framework calls your `accounts.upsert()` — you create/find accounts and
   store the `authPrincipal → accounts` mapping.
3. On subsequent account-scoped calls, the buyer supplies top-level
   `account: { brand, operator, ... }`. The framework calls
   `accounts.resolve(ref, ctx)` with that natural key. Look it up within the
   authenticated caller's synced roster; do not substitute another account.
4. When a request omits `account`, the framework instead calls
   `accounts.resolve(undefined, ctx)`. This is a separate auth-derived lookup
   path. A null result is allowed for account-optional tools and yields
   `ACCOUNT_REQUIRED` for account-required operations.

Implicit sellers refuse the `{ account_id }` reference arm. A seller handle
returned by `sync_accounts` does not replace the natural key on later calls.

### 2 · Key derivation

Extract the principal key from `ctx.authInfo.credential`:

```ts
resolve: async (ref, ctx) => {
  const cred = ctx?.authInfo?.credential;
  const key = cred?.kind === 'oauth'    ? `oauth:${cred.client_id}`
            : cred?.kind === 'api_key'  ? `api_key:${cred.key_id}`
            : cred?.kind === 'http_sig' ? `http_sig:${cred.agent_url}`
            : undefined;
  if (!key) return null;
  if (ref !== undefined) {
    // Match the full natural key within THIS principal's synced roster.
    // An unknown or unauthorized ref returns null, without a fallback.
    return await db.findSyncedAccountByNaturalKey(key, ref);
  }
  // Account omitted: use your existing auth-derived selection policy.
  return await db.findAccountByPrincipalKey(key);
},
```

The `db` methods above are operations you implement in your own store.
`findSyncedAccountByNaturalKey` must compare the complete brand identity
(domain, optional brand ID and countries), operator, operator-unit ID,
currency, timezone, and sandbox within the principal's roster. Use consistent
normalization at sync and lookup, including country ordering and omitted/false
sandbox. It must not create an account or match on brand/operator alone.
`findAccountByPrincipalKey` handles only the omitted-reference path according
to your documented selection policy. The built-in `InMemoryImplicitAccountStore`
keeps its historical first-account selection for that path.

**Why `credential.client_id`, not `authInfo.sub`?**

`credential.client_id` is the OAuth *client* identity — stable across token
rotations and independent of which user (if any) triggered the grant.
`sub` is grant-specific: a buyer rotating credentials or switching from
`client_credentials` to `authorization_code` will get a different `sub`
and lose their synced accounts. Use `sub` only when your platform
intentionally scopes accounts to individual users, and document that choice.

`credential.key_id` for API-key credentialing and `credential.agent_url` for
HTTP Signatures follow the same stability principle: they identify the buyer
entity, not the ephemeral token.

> ⚠️ `authInfo.clientId` (top-level field) is deprecated. Use
> `authInfo.credential.client_id` instead. The deprecated field is removed
> in N+2 of the deprecation cycle.

### 3 · When no sync has happened

Return `null` from `resolve()`. When the request omitted `account`, the
framework emits `ACCOUNT_REQUIRED` with `recovery: 'correctable'` and guidance
to call `sync_accounts`. A buyer-supplied reference that does not resolve still
emits `ACCOUNT_NOT_FOUND` with `recovery: 'terminal'`.

**Do NOT return `AUTH_REQUIRED`, `AUTH_MISSING`, or `AUTH_INVALID`.** Those
errors signal missing or rejected credentials — not a missing pre-sync. Buyers
receiving auth errors will refresh credentials or escalate, not call
`sync_accounts`, and can loop indefinitely.

```ts
// ✓ Correct
resolve: async (ref, ctx) => {
  const key = extractKey(ctx?.authInfo);
  if (!key) return null;
  const account = ref === undefined
    ? await db.findAccountByPrincipalKey(key)
    : await db.findSyncedAccountByNaturalKey(key, ref);
  // Missing: supplied account → ACCOUNT_NOT_FOUND;
  // omitted account on an account-required operation → ACCOUNT_REQUIRED.
  return account ?? null;
},

// ✗ Wrong — misleads buyers about how to recover
resolve: async (ref, ctx) => {
  const key = extractKey(ctx?.authInfo);
  if (!key) return null;
  const account = ref === undefined
    ? await db.findAccountByPrincipalKey(key)
    : await db.findSyncedAccountByNaturalKey(key, ref);
  if (!account) throw new AdcpError('AUTH_MISSING', { message: 'call sync_accounts first' });
  return account;
},
```

Do not replace the omitted-account result with an auth error. The framework's
`ACCOUNT_REQUIRED` suggestion tells the buyer to establish the implicit
linkage. For buyer-supplied unknown, unauthorized, or mismatched references,
the error code must remain `ACCOUNT_NOT_FOUND` to preserve enumeration
resistance.

### 4 · TTL and sync-linkage staleness

The framework has no built-in TTL for sync linkages — TTL is a seller-side
policy. Guidance:

- **In-memory stores (tests):** default to 24 hours. Use
  `InMemoryImplicitAccountStore`'s `ttlMs` option.
- **Durable stores (Postgres / Redis):** add a `synced_at` column and evict
  rows older than your session or token lifetime.
- **Align with token lifetime:** if your OAuth AS issues 1-hour access
  tokens, a 24-hour sync TTL means a buyer's linkage outlives their token.
  That's fine — buyers do not need to hold an active token to have their
  accounts remain linked.
- **Invalidation on credential rotation:** if a buyer's `client_id` changes
  (rare — the AS should issue a new client for the new credential), the old
  sync-linkage row becomes orphaned. Your `upsert()` should UPSERT (not
  INSERT) on `(principal_key, account_id)` so re-syncing is idempotent.

This TTL governs the *sync-linkage lifetime*, which is separate from
`AccountStore.refreshToken` — that hook refreshes an upstream OAuth token
mid-request when your seller-to-upstream platform method throws legacy
`AUTH_REQUIRED` or the 3.1-native `AUTH_MISSING`. It is not a buyer inbound
auth recovery path. The two are orthogonal.

**Postgres schema reference** — see `docs/guides/POSTGRES.md` for the
canonical `adcp_sync_linkages` DDL pattern. The cleanup query there
(`DELETE FROM ... WHERE synced_at < NOW() - INTERVAL '24 hours'`) is the
recommended sweep pattern.

---

## Reference adapter: `InMemoryImplicitAccountStore`

For tests and getting-started scenarios, import the built-in reference
implementation:

```ts
import {
  createAdcpServerFromPlatform,
  definePlatform,
  InMemoryImplicitAccountStore,
} from '@adcp/sdk/server';

const accountStore = new InMemoryImplicitAccountStore({
  // Convert a buyer's AccountReference to your platform's Account shape.
  // Default: synthesizes a minimal Account from the ref fields.
  buildAccount: async (ref, ctx) => {
    const upstream = await myPlatform.findOrCreate(ref, ctx?.authInfo);
    return {
      id: upstream.id,
      name: upstream.name,
      status: 'active',
      ctx_metadata: { upstreamId: upstream.id },
    };
  },
  // Optional: override the key-extraction logic.
  // Default: credential.client_id / credential.key_id / credential.agent_url.
  // keyFn: authInfo => authInfo.extra?.tenant_id as string,
  ttlMs: 86_400_000, // 24h
});

const platform = definePlatform({
  capabilities: { specialisms: ['sales-non-guaranteed'] as const, pricingModels: ['cpm'] as const },
  accounts: accountStore,
  // ... other platform fields
});

createAdcpServerFromPlatform(platform, { name: 'My Agent', version: '1.0.0' });
```

For a runnable example see `examples/decisioning-platform-implicit-accounts.ts`.

### Test helper methods

```ts
accountStore.clear();                           // reset all stored linkages
accountStore.authKey(authInfo);                 // what key would be stored?
accountStore.size;                              // number of stored linkages
```

---

## `'derived'` (upstream-managed account-id namespace)

Pick `'derived'` when the account roster is **not yours to provision**: you
front an upstream platform that owns it (Meta / Snap business accounts,
AudioStack workspaces, a retail-media proxy), or the buyer's credential is
bound to exactly one account on your side. Roster size is an operational
property of the upstream — N=1 and N=many share one wire contract.

The contract:

1. The buyer calls **`list_accounts`** to discover what its credential can
   reach. This is required for the mode, not optional polish —
   `createAdcpServerFromPlatform` throws `PlatformConfigError` when neither
   `accounts.list` nor `opts.accounts.listAccounts` is wired. A credential
   bound to one account returns one row, so buyer SDKs can auto-select it.
2. The buyer sends **`account: { account_id }`** on every account-scoped
   call. The framework refuses the `{ brand, operator }` arm for this mode
   with `AdcpError('INVALID_REQUEST', { field: 'account.brand' })` and a
   `list_accounts` suggestion — a natural key is not a durable reference into
   someone else's roster.
3. Your `resolve` **verifies** that id against what the *caller's credential*
   can reach. A buyer-supplied miss returns `null` (framework → terminal
   `ACCOUNT_NOT_FOUND`). On ref-less operations, zero or multiple reachable
   accounts return `null`; account-required operations then emit correctable
   `ACCOUNT_REQUIRED` with `list_accounts` guidance.
   `createDerivedAccountStore` does this for you. As a backstop the framework
   also refuses a resolved account whose `id` isn't the one the buyer named —
   that catches a resolver that ignores `ref`, but it can't tell whether your
   lookup was credential-scoped, so it is not a substitute for step 3.

```ts
import { createDerivedAccountStore } from '@adcp/sdk/server';

// One account per credential (AudioStack, flashtalking, single-namespace
// retail-media). The factory publishes the one-row list_accounts, verifies
// buyer-supplied ids against it, and auto-selects it on ref-less tools.
const accounts = createDerivedAccountStore<MyMeta>({
  toAccount: async ctx => ({
    id: await upstream.workspaceId(ctx?.authInfo), // the id buyers send back
    name: 'My Platform',
    status: 'active',
    ctx_metadata: {},
  }),
});
```

```ts
// Many accounts per credential (Meta / Snap shaped). `listAccounts` is the
// tenant-isolation boundary: scope it by the caller's credential.
const accounts = createDerivedAccountStore<{ upstreamId: string }>({
  listAccounts: async ctx => {
    const rows = await meta.adAccountsFor(ctx?.authInfo);
    return rows.map(r => ({
      id: r.account_id,
      name: r.name,
      status: 'active',
      ctx_metadata: { upstreamId: r.id },
    }));
  },
  // Optional point lookup for large rosters — MUST filter by the caller too.
  lookupAccount: (id, ctx) => meta.adAccountForCaller(id, ctx?.authInfo),
});
```

For a runnable example see `examples/decisioning-platform-derived-accounts.ts`.

The factory also throws legacy-compatible `AdcpError('AUTH_REQUIRED')` when
`ctx.authInfo` carries no credential (skip with `skipAuthCheck: true` for
genuinely unauthenticated agents). New hand-rolled stores can throw
`AuthMissingError` when they intentionally emit the AdCP 3.1
missing-request-credential code.

Hand-rolled equivalent — you own both obligations, the `list` and the check:

```ts
import { refAccountId } from '@adcp/sdk/server';

accounts: {
  resolution: 'derived',
  resolve: async (ref, ctx) => {
    const reachable = await upstream.accountsFor(ctx?.authInfo); // credential-scoped
    const id = refAccountId(ref);
    // Fail closed. Never "we only have one account, so serve it anyway".
    // (The framework also refuses a resolved account whose id isn't the one
    // the buyer named — but own the check; it's your tenant boundary.)
    if (id !== undefined) return reachable.find(a => a.id === id) ?? null;
    // Ref-less tools: auto-select only when there is exactly one. An
    // account-required operation maps any other roster size to ACCOUNT_REQUIRED.
    return reachable.length === 1 ? reachable[0] : null;
  },
  // The framework does not filter or page for you: honor req.account /
  // req.status / req.sandbox and req.pagination in your own query.
  list: async (req, ctx) => ({ items: await upstream.accountsFor(ctx?.authInfo) }),
}
```

### Ignoring `ref` is a tenant-isolation bug

A resolver that returns a fixed account regardless of `ref` was the
pre-SDK-14 Shape D pattern. Keep writing it and the first time your
deployment serves two accounts, caller A's `{ account_id: 'B' }` request runs
against account A's data — no error, no log. Verify the ref, or let
`createDerivedAccountStore` verify it.

### Writes are verified too

`sync_accounts` and `sync_governance` carry their account reference *inside*
the batch, so they never went through `accounts.resolve`. For `'derived'`
platforms the framework now resolves every entry's `account_id` against what
the caller's credential can reach before any write runs — an unreachable id
fails the `sync_accounts` operation with `ACCOUNT_NOT_FOUND` (the response
row schema requires `brand` + `operator`, which we don't have for an account
we refused to resolve) and fails the individual `sync_governance` row.

### `sync_accounts` in derived mode

Not forbidden, but narrowed to what [adcp#5062](https://github.com/adcontextprotocol/adcp/pull/5062)
allows:

- **Natural-key provisioning entries** (`{ brand, operator, billing }` at the
  entry root, or a settings-update entry keyed by the natural key) are failed
  per-row by the framework with `UNSUPPORTED_PROVISIONING` before reaching
  `accounts.upsert`. There is nothing to provision in a namespace you don't
  own.
- **Settings-update entries** keyed by `account: { account_id }` pass
  through, after the reachability check above. Wire `accounts.upsert` if your
  upstream exposes account-settings writes; leave it unimplemented and buyers
  calling `sync_accounts` get the framework's unimplemented-tool path, as
  before.
- A natural-key *reference* (`account: { brand, operator }`) is refused
  per-row with `INVALID_REQUEST` — the ref shape is wrong for the namespace,
  which is a different fault from the provisioning mode being unsupported.
- An entry carrying **two** references (root `account_id` plus a nested
  `account`, or an `account` mixing `account_id` with `brand`/`operator`) is
  refused with `INVALID_REQUEST`, never disambiguated by precedence. The
  schema's per-entry `oneOf` forbids those shapes, but validation is
  relaxable and accepting on one reference while writing against another is
  a bypass.
- **Response rows still require `brand` + `operator`** per
  `sync-accounts-response.json`, so a settings-update row echoes them from
  your own account record. If your upstream accounts have no brand/operator
  you can express, don't wire `upsert` — see
  [adcontextprotocol/adcp#7517](https://github.com/adcontextprotocol/adcp/issues/7517).

### Capability projection

A declared `resolution: 'derived'` projects `account.require_operator_auth:
true` on `get_adcp_capabilities` — the capability bit for account-id
namespaces, same as declared `'explicit'`. Conformance runners read it and
grade `sync_accounts` storyboard steps as `not_applicable` rather than
`missing_tool`. Override with `capabilities.requireOperatorAuth` if your
deployment's auth model differs.

Emitting the account block also emits `account.supported_billing`, which
defaults to `['agent']`. Declare `capabilities.supportedBillings` explicitly
— an upstream-managed namespace usually bills the operator, and the default
will route buyers into agent-billed flows.

### If you have no namespace to discover

An agent that hands out account ids out-of-band and has nothing to enumerate
is a **seller-defined** account-id namespace: declare `'explicit'`. That mode
accepts `{ account_id }` (and the natural key) with no discovery obligation.

### Stateless BYOK provider auth

For single-account API-key or bearer-token BYOK adapters, the provider
credential can be the AdCP request credential for that endpoint. A caller
presents the current provider key or OAuth access token as normal bearer
request auth:

```http
Authorization: Bearer <provider_api_key_or_access_token>
```

This is the single-plane pattern for a seller agent that wraps one upstream
provider account per credential: the seller agent authenticates the request
with the caller-presented provider credential, derives the singleton account
from that request auth, and uses the same request-local token for upstream API
calls. No SDK-managed OAuth flow, refresh-token store, provider-token store,
or callback route is required when the caller owns the provider credential
lifecycle. If the provider credential can see multiple upstream accounts,
stay in `'derived'` but supply `listAccounts` instead of `toAccount` so the
buyer can discover and name one — or use `createOAuthPassthroughResolver`
under `'explicit'` if you also own the id namespace.

Handlers with a resolved account should read the active token from
`ctx.account.authInfo?.token`; refresh hooks update `account.authInfo`.
Handlers without a resolved account can read the request token from
`ctx.authInfo.token`. Use a stable non-secret identity for cache and
idempotency scoping, such as `ctx.authInfo.credential.key_id` for API keys,
`ctx.authInfo.credential.client_id` for OAuth, or an adopter-supplied
`principal`. Do not store the raw token in `ctx_metadata`; keep it on request
auth and re-read it per request.

Treat both token paths as request-local. Do not copy provider tokens into
persisted Account rows, `ctx_metadata`, `ctx.authInfo.extra`, request `ext` /
body fields, or log lines. In dual-auth proxy deployments, keep the second
credential request-local too; log only non-secret identifiers such as
`key_id`, `client_id`, or `principal`.

Only introduce a separate provider-auth channel when one request truly needs
two credentials: one credential to authorize the caller to the AdCP agent and
another credential to authorize the upstream provider tenant. That dual-auth
proxy shape is optional; it is not the baseline BYOK model.

No `upsert` needed — see [`sync_accounts` in derived mode](#sync_accounts-in-derived-mode)
for what the framework does with each entry shape when you do wire one.

---

## `'explicit'` (default)

Resolve from `ref.account_id` or `ref.brand`/`ref.operator`:

```ts
import { refAccountId } from '@adcp/sdk/server';

accounts: {
  resolution: 'explicit',  // or omit — 'explicit' is the default
  resolve: async (ref, ctx) => {
    const id = refAccountId(ref);
    if (id) return db.findForPrincipal(id, ctx.authInfo);
    if (ref?.brand && ref?.operator) return db.findByBrandOperatorForPrincipal(ref.brand, ref.operator, ctx.authInfo);
    return null;
  },
}
```

`upsert` is optional for explicit-mode platforms. Implement it if your buyers
need to pre-register accounts before use (e.g., credit-check gates).
Always bind buyer-supplied account references to the authenticated principal;
return `null` for a reference outside that principal's roster. This also applies
to `list_creative_formats` when its optional AdCP 3.2 `account` field is supplied.

For the Shape C publisher-curated pattern, prefer `createRosterAccountStore`
over a hand-rolled store — it handles the id-arm dispatch and `list_accounts`
plumbing, and exposes `resolveWithoutRef` for the ref-less case (see
[Ref-less resolution](#ref-less-resolution-list_creative_formats-preview_creative-provide_performance_feedback) below).

---

## Ref-less resolution (`list_creative_formats`, `preview_creative`, `provide_performance_feedback`)

`preview_creative` and `provide_performance_feedback` send no `account` field.
In AdCP 3.2, `list_creative_formats` may send one. When it is omitted,
the framework calls `accounts.resolve(undefined, ctx)`. Publisher-curated (`resolution: 'explicit'`)
platforms using `createRosterAccountStore` get `null` by default —
`ctx.account` is `undefined` in those handlers.

Use `resolveWithoutRef` when your platform needs a synthetic publisher-wide
account for these tools:

```ts
import { createRosterAccountStore } from '@adcp/sdk/server';

const accounts = createRosterAccountStore({
  lookup: async (id, ctx) => db.findForPrincipal(id, ctx?.authInfo),
  toAccount: row => ({
    id: row.id,
    name: row.name,
    status: 'active',
    ctx_metadata: { tenantId: row.tenant_id },
  }),
  // Called when tools resolve with no account_id on the wire.
  // The returned entry flows through toAccount like any lookup hit.
  resolveWithoutRef: (_ref, ctx) => ({
    id: '__publisher__',
    name: 'Publisher',
    // tenant_id is a custom TRosterEntry field — toAccount maps it to ctx_metadata
    tenant_id: ctx?.authInfo?.credential?.client_id ?? 'default',
  }),
});
```

When `resolveWithoutRef` returns `undefined`, the helper falls back to `null`
(same as omitting the option).

**Auth-derived singleton.** If the publisher singleton must be looked up from
your roster by a principal-derived id (rather than synthesized inline), use the
spread-override pattern so the lookup goes through `lookup` + `toAccount`:

```ts
const base = createRosterAccountStore({ lookup, toAccount });
const accounts = {
  ...base,
  resolve: async (ref, ctx) => {
    if (ref === undefined) {
      const id = deriveAccountIdFromAuth(ctx?.authInfo);
      return id ? base.resolve({ account_id: id }, ctx) : null;
    }
    return base.resolve(ref, ctx);
  },
};
```

**Hand-rolled stores.** For stores that don't use `createRosterAccountStore`,
handle `resolve(undefined, ctx)` in your own `resolve` implementation by
checking `ref === undefined` before the id-arm branch.

### Callback boundaries

A custom `principalKey` may be synchronous or asynchronous, and must return a nonempty primitive string derived from trusted authentication state. Missing, object, numeric, boolean, or blank values fail closed before backend access. Use a stable tenant identity, keep it deterministic across repeated calls in one request, and bound callback I/O durations.

`createKeyedAccountStore` captures dry-run intent before callbacks and gives each CAS retry fresh copies of sync entries and request input. Mutating callback request arguments cannot change the original request or turn a preview into a committed write. Framework commercial checks also retain an independent request snapshot. Async diagnostic hooks are fire-and-forget; their failures are isolated from dispatch.
