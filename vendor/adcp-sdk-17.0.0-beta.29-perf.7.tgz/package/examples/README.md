# AdCP Client Examples

This directory contains practical examples of how to use the `@adcp/sdk` library.

## Start here: AdCP 3.2 seller

[`seller-3.2-starter.ts`](./seller-3.2-starter.ts) is the runnable first path:
under 200 lines, typed, and built around
`list_products` → `buy_products` → `control_media_buy`. It reads real products
from `PRODUCT_CATALOG_JSON` and never invents fallback inventory.

The `hello_*` and `decisioning-platform-*` files are advanced integration and
certification references. They intentionally show complete adapters, durable
boundaries, and conformance hooks, so many are 700–1,400 lines. Start with the
compact seller, then open the advanced example matching your backend.

Adding one task to an application that already owns auth and storage? Start
with [`existing-platform-thin.ts`](./existing-platform-thin.ts) and the
[existing-platform guide](../docs/guides/EXISTING-PLATFORM.md).

Running buyer writes from request-scoped processes? The
[`durable-buyer-writes`](./durable-buyer-writes/) example connects the caller,
fresh callback/poll worker, PostgreSQL receiver stores, and host publication
outbox described in the
[durable buyer writes guide](../docs/guides/DURABLE-BUYER-WRITES.md).

Maintaining a buyer-side copy of a seller's wholesale products and signals?
[`wholesale-feed-sync.ts`](./wholesale-feed-sync.ts) shows the complete path:
durable bootstrap, declarative account-level webhook registration, raw-body
RFC 9421 verification, notification normalization, `applyWebhook()`, and
automatic repair on version gaps or bulk changes. Set `ADCP_SELLER_URL`,
`ADCP_SELLER_AGENT_ID`, `ADCP_SELLER_BRAND_JSON_URL`, `ADCP_ACCOUNT_ID`,
`ADCP_SUBSCRIBER_ID`, and the externally reachable HTTPS `ADCP_WEBHOOK_URL`,
then run `npx tsx examples/wholesale-feed-sync.ts`. The example's file-backed
snapshot and in-memory replay protection are single-process defaults; use
shared persistence, replay, and webhook-dedupe stores for multiple replicas.
See [Verifying inbound webhooks](../docs/recipes/verifying-inbound-webhooks.md)
for the full deployment hardening checklist.

Migrating a seller adapter to AdCP 3.2 targeting? The focused
[`targeting-input-existing-platform.ts`](./targeting-input-existing-platform.ts)
example carries nullable omit/clear/set commands through provider translation,
persists strict accepted state, produces strict readback, and refuses clears the
provider cannot honor.

Adding Reliable Reporting Core to an existing seller? Start with the
[adapter-first installation example](https://github.com/adcontextprotocol/adcp-client/blob/main/packages/reporting-storage/examples/reliable-reporting-service/README.md).
It uses the durable ledger as the sole authority and shows trusted account,
source-scope, timezone, and currency resolution without sample reporting data.

The [existing-app reliable reporting buyer](./reliable-reporting-buyer/README.md)
wires the public buyer entrypoint, PostgreSQL stores, verified webhook intake,
buyer-retained expectations, adjustment policy, metrics, and shutdown.

The [reporting subscriptions reference seller](./reporting-subscriptions-seller/seller.mjs)
composes the principal runtime, the subscription coverage engine and the
Reliable Reporting service for principal-level `reporting_subscriptions`
(experimental). It passes
[`storyboards/reporting-subscriptions.yaml`](./storyboards/reporting-subscriptions.yaml).

## Building an AdCP agent — fork-target reference adapters

Pick the example whose AdCP role and specialism most closely matches what you're building, fork it, replace the `// SWAP:` markers, and follow the `FORK CHECKLIST` block for the unmarked but load-bearing constants. The `hello_*_adapter_*` examples are paired with the three-gate CI test (strict tsc / storyboard / upstream-traffic) where a matching mock server exists; examples without one are called out below with the narrower runtime coverage they currently have. `proxy-seller-snap/` is a lighter bridge-pattern fork target: it proves seed-bridge wiring and must be paired with your live-OAuth sandbox runner for upstream health.

| If you're claiming…                                              | Fork                                     | Then…                                                                                                                                                                                                                     |
| ---------------------------------------------------------------- | ---------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `signal-marketplace` / `signal-owned`                            | `hello_signals_adapter_marketplace.ts`   | as-is for marketplace; `signal-owned` adopters drop the marketplace-specific tax/rev-share fields                                                                                                                         |
| `creative-template`                                              | `hello_creative_adapter_template.ts`     | as-is — single-tenant; production adopters add per-tenant workspace binding (see SWAP markers)                                                                                                                            |
| `creative-generative`                                            | `hello_creative_adapter_template.ts`     | replace template-driven `buildCreative` with brief-driven generation; keep the `previewCreative` shape                                                                                                                    |
| `creative-ad-server`                                             | `hello_creative_adapter_ad_server.ts`    | as-is — covers the stateful library + tag generation + macro substitution + delivery reporting flow                                                                                                                       |
| `sales-non-guaranteed`                                           | `hello_seller_adapter_non_guaranteed.ts` | as-is — covers sync confirmation, floor pricing, spend-only forecast, pacing propagation                                                                                                                                  |
| `sales-guaranteed`                                               | `hello_seller_adapter_guaranteed.ts`     | as-is — covers the HITL flow                                                                                                                                                                                              |
| `sales-broadcast-tv`                                             | `hello_seller_adapter_guaranteed.ts`     | replace `audience_targeting` with broadcast-DMA targeting; replace `Product.channels` with `linear_tv`                                                                                                                    |
| `sales-streaming-tv`                                             | `hello_seller_adapter_guaranteed.ts`     | adjust `Product.channels` to `ctv`                                                                                                                                                                                        |
| `sales-social`                                                   | `hello_seller_adapter_social.ts`         | as-is                                                                                                                                                                                                                     |
| Proxy-shaped seller / DSP / walled garden                        | `proxy-seller-snap/`                     | start here when reads proxy an upstream platform API and storyboard seeds need `TestControllerBridge` to appear in sandbox reads                                                                                          |
| `sales-catalog-driven`                                           | `hello_seller_adapter_social.ts`         | promote `syncCatalogs` to a real catalog ingestion + `getProducts` reads from the catalog                                                                                                                                 |
| `audience-sync`                                                  | `hello_seller_adapter_social.ts`         | strip everything except `syncAudiences` + `pollAudienceStatuses`; this is the standalone audience-sync seller pattern                                                                                                     |
| `governance-spend-authority` / `property-lists` / `brand-rights` | `hello_seller_adapter_multi_tenant.ts`   | as-is — multi-specialism + multi-tenant agency / holdco shape; closes adcp-client#1332 (governance) and adcp-client#1334 (brand-rights). Single-specialism adopters fork the relevant handler block out of the same file. |

Naming convention: `hello_<role>_adapter_<specialism>.ts` where `<role>` is the AdCP protocol layer (`seller` for `media-buy`, `creative` for `creative`, `signals` for `signals`, `governance` for `governance`, `brand` for `brand`). `<specialism>` strips the role-implied prefix (so `creative-template` → `_template`, `sales-guaranteed` → `_guaranteed`). The multi-tenant holdco adapter sits outside this convention because it spans multiple roles (governance + brand-rights + property-lists) — naming follows the deployment shape rather than a single role.

## Common multi-specialism bundles

Real platforms typically claim more than one specialism. Claim a specialism only if (a) you implement its required tools **and** (b) you are prepared to receive and service requests for that flow in production. Stub-throw or empty-array implementations are a smell — drop the claim instead.

| Adopter shape                                              | Canonical specialism bundle                                                                  | Skills                                                                                                                                                            |
| ---------------------------------------------------------- | -------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Retail-media network (Amazon Ads, Walmart Connect, Citrus) | `sales-catalog-driven` + `audience-sync` + `creative-template`                               | [retail-media](../skills/build-retail-media-agent/SKILL.md), [seller](../skills/build-seller-agent/SKILL.md), [creative](../skills/build-creative-agent/SKILL.md) |
| Hybrid creative platform (Celtra, Bannerflow)              | `creative-template` + `creative-generative`                                                  | [creative](../skills/build-creative-agent/SKILL.md), [generative-seller](../skills/build-generative-seller-agent/SKILL.md)                                        |
| Walled-garden social network (Meta, Snap, TikTok)          | `sales-social` + `audience-sync`                                                             | [seller](../skills/build-seller-agent/SKILL.md)                                                                                                                   |
| Premium broadcaster (Paramount, Disney)                    | `sales-broadcast-tv` + `sales-streaming-tv` _(preview)_                                      | [seller](../skills/build-seller-agent/SKILL.md)                                                                                                                   |
| DSP-side seller (Scope3, Trade Desk)                       | `sales-non-guaranteed` + `signal-marketplace`                                                | [seller](../skills/build-seller-agent/SKILL.md), [signals](../skills/build-signals-agent/SKILL.md)                                                                |
| Identity provider (LiveRamp, ID5)                          | `signal-owned` + `audience-sync`                                                             | [signals](../skills/build-signals-agent/SKILL.md), [seller](../skills/build-seller-agent/SKILL.md)                                                                |
| Governance vendor (IAS, DV)                                | `governance-delivery-monitor` + `measurement-verification` _(preview)_ + `content-standards` | [governance](../skills/build-governance-agent/SKILL.md)                                                                                                           |

> Each specialism runs its own compliance storyboard independently — no joint multi-specialism storyboard exists yet. For cross-protocol bundles (e.g. DSP-side seller spans `media-buy` + `signals`), run each protocol's storyboard separately.

## AdCP 3.1 commercial-state model

Keep three axes separate when forking a Hello agent:

- `capabilities.account.supported_billing` is the seller-wide wire capability. Set `capabilities.supportedBillings` on decisioning-platform examples when the seller accepts `operator`, `agent`, or `advertiser` billing at all.
- `BuyerAgentRegistry` is the per-caller commercial relationship. `hello_signals_adapter_marketplace.ts`, `hello_seller_adapter_social.ts`, and `hello_seller_adapter_multi_tenant.ts` show the durable buyer-agent identity seam; `ctx.agent` is the trusted record for status, sandbox-only reach, tenant routing, and billing gates.
- `fixtures.buyer_agents[]` plus `seed_buyer_agent` is the compliance setup path. The signals Hello agent wires a test-only overlay so a 3.1 storyboard can vary Addie's `status`, `sandbox_only`, or `billing_capabilities` without inventing a special bearer-token prefix. Production agents should back this with their onboarding ledger and invalidate the registry cache after mutation.

The framework resolves buyer agents, status-gates them, and enforces `sync_accounts.billing` against both seller-wide `supportedBillings` and the resolved `ctx.agent.billing_capabilities`. The social Hello agent includes a buyer-agent ledger so the framework can exercise the per-agent billing gate; do not fork a separate bearer-token prefix or unscoped test-only shortcut.

## Examples

### Packaged starting points

- **`seller-3.2-starter.ts`** - Compact AdCP 3.2 seller with direct purchase and lifecycle control
- **`comply-controller-seller.ts`** - Compliance setup using repository adapters
- **`decisioning-platform-multi-tenant.ts`** - Host-routed multi-tenant decisioning platform

### Multi-specialism + multi-tenant (account-routed)

`hello_seller_adapter_multi_tenant.ts` demonstrates the **account-routed** multi-tenant model: one server hosts `governance-spend-authority`, `property-lists`, and `brand-rights` for two distinct tenants whose data never crosses. The agency / holdco hub shape. It has strict typecheck coverage plus a direct MCP runtime test for buyer-agent-derived no-account tenant routing; full storyboard/façade gates will land once governance / brand-rights mock servers exist. Two resolution paths:

- Tools that carry `account` (governance, property-lists, sync_accounts, sync_governance) → `accounts.resolve(ref)` reads `ref.operator` and routes to the matching tenant. Same buyer credential can hit different tenants by varying `account.operator`.
- Tools without `account` (`get_brand_identity`, `get_rights`) → `accounts.resolve(undefined, ctx)` reads the resolved buyer agent's home tenant from `ctx.agent`. Different credentials → different views of the catalog without any account field on the wire.

Cross-specialism dispatch: `brandRights.acquireRights` consults `campaignGovernance.checkGovernance` directly (in-process, no HTTP roundtrip) when the buyer has registered a governance binding via `sync_governance`. Returns the spec-correct `AcquireRightsRejected` arm with `reason` + `suggestions` on denial.

This is distinct from `decisioning-platform-multi-tenant.ts` which uses **host-routed** tenancy via `TenantRegistry` (different agentUrls per tenant). Both are valid; pick by deployment shape.

### Multi-tenant (path-routed Express)

`decisioning-platform-path-routed.ts` demonstrates the **path-routed** TenantRegistry model for existing Express apps that must keep legacy public paths such as `/storefront/:platformId/mcp`. The route resolves the tenant from the decoded path segment, creates a per-request `StreamableHTTPServerTransport`, stamps MCP `req.auth` from the app's existing auth middleware, and lets each platform's `accounts.resolve(ref, ctx)` scope buyer identity from `ctx.authInfo`.

### Agent testing (`comply_test_controller`)

Start with `createComplyController` (`comply-controller-seller.ts`). Switch to `registerTestController` (`seller-test-controller.ts`) only when your domain state has internal structure that multiple production tools read from — i.e., when the adapter surface's one-method-per-scenario shape starts fighting the code you already have.

- **`comply-controller-seller.ts`** — `createComplyController` adapter surface. Each scenario maps cleanly to one repository method (`seed_creative` → `creativeRepo.upsert`). The default choice.
- **`seller-test-controller.ts`** — `registerTestController` with a hand-rolled `TestControllerStore`. Pick this when your media buy / creative records carry internal structure (packages, revision, history) that seed must populate AND production tools (`get_media_buy`, `sync_creatives`) must read. Flat store surface, session-scoped factory.

Both wire `comply_test_controller`, both auto-emit the `capabilities.compliance_testing.scenarios` block, both sit on the same primitives. Pick by state shape, not by perceived helper tier.

For proxy-shaped sellers where reads go to an upstream platform API, start with **`proxy-seller-snap/`**. It shows the seed bridge pattern: `comply_test_controller` writes storyboard fixtures into a session store, production read handlers call the Snap-shaped client, and `bridgeFromSessionStore` merges seeded products, creatives, and governance lists into sandbox responses after the handler succeeds.

Run `npm run typecheck:examples` to validate both examples against the built `dist/`.

### Running the compact seller

Follow the [AdCP 3.2 seller quickstart](../docs/guides/SELLER-QUICKSTART-3.2.md) to configure real inventory and start `seller-3.2-starter.ts`.

## Environment Configuration

The library supports loading agent configurations from environment variables. Set `ADCP_AGENTS_CONFIG` (or `SALES_AGENTS_CONFIG`):

```bash
ADCP_AGENTS_CONFIG='[{"id":"test-agent","name":"Test Agent","agent_uri":"https://test-agent.example.com","protocol":"mcp","auth_token":"your-token"}]'
```

## Library Usage Patterns

### 1. Multi-Agent Client

```typescript
import { ADCPMultiAgentClient, type AgentConfig } from '@adcp/sdk';

const agents: AgentConfig[] = [
  /* your agents */
];
const client = new ADCPMultiAgentClient(agents);

// Single agent operation
const agent = client.agent('agent-id');
const result = await agent.getProducts({ brief: '...' });

// Multi-agent parallel operation
const results = await client.agents(['id1', 'id2']).getProducts({ brief: '...' });
```

### 2. Environment-based Configuration

```typescript
import { ADCPMultiAgentClient } from '@adcp/sdk';

// Auto-discover from env vars and config files
const client = ADCPMultiAgentClient.fromConfig();

// Or from environment only
const client = ADCPMultiAgentClient.fromEnv();
```

## Available Tools

AdCP tools available on `AgentClient`:

- `getProducts()` - Discover advertising products
- `refineProposals()` - Revise or finalize compact proposals with capability-aware preflight
- `listCreativeFormatsLegacy()` - Inspect the legacy named-format catalog during migration
- `createMediaBuy()` - Create a media buy
- `updateMediaBuy()` - Update a media buy
- `syncCreatives()` - Sync creative assets
- `listCreatives()` - List creative assets
- `getMediaBuyDelivery()` - Get delivery performance
- `getSignals()` - Get audience signals
- `activateSignal()` - Activate audience signals
- `providePerformanceFeedback()` - Send performance feedback
- `getAdcpCapabilities()` - Get agent capabilities (v3)

## Error Handling

```typescript
const result = await agent.getProducts({ brief: 'test' });

if (result.success && result.status === 'completed') {
  console.log('Data:', result.data);
} else {
  console.log('Error:', result.error);
}
```

## Testing Framework

This package also includes a complete testing framework. To run the testing UI:

```bash
npm run dev
# Open http://localhost:8080
```

See the main README for full testing framework documentation.

Supply-path verification: [supply-path-verification.ts](supply-path-verification.ts) reads owner, host, agent and collection from environment variables and prints a live evidence-bearing verdict.
