# AdCP Protocol Bundle

This tarball contains the complete AdCP protocol for version `3.1.17`:

- `schemas/` — JSON Schemas for every task (request + response)
- `compliance/` — Storyboard bundles (universal, domains/, specialisms/, test-kits/)
- `skills/` — Agent-facing protocol skills (`call-adcp-agent` for buyer-side rules, `adcp-*` for per-protocol task semantics). SDKs ship these to give Claude/agents the cross-cutting wire contract.
- `openapi/registry.yaml` — OpenAPI description of the registry endpoints
- `manifest.json` — Version + contents summary
- `CHANGELOG.md` — Release notes

## Quick start

```bash
# Pull and verify this exact version
curl -OL https://adcontextprotocol.org/protocol/3.1.17.tgz
curl -OL https://adcontextprotocol.org/protocol/3.1.17.tgz.sha256
shasum -a 256 -c 3.1.17.tgz.sha256

# Optional: verify the publisher with Sigstore (requires cosign 2.x)
curl -OL https://adcontextprotocol.org/protocol/3.1.17.tgz.sig
curl -OL https://adcontextprotocol.org/protocol/3.1.17.tgz.crt
cosign verify-blob \
  --signature 3.1.17.tgz.sig \
  --certificate 3.1.17.tgz.crt \
  --certificate-identity-regexp '^https://github\.com/adcontextprotocol/adcp/\.github/workflows/release\.yml@refs/heads/.*$' \
  --certificate-oidc-issuer 'https://token.actions.githubusercontent.com' \
  3.1.17.tgz

tar xzf 3.1.17.tgz
cd adcp-3.1.17
```

## Validate an agent

```bash
npx @adcp/sdk@latest storyboard run https://my-agent.example.com
```

The CLI uses the same `compliance/` tree bundled here. For offline runs, point it at
the extracted directory (see @adcp/sdk docs).

## What's in the bundle

See `manifest.json` for the generated file count, and `compliance/index.json`
for the enumerated domains + specialisms that agents can claim in
`get_adcp_capabilities`.

## Layout stability

The directory structure inside `adcp-{version}/` (`schemas/`, `compliance/`,
`skills/`, `openapi/`, `manifest.json`) is a stable contract within a given
major version. Renames or moves inside this tree are breaking changes and only
ship with a major bump.

## Docs

- https://adcontextprotocol.org/docs/building/schemas-and-sdks
- https://adcontextprotocol.org/docs/building/verification/validate-your-agent
